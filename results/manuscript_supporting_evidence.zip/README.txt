Reviewer-supporting manuscript evidence
=======================================

Canonical source: dissipation_qrc.tex

Build from this directory with:
  latexmk -pdf -interaction=nonstopmode -halt-on-error dissipation_qrc.tex

This checksum-sealed reviewer-supporting package extends the compile-facing source with figure generators, compact paper snapshots, protocol records, frozen drivers, and the continuation records used by the complete reviewer bundle. Full raw numerical outputs are distributed in the separate evidence archives.
