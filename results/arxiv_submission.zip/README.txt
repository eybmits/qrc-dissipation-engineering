arXiv submission source package
===============================

Canonical source: dissipation_qrc.tex

Build from this directory with:
  latexmk -pdf -interaction=nonstopmode -halt-on-error dissipation_qrc.tex

This upload contains only the files needed to compile the manuscript: the main TeX source, generated bibliography, bundled class and bibliography style, eight section files, and exactly the eight vector figures used by the paper. Full code, data, figure generators, protocol records, and numerical evidence are released separately at https://github.com/eybmits/qrc-dissipation-engineering.
