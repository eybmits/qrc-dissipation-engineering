arXiv submission source package
===============================

Canonical source: dissipation_qrc.tex

Build from this directory with:
  latexmk -pdf -interaction=nonstopmode -halt-on-error dissipation_qrc.tex

The package contains the generated bibliography, the bundled quantumarticle class and bibliography style, all section files, and exactly the nine vector figures used by the manuscript. The figure sources and compact paper snapshots are included for direct inspection, including the reset-architecture snapshot and its repo-native strict driver. The N=6 rank-one orientation snapshot is bound to its compact validated summary, protocol, provenance, environment, validator, and frozen execution and aggregation source; the separately released full record contains all 24 checkpoints. The final N=5 numerical-replay report and its non-scientific protocol amendment are also included and hash-bound to the compact snapshot. The exact protocol manifest, frozen driver snapshots, and complete N=5 collective and cross-size local/pair continuation records are included. The separate numerical-evidence archive contains the full raw outputs. The complete project repository and numerical evidence have been released publicly at https://github.com/eybmits/qrc-dissipation-engineering.
