# QRC dissipation-engineering revision evidence

This is complete and ready for a final evidence snapshot.  It accompanies the Quantum revision and contains the
scientific and manuscript source, tests, current analysis reports, named
revision result groups, and checksum-validated baseline archives.  It
intentionally excludes rendered PDFs, caches, version-control metadata,
credential-like paths, smoke outputs, and superseded
`measurement_full`/`measurement_full_v2` results.

## Evidence authority

The reports directly under `reports/` in this package are the current narrative
authority.  The two nested baseline archives provide the raw main/review
protocol evidence; historical measurement and same-seed prospective archives
are deliberately omitted because the sealed revision groups supersede them.
The single frozen diagnostic file consumed by the fresh-interpolation driver
is retained at its original relative path and authenticated against that
stage's sealed manifest.
For parity and system-size conclusions, use `revision_parity_control` and
`revision_normalized_scaling`, respectively, rather than the corresponding
legacy rows in the baseline archive.

## Result groups

| group | status | files |
|---|---:|---:|
| `revision_tuning` | complete | 1423 |
| `measurement_full_v3` | complete | 122 |
| `revision_parity_control` | complete | 132 |
| `revision_normalized_scaling` | complete | 82 |
| `revision_primary_regularization` | complete | 226 |
| `collective_loss_full_input_diagnostic` | complete | 3 |
| `primary_driven_activity` | complete | 226 |
| `forecast_baseline_audit` | complete | 1 |
| `activity_matched_response` | complete | 405 |

Release-documentation gate: **complete**.
Exact missing files or pending final-seal/figure-QA lines are recorded in
`PROVENANCE.json`.

`PROVENANCE.json` records exact group checks, Git state, and the builder
contract. `SHA256SUMS.txt` authenticates every other member in this package.
The archive's adjacent `.sha256` file authenticates the archive itself.

## Verification

From the repository used to build this archive:

```bash
python3 scripts/build_revision_evidence_package.py verify \
  --require-complete PATH_TO_ARCHIVE
```

To reproduce the final package, first complete the experiment drivers described
in the included source, then run:

```bash
python3 scripts/build_revision_evidence_package.py build \
  --require-complete \
  --output results/qrc_dissipation_reproducibility_package.zip
```

To reconstruct a runnable checkout from an extracted evidence package, run the
following commands from the package's top-level `qrc_dissipation_revision_evidence` directory.
The separate reconstruction directory is necessary because repository files
live under `source/`, while the packaged result groups live under `results/`:

```bash
mkdir reproduction
cp -R source/. reproduction/
cp -R results reproduction/
cp -R reports reproduction/
cd reproduction
tar -xzf results/final_protocol_results.tar.gz -C results
tar -xzf results/review_protocol_results.tar.gz -C results
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
PYTHONPATH=src:experiments python -m pytest -q
PYTHONPATH=src:experiments python   experiments/validate_revision_primary_regularization_artifacts.py
PYTHONPATH=src:experiments python   experiments/validate_collective_loss_full_input_artifacts.py
PYTHONPATH=src:experiments python   experiments/validate_nested_operating_point_artifacts.py
# Activity protocol terminal state: outcome-neutral feasibility failure.
# PROVENANCE.json records the authenticated 160-row pilot and 240-cell calibration audit;
# no frozen calibration, task scores, or aggregate exist by design.
MPLCONFIGDIR=.mplconfig python paper/make_figures.py
cd paper
latexmk -pdf -interaction=nonstopmode -halt-on-error dissipation_qrc.tex
```

No machine-local absolute path or environment variable is stored in the
package.  All archive paths are relative to the single top-level directory
`qrc_dissipation_revision_evidence`.
