# Response to the principal reasons for rejection

We thank the referee for identifying places where the manuscript's claim
hierarchy was stronger than the evidence. We agree that the fixed-Frobenius
comparison was presented too much like an operationally equal-cost comparison,
that the spectral diagnostic was described too generally, that the finite-size
trend was too prominent, and that the measurement-grid factor was not
scientifically distinct from generic grouping efficiency. The revision changes
the claims rather than arguing around those limitations.

The numbering below follows the supplied list of principal reasons
(\(1,2,4,5\)).

## 1. The fixed-Frobenius comparison is not an experimental cost match

**Response: accepted.**

The quantity
\[
\mathcal B=\sum_k\operatorname{Tr}(L_k^\dagger L_k)
\]
is now called a fixed Frobenius normalization throughout. It is not described
as dissipated power, heat, entropy production, relaxation time, trajectory
activity, or hardware cost. The abstract now leads with the two bounded
local/collective comparisons in which drive, input-step duration, dissipative
strength, and readout regularization are selected separately. Those
comparisons impose no cross-design strength equality: collective exceeds
selected uniform local loss by 29.6% on 24 held-out reservoirs. A
wider common grid brackets the selected collective strength, and a second
held-out ensemble gives a 28.7% gain, with 24/24 paired wins in each test.
These are the principal independently tuned result and its wider-grid held-out
confirmation. Both remain bounded computational comparisons rather than
equal-hardware-cost experiments.

The seven-design result is retained as a complementary controlled map. At
fixed \(\mathcal B\), collective loss gives 41% more STM than uniform local
loss at \(N=5\), with 32/32 paired wins. The manuscript now states at first
use that this number belongs only to that mathematical convention and is not
convention independent.

We also added two target-only checks to make the opposing forecasting result
interpretable. On the same 64 sealed 150-step continuations, the
training-mean prediction has MSE \(0.0599\) and the last-value prediction has
MSE \(0.1051\). Collective loss has MSE \(0.0969\): it is worse than the
training mean by \(0.0370\), with paired 95% interval
\([0.0188,0.0552]\), while its difference from the last-value prediction is
not resolved. Uniform local, unequal-local, pair, and thermal loss have lower
errors than both simple predictions, with pointwise descriptive intervals
that exclude zero. This check regenerates only deterministic target sequences
and does not rerun a reservoir.

For the central one-body lowering sector,
\(L_k=\sum_i A_{ki}\sigma_i^-\) and \(\Gamma=A^\dagger A\), the revised text
also records the exact identity
\[
\mathcal B=2^{N-1}\operatorname{Tr}\Gamma.
\]
Thus fixed \(\mathcal B\) fixes the total rate weight of the one-body decay
matrix for the local, unequal-local, collective, and interpolation families.
This sharpens the mathematical meaning of the normalization without turning it
into realized activity or experimental cost. Pair and exchange-jump terms and
dephasing operators have different raw Hilbert--Schmidt norms, so the identity
is not used to claim one common physical resource across all seven designs.

The revised manuscript now also shows how this matched total is distributed.
At \(N=5\), both uniform local and collective loss have
\(\mathcal B=80\) and \(\operatorname{Tr}\Gamma=5\). Uniform local loss has
five orthogonal one-body lowering combinations coupled to the bath, each with
decay-matrix eigenvalue \(1\). Collective loss has one bright collective
combination with eigenvalue \(5\), while four orthogonal lowering combinations
have zero direct bath coupling. This exact comparison requires no new
simulation. It makes clear why fixed \(\mathcal B\) isolates jump structure
without matching relaxation or operational cost.

We removed the nine-row alternative-matching table and the after-the-fact
replay from the main argument. We then attempted an operational comparison
whose rules were fixed before calibration. It uses the expected jump rate
integrated continuously along a driven input trajectory,
\[
\mathcal J=\frac{1}{n_{\mathrm{int}}\Delta t}
\sum_{t=1}^{n_{\mathrm{int}}}
\int_0^{\Delta t}\sum_k
\operatorname{Tr}[L_k^\dagger L_k\rho_t(\tau)]\,\mathrm d\tau .
\]
Eight task-independent pilot reservoirs set five common targets between
\(\mathcal J=0.3362\) and \(0.7662\) on local \([0.05,0.5]\) and collective
\([4,32]\) rate branches. The protocol required all \(240\) fresh
design--reservoir--target calibrations to satisfy the \(0.5\%\) reachability
criterion before selecting rates or computing a task score. A task-free
development branch crossed a low-rate collective turnover and produced no
readout fit or task score. A second, independent attempt on \([4,16]\) left
five of \(240\) collective calibration cases unreachable. Before that attempt
finished, one recovery rule had been recorded: retain all rules and the local
branch, double only the collective upper bound to \(32\), and use new pilot and
calibration seeds. No further adjustment was allowed.

That permitted recovery also failed the independent-reservoir reachability
criterion: 236 of 240 cases matched, while four local-loss cases could not
reach the highest fixed targets. No rate set was recorded, the STM
command was never run, and the manuscript reports no activity-matched task
effect or Pareto curve. This negative result directly tests driven-ensemble
matching feasibility rather
than relying on the removed initial-state and constant-midpoint proxies, but it
does not resolve an operational superiority claim. Time-averaged expected jump
rate also remains distinct from dissipated energy,
entropy production, bath power, or hardware cost, which would require an
explicit bath and thermodynamic or platform accounting model.

## 2. The Liouvillian-gap diagnostic was overclaimed

**Response: accepted and narrowed.**

The six non-dephasing-design points in the original diagnostic figure are now
described as a pattern measured after those designs were scored. The manuscript
no longer presents that pattern as validation of a general design rule.

The independent experiment remains useful but has a narrower interpretation.
Its rule was fixed before task scoring and tests a local-to-collective
interpolation at \(N=4,5\), with separate diagnostic and task seeds. The
six-point held-out order is reproduced at both sizes. However, both the mean
gap and STM are essentially monotone along the interpolation, and the endpoints
were known controls. The revision therefore calls this a **within-family rank
check chosen before task scoring**. It does not claim transfer to unrelated
jump families, discovery of a nonmonotonic optimum, or a general design rule.

The related-work discussion now credits prior work for the broader connection
between Liouvillian gaps and the echo-state property. Our distinctive
contribution is limited to the analytic dephasing result, the six-design
pattern measured after scoring, and the within-family check chosen before
scoring. A genuinely out-of-family test using orthogonal collective modes or
random low-rank jump families remains future work rather than an implied
completed validation.

## 4. The finite-size trend was too prominent

**Response: accepted and demoted.**

The trend has been removed from the abstract and from the headline-number
table. The scaling figure no longer highlights the fitted slope. The section is
renamed a finite-size robustness check, and the manuscript limits its positive
finite-size claim to collective remaining ahead at each tested size
\(N=4,\ldots,8\) under two fixed-strength conventions.

The original protocol has 30 seeds at \(N=4,\ldots,7\) and 20 at \(N=8\); the
variance-normalized control has eight fresh paired seeds per size. Neither
protocol retunes dissipative strength independently at each \(N\), and neither
supports an asymptotic law. More importantly, the collective--local gap
separation narrows and does not track the per-size STM differences. The single
slowest mode therefore does not explain the observed finite-\(N\) pattern. The
full slow-mode spectrum, observable overlap, and effective dimension are
now stated as open mechanism tests rather than conclusions.

## 5. The measurement factor largely reflects generic grouping

**Response: accepted for the factor; the reordering result is retained.**

At nominal state-preparation count \(N_{\mathrm{prep}}=45q\), the independent model uses \(q\) samples per
feature, while each grouped product-basis setting receives \(15q\) shared
bitstrings. Grouping therefore supplies approximately 15-fold feature-level
sample reuse. The two-grid-position separation on the fourfold grid, whose
tested coordinates differ by a factor near 16, is consistent with this generic
reuse and has been removed from headline status. It is not presented as a
dissipator-specific advantage, a continuous threshold, or a hardware-cost
factor.

The design-specific observation is that finite-sample readout changes the
relative ordering: pair and unequal-local loss have the largest descriptive
means at smaller preparation counts, whereas collective emerges only at larger
counts. All finite-sample inference retains Bonferroni-simultaneous bands over the complete
210-contrast family, and mean-winner labels remain descriptive unless every
relevant pairwise contrast is resolved. The manuscript also keeps the
limitations from omitted reset time, basis switching, trajectory replay,
detector error, drift, and wall-clock cost.

## Reproducibility access and input independence

**Response: clarified.**

The complete checksum-verified reproducibility archive is supplied with the
submission and is included in the public repository at
<https://github.com/eybmits/qrc-dissipation-engineering>. Its stored artifacts
reproduce the principal local--collective comparisons and the reported tables
and figures. Referees therefore receive the archive directly and do not need
special repository access.

The Methods now also state the input design in one sentence. Each reservoir
seed generates its own coupling matrix and input sequence. Within that seed,
all dissipative designs reuse the same couplings, inputs, targets, and data
split. The comparison is paired across designs, while different seeds test
different reservoirs and input sequences.

## Revised claim boundary

The revised paper supports the following summary:

> In the tested driven-spin model, independently selected collective loss is a
> robust short-term-memory specialist relative to independently selected
> uniform local loss within the declared bounded searches. A complementary
> fixed-Frobenius map shows a large structural contrast but is not a cost match.
> Gap-based ordering is supported only by a within-family check chosen before task scoring,
> finite-size results are per-size sensitivity checks, and finite-sample readout can
> reorder the descriptive means among the tested designs.

The revision does not claim a globally optimal dissipator, equal experimental
cost, activity-matched superiority, a general gap selector, a monotonic or
asymptotic scaling law, or a dissipator-specific 16-fold measurement advantage.
