# Uniform Hilbert--Schmidt contraction for the driven dephasing reservoir

## Result

The continuum-contraction condition used in the paper can be proved
analytically for the dephasing family in the implemented Hamiltonian protocol.
The proof does not rely on sampling five input values.  It applies to every
fixed input \(s\in[0,1]\), and compactness then makes the contraction constant
uniform over that interval.

The result is specific to the driven dephasing model and its nonzero transverse
single-qubit field.  It is not a theorem that every unital dissipator is
contractive.

## Setup

Let \(d=2^N\), equip \(M_d(\mathbb C)\) with the Hilbert--Schmidt inner product
\(\langle A,B\rangle=\operatorname{Tr}(A^\dagger B)\), and define

\[
\mathcal L_s(X)
=-i[H_s,X]
+\sum_{i=1}^N\gamma_i\bigl(Z_iXZ_i-X\bigr),
\qquad \gamma_i>0 .
\]

This is exactly the repository convention for Hermitian-unitary dephasing jumps
\(L_i=Z_i\): because \(Z_i^\dagger Z_i=I\),
\(\mathcal D[Z_i](X)=Z_iXZ_i-X\).  In the primary ensemble,

\[
H_s
=\sum_{i<j}J_{ij}X_iX_j
+h\sum_i Z_i
+h(1+s)\sum_i X_i ,
\qquad h>0,\quad s\in[0,1].
\]

The normalisation used in the experiments changes the positive numbers
\(\gamma_i\), but leaves every \(\gamma_i>0\).

## Lemma 1: exact Dirichlet identity, including factors

For \(X_t=e^{t\mathcal L_s}X\),

\[
\frac{\mathrm d}{\mathrm dt}\|X_t\|_2^2
=-\sum_{i=1}^N\gamma_i\|[Z_i,X_t]\|_2^2
\le 0 .
\tag{1}
\]

Indeed, the Hamiltonian commutator is skew-adjoint in the Hilbert--Schmidt
inner product, so its contribution to
\(2\operatorname{Re}\langle X_t,\mathcal L_sX_t\rangle\) vanishes.  For a
Hermitian unitary \(Z\),

\[
\operatorname{Re}\langle X,Z X Z-X\rangle
=-\frac12\|[Z,X]\|_2^2 .
\]

Multiplying by the factor \(2\) from differentiating the squared norm gives
Eq. (1).  Thus each one-step map is Hilbert--Schmidt non-expansive on all
operators, without any normality assumption on \(\mathcal L_s\).

## Lemma 2: equality over a nonzero time interval forces a scalar

Fix \(s\in[0,1]\) and \(t>0\).  Suppose
\(\|e^{t\mathcal L_s}X\|_2=\|X\|_2\).  Integrating Eq. (1) gives

\[
\sum_i\gamma_i\int_0^t
\|[Z_i,X_\tau]\|_2^2\,\mathrm d\tau=0 .
\]

The integrand is continuous and every rate is positive, so
\([Z_i,X_\tau]=0\) for all \(i\) and every \(\tau\in[0,t]\).
Consequently \(X_\tau\) is diagonal in the computational basis throughout the
interval.  At \(\tau=0\), the dephasing term vanishes.  Because the curve stays
inside the diagonal algebra, its derivative must be diagonal, whereas
\(-i[H_s,X]\) has zero diagonal for diagonal \(X\).  Therefore
\([H_s,X]=0\).

Write the diagonal entries of \(X\) as \(x_b\), indexed by bit strings
\(b\in\{0,1\}^N\), and let \(b^{(i)}\) denote \(b\) with bit \(i\) flipped.
The matrix element of the commutator between these two basis vectors is

\[
\langle b|[H_s,X]|b^{(i)}\rangle
=h(1+s)\bigl(x_{b^{(i)}}-x_b\bigr).
\]

The \(X_iX_j\) terms connect strings at Hamming distance two and cannot cancel
this Hamming-distance-one matrix element; the \(Z_i\) terms are diagonal.
Since \(h(1+s)>0\), commutation implies
\(x_b=x_{b^{(i)}}\) on every edge of the hypercube.  The hypercube is
connected, hence all \(x_b\) are equal and \(X\) is scalar.

It follows that every nonzero traceless \(X\) obeys the strict inequality

\[
\|e^{t\mathcal L_s}X\|_2<\|X\|_2 .
\tag{2}
\]

## Theorem: uniform contraction on the full input continuum

For the implemented dephasing reservoir and every step length
\(\Delta t>0\), there is a number \(\lambda<1\) such that

\[
\sup_{s\in[0,1]}
\left\|e^{\Delta t\mathcal L_s}
\big|_{\operatorname{Tr}=0}\right\|_{2\to2}
\le\lambda<1 .
\tag{3}
\]

To prove this, fix \(s\).  The unit sphere in the finite-dimensional traceless
subspace is compact, so the induced norm is attained.  Equation (2) excludes
equality for every vector on that sphere; therefore the induced norm is
strictly below one.  Next, \(s\mapsto\mathcal L_s\) is affine and the matrix
exponential is continuous, so

\[
\eta(s)=
\left\|e^{\Delta t\mathcal L_s}
\big|_{\operatorname{Tr}=0}\right\|_{2\to2}
\]

is continuous.  Its maximum on compact \([0,1]\) is attained, and every
pointwise value is below one.  Hence \(\max_s\eta(s)=\lambda<1\).

The dissipator is unital, so \(I/d\) is a fixed point for every \(s\).  For an
arbitrary switched input sequence,

\[
\left\|\rho_n-\frac{I}{d}\right\|_2
\le\lambda^n
\left\|\rho_0-\frac{I}{d}\right\|_2 .
\]

This proves uniform exponential collapse of the traceless state deviation
from \(I/d\) and of every bounded Pauli signal. It does **not**, by itself,
prove that a
scale-invariant normalized capacity converges continuously to zero at every
finite washout: an effectively unbounded linear readout can amplify an
arbitrarily small residual or propagation roundoff. The reported operational
STM zero also uses the capacity routine's near-constant-prediction guard
(denominator below \(10^{-30}\)); corrected parity instead uses the train-only
numerical feature floor documented in its protocol. That floor is above observed
propagation noise and far below the weakest retained active-channel feature.

## Coverage of the tested Hamiltonian ensembles

The proof only needs the graph of nonzero single-bit-flip matrix elements of
\(H_s\) to be connected for every allowed \(s\).  It therefore covers:

- the primary `xx_z_x` ensemble and the `xy_z_x` and `xx_ring` controls, where
  \(h(1+s)\sum_iX_i\) supplies every hypercube edge; and
- the `zz_x_z` control, where the input-independent term \(h\sum_iX_i\)
  supplies every hypercube edge.

The two-body couplings and their random values are irrelevant to this
connectivity argument.

## Exact assumptions and failure modes

The proof uses all of the following:

1. every local dephasing rate is strictly positive;
2. input is Hamiltonian-only and held fixed within each step;
3. the single-bit-flip graph of \(H_s\) is connected for every allowed input;
4. the Hilbert--Schmidt norm and a finite-dimensional reservoir are used; and
5. \(\Delta t>0\).

If the transverse field is removed, if a dephasing rate vanishes and
connectivity is lost, or if an input value makes all single-flip amplitudes
zero, diagonal traceless invariant operators may survive and strict contraction
need not hold.  The argument also does not cover reset encodings or
input-dependent jumps.

Equation (3) establishes existence of a continuum contraction constant but
does not provide a useful closed-form numerical value for \(\lambda\).
Five-point singular-value calculations may still be reported as descriptive
rates for particular instances, but they are no longer the certificate.

## Verification

`tests/test_dephasing_contraction_proof.py` independently checks:

- the Dirichlet identity and its factor of one;
- the one-dimensional diagonal commutant for the implemented Hamiltonian; and
- strict contraction on the traceless subspace over a numerical input grid at
  small \(N\).
