# Nested prescreen stability audit

This is a post-hoc descriptive sensitivity audit of the two realized cheap-screen reservoirs. It does not remedy the two-seed prescreen limitation, enlarge calibration, or supply selection-adjusted inference.

The complete realized common grid contains 176 configurations per method. Within each seed and configuration, the validation-best ridge was chosen before configs were ranked.

| Method | Frozen config ranks | In each top 8 | Top-8 overlap (I/U) | Jaccard | Full-rank Spearman |
|---|---:|:---:|---:|---:|---:|
| `B3_collective` | 2/3 | yes/yes | 5/11 | 0.455 | 0.953 |
| `CD_paper` | 1/1 | yes/yes | 5/11 | 0.455 | 0.955 |

Seedwise winners:

- `B3_collective`, seed 998585535: $(h,\Delta t,\mathrm{strength})=(0.25,1,16)$, ridge 0, validation MC 17.363181.
- `B3_collective`, seed 1004383068: $(h,\Delta t,\mathrm{strength})=(0.25,1,16)$, ridge 0, validation MC 18.144444.
- `CD_paper`, seed 998585535: $(h,\Delta t,\mathrm{strength})=(0.25,0.5,0.25)$, ridge 1e-08, validation MC 14.514969.
- `CD_paper`, seed 1004383068: $(h,\Delta t,\mathrm{strength})=(0.25,0.5,0.25)$, ridge 1e-06, validation MC 11.566047.

Claim boundary: agreement or disagreement here characterizes only the realized two-seed screening stage. The frozen operating points were selected later on the disjoint 12-reservoir calibration pool.

Deterministic payload SHA-256: `fe0a3eb17ba8e36cc88cd87e85fcd5086fc5e50f7291f4567327e80f6dac49e0`.
