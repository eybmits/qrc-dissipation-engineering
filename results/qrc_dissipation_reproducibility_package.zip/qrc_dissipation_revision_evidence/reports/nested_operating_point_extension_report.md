# Nested operating-point extension

## Protocol and completion

The sealed original prescreen and selection pools were reused only after byte-level source/protocol verification. The common local/collective prescreen was extended through x0.1, x0.25, x0.5, x1, x2, x4, x8, x16, x32, x64, x128. Both choices were frozen and hashed before a deterministic fresh 24-seed paired test ensemble was scored once.

- Prescreen coverage: 704/704 (512 reused, 192 new).
- Selection coverage: 204/204 (168 reused, 36 new).
- Fresh test coverage: 48/48.
- Protocol SHA-256: `1696169ac2b11c3bc832a562c1c0745a943ac1de555b5b7dab2e6f7d48275357`; selection SHA-256: `35406b3840f0abdb778e9d3c011eedb24e1775ae964a8ccb175667b675a23313`.

## Frozen choices

- Uniform local: $h=0.25$, $\Delta t=0.5$, strength x0.25, ridge 1e-06; selection MC 13.437258.
- Collective: $h=0.5$, $\Delta t=1$, strength x16, ridge 0; selection MC 17.832934.
- Collective bracket at the same $(h,\Delta t)$: x8 (16.899664), x16 (17.832934), x32 (16.273512).

## Fresh paired test

Collective minus local on the 24 fresh reservoirs: $\Delta C_{\mathrm{STM}}=3.945491$ (95% paired $t$ interval [3.522789, 4.368194]), 28.72%, 24/24 wins, exact two-sided sign $p=1.19209e-07$.

## New computation

- Prescreen: 192 jobs, 6658.0 CPU-s.
- Selection: 36 jobs, 3406.6 CPU-s.
- Fresh test: 48 jobs, 2231.8 CPU-s.
- Total new row runtime: 12296.5 CPU-s.

## Claim boundary

This brackets the selected collective strength within the declared common
grid and evaluates a second held-out paired test ensemble. The two designs use
the same search grid but select different strengths, so this is not an
equal-\(\mathcal B\) comparison. It remains a finite-grid, uniform-local versus
equal-coefficient-collective comparison, not unrestricted profile or
hardware-cost optimization.
