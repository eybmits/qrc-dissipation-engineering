# Collective-loss full-input stationary-spectrum diagnostic

**Status: PASS.** All declared numerical and integrity checks passed.

## Scope and protocol

This standalone additive diagnostic evaluates the primary $N=5$ collective-loss Liouvillian at $h=\Delta t=0.5$ with the matched local-loss Frobenius budget. It uses 10 fixed Hamiltonian instances from the existing washout-control seed set and 21 constant inputs $s=0,0.05,\ldots,1$.

For every one of the 210 seed/input cases, the complete 1,024-eigenvalue dense spectrum and right eigenvectors were computed. Six predeclared cases were also checked with an independently assembled sparse Liouvillian and shift-invert eigensolves near zero and the first decay mode.

**Interpretation boundary.** Finite-grid constant-input diagnostic only: positive sampled gaps and a unique sampled stationary mode do not prove a continuum lower bound or contraction under arbitrary switched-input sequences.

## Aggregate result

- Unique stationary mode: 210/210 sampled Liouvillians.
- Minimum sampled decay gap: 0.0502596919185 (seed 1965675192, $s=0.00$).
- Maximum sampled decay gap: 0.302238160142 (seed 1951374833, $s=1.00$).
- Mean sampled decay gap: 0.151000144727.
- Maximum positive-real-part leakage: 3.218e-14.
- Maximum dense all-mode relative eigenpair residual: 7.327e-13.
- Maximum trace-preservation relative residual: 0.000e+00.
- Maximum relative jump-budget error: 0.000e+00.

## Per-seed sampled interval

| seed | unique/grid | min gap (s) | max gap (s) | mean gap |
|---:|---:|---:|---:|---:|
| 518677875 | 21/21 | 0.154997907 (1.00) | 0.167786254 (0.00) | 0.158396857 |
| 1451336746 | 21/21 | 0.0519311767 (0.00) | 0.0878203222 (1.00) | 0.0680832717 |
| 198305900 | 21/21 | 0.0973681559 (0.00) | 0.144789441 (1.00) | 0.122703125 |
| 460255569 | 21/21 | 0.153256041 (0.00) | 0.239051792 (1.00) | 0.188310172 |
| 682143856 | 21/21 | 0.0985168971 (0.00) | 0.1307544 (1.00) | 0.117554111 |
| 664543175 | 21/21 | 0.104939545 (0.10) | 0.144088765 (1.00) | 0.116405237 |
| 1951374833 | 21/21 | 0.201248374 (0.20) | 0.30223816 (1.00) | 0.232232476 |
| 1716840368 | 21/21 | 0.19056284 (0.00) | 0.270905045 (1.00) | 0.232337062 |
| 1965675192 | 21/21 | 0.0502596919 (0.00) | 0.0728361385 (1.00) | 0.0624330869 |
| 2138468722 | 21/21 | 0.197445402 (0.00) | 0.235896367 (1.00) | 0.211546047 |

## Dense/sparse cross-checks

- Cases checked: 6; all found exactly one stationary mode among the near-zero shift-invert modes.
- Maximum dense/sparse Liouvillian entry difference: 0.000e+00.
- Maximum matched dense/sparse eigenvalue difference: 3.298e-09.
- Maximum sparse relative eigenpair residual: 4.336e-10.

## Integrity and reproduction

- Protocol SHA-256: `d7d1bff24b9c545eb97428ffbd55fb924aeabff1496d63c3e95ef072b59f8311`
- Protocol-file SHA-256: `c8c1ef538f1e53e3dfe24c19936be931be755248c4f316e2d752ec240f4464e0`
- Raw scientific-payload SHA-256: `2ff661f77d401f55c50d2286a65d0750579dcfa4c481441d665af80e58453c3e`
- Raw-file SHA-256: `d9c9db2d9a061d65f2c80019915efe4c31cfe280a7536b7ebfd90bebc16d124b`

```bash
PYTHONPATH=src:experiments python experiments/run_collective_loss_full_input_diagnostic.py verify
PYTHONPATH=src:experiments python experiments/run_collective_loss_full_input_diagnostic.py run --workers 4 --recompute
```
