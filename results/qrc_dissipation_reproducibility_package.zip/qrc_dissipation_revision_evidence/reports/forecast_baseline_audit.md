# Forecast baseline audit

## Scope

This post-hoc check adds two simple reference predictions to the sealed 150-step closed-loop Mackey--Glass task. It regenerates only the deterministic target sequences; it does not rerun a reservoir or select any model setting.

## Results

| model or simple prediction | mean MSE | standard error |
|---|---:|---:|
| training-mean prediction | 0.05988 | 0.00042 |
| last-value prediction | 0.10512 | 0.00846 |
| reset-encoded FN | 0.11535 | 0.00759 |
| uniform local | 0.03692 | 0.00294 |
| collective | 0.09688 | 0.00909 |
| unequal local | 0.03486 | 0.00279 |
| pair | 0.03865 | 0.00353 |
| thermal | 0.04622 | 0.00375 |
| exchange-assisted | 0.05177 | 0.00375 |
| dephasing | 0.05988 | 0.00042 |

Collective loss is worse than the training-mean prediction by 0.03700 MSE (paired 95% interval [0.01878, 0.05523]). Its difference from the last-value prediction is -0.00824 ([-0.03277, 0.01628]), so that comparison is not resolved.

Uniform local, unequal-local, pair, and thermal loss each have lower errors than both simple predictions, with pointwise descriptive 95% intervals that exclude zero. Dephasing matches the training-mean prediction seed by seed to numerical precision. Several reservoir forecasts therefore outperform these two constant predictions, whereas the collective memory advantage does not transfer to this 150-step closed-loop task at the fixed-map operating point.

## Reproduce

```bash
PYTHONPATH=src:experiments python experiments/forecast_baseline_audit.py
```
