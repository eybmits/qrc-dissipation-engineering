# Prospective activity-matching feasibility audit

Protocol `activity-matched-response-v3-2026-07-25` terminates as a complete
negative feasibility result, not as task-performance evidence. The protocol
attempted to match uniform-local and collective loss at five values of the
expected jump activity

\[
\mathcal J=\frac{1}{T\Delta t}\sum_{t=1}^{T}
\int_0^{\Delta t}\sum_k
\operatorname{Tr}[L_k^\dagger L_k\rho_t(\tau)]\,\mathrm d\tau
\]

on task-independent input streams. Every target, branch, seed namespace,
matching tolerance, and stop rule was frozen before any fresh calibration
row. No task target or task score enters this audit.

## Frozen sequence

The archived v1 development pilot used collective rates `[2,16]`; two of eight
collective curves crossed the assumed low-rate monotonic direction. It
produced no target freeze, fresh calibration, readout fit, or task score.

The disjoint v2 attempt used collective rates `[4,16]`. Its label-free fresh
calibration completed all 240 cells, but five collective cells were
unreachable. The mandatory calibration freeze failed, and no task score was
computed. Before that audit finished, the single permitted response-blind
recovery was recorded in
`reports/activity_matched_response_v2_recovery_plan.md`: retain every rule and
the local branch `[0.05,0.5]`, double only the failed collective upper bound to
give `[4,32]`, and use new pilot and task namespaces `505` and `506`. The rule
forbids a second extension, manual target adjustment, seed reuse, or task
scoring after another failed gate.

## v3 pilot and frozen targets

All 160 prespecified pilot rows completed: eight task-blind reservoirs, two
designs, and ten rates per design. Every local curve was monotone increasing
and every collective curve was monotone decreasing under the frozen
tolerances. The common endpoint-reachable activity interval was
`[0.321129310, 0.802130689]`, a span ratio of `2.497843282`.

After the predeclared five-percent logarithmic inset on each side, the pilot
froze five geometric targets before any fresh calibration:

`0.336169420`, `0.413057367`, `0.507530959`, `0.623612348`, and
`0.766243623`.

The eight pilot seeds and 24 fresh calibration seeds are mutually disjoint and
have no overlap with the 430 seeds sealed as prior evidence.

## Fresh calibration result

All \(2\times24\times5=240\) fresh calibration cells completed. Of these, 236
matched within the required relative error of at most `0.005`, and four local
cells were correctly censored as unreachable. All 120 collective cells
matched; 116 of 120 local cells matched.

| design | seed | target index | target activity | reachable interval at rates 0.05 and 0.5 |
|---|---:|---:|---:|---:|
| local | `1151836701` | 3 | `0.623612348` | `[0.077895767, 0.612529106]` |
| local | `1151836701` | 4 | `0.766243623` | `[0.077895767, 0.612529106]` |
| local | `220295615` | 4 | `0.766243623` | `[0.087628491, 0.734697774]` |
| local | `818925401` | 4 | `0.766243623` | `[0.084159669, 0.695135292]` |

Among the 236 matched cells, the maximum relative target error was
`0.004967649` and the maximum absolute error was `0.003801795`. Across all
fresh-calibration evaluations, the maximum trace error was `2.631e-12` and the
maximum imaginary activity residue was `7.262e-14`. No calibration curve
failed its monotonicity audit.

The mandatory command

`PYTHONPATH=src:experiments python experiments/run_activity_matched_response.py freeze-calibration`

rejected the completed calibration exactly as required:

`fresh calibration cannot be frozen: 4 calibration cells censored`

Consequently, `frozen_calibration.json` does not exist, the `score` command was
not run, no task-score checkpoint exists, and neither an aggregate nor a
Pareto curve was created. The strict evidence validator accepts this terminal
state as

`complete outcome-neutral feasibility failure: 4 of 240 calibration cells censored`.

## Interpretation and claim boundary

The result shows that the predeclared five-target operational comparison is
not feasible for all fresh reservoirs within the frozen v3 rate branches. It
does not show that activity matching is impossible under every possible rate
domain, target rule, input ensemble, or physical platform. Under the
precommitted no-further-recovery rule, however, those choices cannot now be
changed. The paper therefore makes no activity-matched STM claim and no
collective-versus-local Pareto-dominance claim.

Expected jump activity is operational for the declared gauge-fixed unraveling,
but it is not dissipated energy, entropy production, bath power, heat, or
hardware cost.

## Frozen provenance

- pilot manifest SHA-256:
  `2ed21080536a1081d96d45a809582f08a000a0d716de493171ee66107601f79f`;
- embedded pilot protocol SHA-256:
  `9dbcb1fe9e52d818514748577ed7a681be5f376f0d18349e37ed635c156f763a`;
- frozen-target file SHA-256:
  `0586458a449d642c6fee83f7640b111172bee9cc664240291911578c6928840d`;
- frozen pilot-row index SHA-256:
  `d7609e3edb7daa26e62d01f19145bfb74939bdfbb628228666666fb8b9843ee1`;
- task manifest SHA-256:
  `d5effd1bc8bb4ba6b120818f94862c18dbd185784497f4bfff099b9e54eac76b`;
- embedded task protocol SHA-256:
  `201a1da30be8b321840a69cb1f1f050c1629497208c81cfb77280a9ddb5a1f76`;
- source-snapshot manifest SHA-256:
  `15547a2ff5a520e81abe3664088fdd4ff9f074bbca3df57960e5ffcdff41a729`;
- frozen driver SHA-256:
  `d043d5d6327857336b02b3f85e6fcda59e88be986fc81b9046f3f61147fea3c4`;
- deterministic 160-file pilot index SHA-256:
  `707e3cf08a0c6968d062488694df3b130636324c56d6298ba8348ff3dc24b870`;
- deterministic 240-file calibration index SHA-256:
  `4bf8fec7ecee114302e4e87f78f47e442b403591b055830a3f77e0bc9c3995ab`.

The last two digests are SHA-256 hashes of canonical compact JSON arrays of
sorted `[relative path, file SHA-256]` pairs.
