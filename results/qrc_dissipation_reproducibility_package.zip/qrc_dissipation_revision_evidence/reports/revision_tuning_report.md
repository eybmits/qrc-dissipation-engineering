# Revision tuning and independence controls

These controls retain the paper's dissipation-engineering question while closing the channel-specific tuning, resource-matching, and same-ensemble validation gaps.

## Six-channel validation-selected ranking

For each held-out reservoir, strength is selected only from validation scores
on the other 19 reservoirs. The intervals below use a two-sided Bonferroni
correction over all 15 pairwise contrasts, but are descriptive conditional
summaries of the realised selections because the folds share calibration data.

| rank | channel | held-out STM MC ± SE | selected strengths |
|---:|---|---:|---|
| 1 | B3_collective | 14.173 ± 0.392 | `{'8.0': 20}` |
| 2 | B2_thermal | 11.865 ± 0.181 | `{'0.1': 20}` |
| 3 | B4_loss_exchange | 11.771 ± 0.164 | `{'0.1': 20}` |
| 4 | A1_heterogeneous | 11.389 ± 0.155 | `{'0.25': 20}` |
| 5 | CD_paper | 11.317 ± 0.175 | `{'0.25': 20}` |
| 6 | B5_pair | 11.113 ± 0.203 | `{'0.25': 20}` |

| collective minus | ΔMC | descriptive Bonferroni-adjusted interval |
|---|---:|---:|
| B2_thermal | +2.309 | [+0.874, +3.744] |
| B4_loss_exchange | +2.402 | [+0.989, +3.815] |
| A1_heterogeneous | +2.784 | [+1.349, +4.219] |
| CD_paper | +2.857 | [+1.383, +4.330] |
| B5_pair | +3.061 | [+1.441, +4.681] |

The collective validation optimum is bracketed at x8 between x4 and x16.
Every design selects the same multiplier in all 20 folds. The ordinary
all-pairs intervals are retained as descriptive summaries of the realised
selected-score vectors; the selection-aware sensitivity analysis below carries
the main uncertainty statement.

### Selection-aware bootstrap sensitivity

Because leave-one-reservoir-out folds share most of their selection data, the
Student-\(t\) intervals above are supplemented by a deterministic
selection-aware paired bootstrap. Each of 50,000 draws (seed `20260724`)
repeats strength selection, and strict duplicate exclusion removes every
bootstrap copy of the held-out reservoir from its selection pool. The resulting
Bonferroni-simultaneous 95% percentile-interval lower endpoints for collective
loss minus each competitor are:

| collective minus | selection-aware 95% lower endpoint |
|---|---:|
| B2_thermal | +0.826 |
| B4_loss_exchange | +0.927 |
| A1_heterogeneous | +1.300 |
| CD_paper | +1.361 |
| B5_pair | +1.412 |

All five lower endpoints remain positive. This is a sensitivity analysis that
propagates the shared selection step; it is not a substitute for a new
six-design experiment with completely disjoint calibration and test
reservoirs.

## Alternative dynamical matching

| channel | convention | reachable instances | scale | ΔMC vs nominal dial (95% paired CI) |
|---|---|---:|---:|---:|
| B3_collective | initial excitation-number loss | 32/32 | 1 | +3.572 [+3.365, +3.779] |
| B3_collective | driven Liouvillian gap | 0/32 | 40 | +0.201 [-0.640, +1.042] |
| B3_collective | steady-state jump activity | 1/32 | 1.73 | +3.966 [+3.597, +4.334] |
| B2_thermal | initial excitation-number loss | 32/32 | 1.3 | -1.051 [-1.133, -0.968] |
| B2_thermal | driven Liouvillian gap | 32/32 | 0.784 | +0.330 [+0.124, +0.536] |
| B2_thermal | steady-state jump activity | 32/32 | 0.662 | +0.693 [+0.577, +0.808] |
| B5_pair | initial excitation-number loss | 32/32 | 0.25 | +2.802 [+2.580, +3.024] |
| B5_pair | driven Liouvillian gap | 29/32 | 4.96 | +0.252 [+0.005, +0.498] |
| B5_pair | steady-state jump activity | 0/32 | 4.14 | -0.978 [-1.200, -0.756] |

Initial excitation-number loss-rate matching is exact. Collective driven-gap matching is unreachable within the stored x0.05–x40 search in 32/32 instances, and steady-state activity matching is exact in only 1/32. Those rows are therefore labeled closest-achievable boundary controls, not exact matches.

## Independently nested operating-point comparison

A common cheap screen only formed the shortlists. Final (h, dt, strength, ridge) choices used 12 independent full-length selection reservoirs and were evaluated once on 24 untouched reservoirs.

- B3_collective: selected (h, dt, multiplier)=`[0.5, 1.0, 16.0]`, ridge=0; untouched-test STM MC 17.893 ± 0.127.
- CD_paper: selected (h, dt, multiplier)=`[0.25, 0.5, 0.25]`, ridge=1e-06; untouched-test STM MC 13.806 ± 0.204.

Collective minus local on the 24 untouched reservoirs: ΔMC=4.087 [95% paired CI 3.630, 4.544], +29.6%, 24/24 wins, exact paired sign p=1.192e-07.

This comparison is selection/test disjoint but bounded by the frozen finite
candidate grids used for the screen and full-length selection stages. The two
channels retain uniform coefficients throughout: learned local rates and
learned collective coefficients are not included. It therefore supports the
best settings found within this declared search, not global optima or a fully
joint channel-and-profile optimization.

## Fixed-regime learned-profile comparison

A separate \(N=5\) channel-by-profile experiment compares learned local and
learned collective designs at the common fixed regime
\(h=0.5\), \(\Delta t=0.5\), \(\bar\gamma=1.5\), and ridge
\(10^{-8}\), under the same Frobenius normalization. Learned collective loss exceeds
learned local loss by \(\Delta{\rm MC}=0.662\), with 18/24 paired wins. The
Bonferroni-simultaneous 95% interval is [0.033, 1.292] over all ten pairwise
contrasts among the five reported profile cells.

This comparison establishes that the learned-versus-learned contrast remains
positive in that fixed regime. Profile searches use the experiment's declared
bounded optimization budget and are not combined with the disjoint
\((h,\Delta t,\text{strength},\text{ridge})\) search above. It therefore does
not establish a general priority of channel structure over spatial-profile
engineering.

## Frozen interpolation on a fresh reservoir ensemble

- N=4: frozen alpha=0.8 minus local ΔMC=1.781 [95% paired CI 1.555, 2.007], 24/24 wins, exact paired sign p=1.192e-07; frozen-gap versus fresh-score Spearman rho=1.000, exact 720-permutation p=0.002778.
- N=5: frozen alpha=0.8 minus local ΔMC=2.580 [95% paired CI 2.356, 2.804], 24/24 wins, exact paired sign p=1.192e-07; frozen-gap versus fresh-score Spearman rho=1.000, exact 720-permutation p=0.002778.

The 24 fresh task seeds have zero overlap with the 20 diagnostic seeds. This is an out-of-ensemble confirmation within the same local-to-collective operator interpolation; it is not presented as an out-of-family test.

## Reproducibility links

- `results/revision_tuning/strength_extension/six_channel_aggregate.json`: all-six ranking, raw rows, and source-row hashes.
- `results/revision_tuning/derived_simultaneous_inference.json`: all 15 simultaneous pairwise intervals and exact input-artifact hashes.
- `results/revision_tuning/critique_response_inference.json`: the 50,000-draw selection-aware tuning sensitivity, 210-contrast measurement bands, and all-ten channel-profile intervals.
- `results/revision_tuning/strength_extension/alternative_matching_aggregate.json`: operational matching curves, feasibility flags, and raw rows.
- `results/revision_tuning/nested_tuning/nested_tuning_results.json`: screen, selection, and untouched-test rows.
- `results/revision_tuning/fresh_interpolation/fresh_interpolation_results.json`: frozen diagnostics plus all fresh alpha-grid rows.
- `results/revision_tuning/strength_extension/source_snapshot/`, `results/revision_tuning/nested_tuning/source_snapshot/`, and `results/revision_tuning/fresh_interpolation/source_snapshot/`: byte-exact stage drivers with hash-linkage manifests.
- `experiments/revision_inference.py`: deterministic inference-only reconstruction from the sealed raw outputs.
