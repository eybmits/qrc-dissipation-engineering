# Activity-response development-branch audit

This is a label-free protocol-development record, not confirmatory evidence.
The first activity-only pilot used eight development seeds and rate branches
\([0.05,0.5]\) for local loss and \([2,16]\) for collective loss. It completed
all 160 expected pilot cells (80 per design), without constructing an STM
target, fitting a readout, freezing an activity target, calibrating a fresh
rate, or scoring a task.

The prespecified decreasing collective-response assumption failed at the low
end for two of eight seeds:

- seed `843087746`: activity increased from `1.233070339` at rate `2` to
  `1.235127283` at rate `2.593679109`;
- seed `1804079163`: activity increased from `1.270110575` at rate `2` to
  `1.280664316` at rate `2.593679109`.

The development branch therefore produced no frozen target or inferential
result. Before the confirmatory pilot, the collective branch was restricted to
\([4,16]\), where the response direction is prespecified as decreasing, and
both pilot and task namespaces were replaced (`503` and `504`). The
confirmatory source and protocol record this boundary explicitly.

Numerical checks on the discarded activity-only grid were benign: maximum
trace error `9.215e-13`, maximum imaginary activity residue `1.177e-13`, and
minimum interval-integrated activity `0.0420675`.

Archived provenance:

- 160 raw rows:
  `results/activity_matched_response_exploratory_branch_audit/pilot/checkpoints/`
- pilot manifest SHA-256:
  `8d3f4f912ba87fde176da3bb738f708613908c1f9a50928405308574b5df1471`
- frozen driver SHA-256:
  `b9fef8bb3d86c0eb6030553a444e1bbe34c9f86b4d55bd8020b5ebfc12b139b4`
- source-snapshot manifest SHA-256:
  `994676351ab5a6e55824a8a71a18b932cc8c56d8e8f2ff48c52542fad4529562`
