# v2 activity-response reachability audit

Protocol `activity-matched-response-v2-2026-07-25` is a failed prospective
feasibility attempt, not task evidence. Eight label-free pilot reservoirs
completed all 152 prespecified rate cells and froze five geometric activity
targets:

`0.470668127`, `0.525466696`, `0.586645308`, `0.654946775`, and
`0.731200389`.

The subsequent label-free calibration used 24 fresh reservoirs, both designs,
and all five targets. All 240 expected cells completed: 235 matched within the
declared calibration rule and five were correctly censored as unreachable.
All 120 local cells matched. The five censored collective cells were:

| seed | target index | target activity | reachable interval at rates 4 and 16 |
|---:|---:|---:|---:|
| `438121823` | 0 | `0.470668127` | `[0.489610690, 1.260696406]` |
| `1428615478` | 0 | `0.470668127` | `[0.643340452, 1.422934906]` |
| `1428615478` | 1 | `0.525466696` | `[0.643340452, 1.422934906]` |
| `1428615478` | 2 | `0.586645308` | `[0.643340452, 1.422934906]` |
| `1624233758` | 0 | `0.470668127` | `[0.520610718, 1.155032708]` |

The mandatory `freeze-calibration` command rejected the result with
`fresh calibration cannot be frozen: 5 calibration cells censored`.
Consequently, no frozen-calibration artifact or task-score checkpoint exists,
and no task response was computed or inspected. The one permitted,
outcome-blind recovery was frozen before calibration finished in
`reports/activity_matched_response_v2_recovery_plan.md`.

Archived provenance:

- pilot manifest SHA-256:
  `82d5b08f93f37d3a34c210c1a9fc0f2d02fa56b262595fbfd95e7319ecc6c631`;
- embedded pilot protocol SHA-256:
  `00088839fcc8b7fd238d3764c5cb5e0e88b08e3019092557cb0adba046a491d6`;
- frozen-target file SHA-256:
  `0652e6b0d3cbaa0506cf74d111711e29e56c837360559f5e57a687413ebc05b5`;
- task manifest SHA-256:
  `c648a6b7a6ece46f85e00e8fea2e4ac7910d6d4d4ae537419724f0422fe8b72e`;
- embedded task protocol SHA-256:
  `b0d3ddf3bd3cca1b6acbdb4369d6c75ce9d6b4cacadafc0f0be9d836814b2e60`;
- source-snapshot manifest SHA-256:
  `67131ee27c3ba0aac3895db0ee0e43d3cd6f4139e6daf0eb2b7c9baacb204b70`;
- frozen driver SHA-256:
  `39788860b635a102ee00e4fae0396092542c3cddc7db4c19dbab1b10d2cea2a7`;
- deterministic 152-file pilot bundle SHA-256:
  `a67cd1fc2d9c5b48b65dd408c36bedf0e003d6157e72221c09d7ecc8773e49fd`;
- deterministic 240-file calibration bundle SHA-256:
  `e8cf6f2de5d37611511ef5cb2d2e35d89195236bd12423e0d22ca35926e73385`.
