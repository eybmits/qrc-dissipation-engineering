# Focused revision controls

Protocol: `revision-controls-v1-2026-07-23`. This report is generated from atomic raw checkpoints; it does not replace the canonical paper protocol.

## 1. Parity regularisation control

Completion: **96/96** checkpoints (complete). The refit uses 750 rows for 676 fitted coefficients.

Ridge-boundary audit: zero selected in 83 rows (legitimate unregularised endpoint); maximum ridge selected in 0 rows; unresolved rising upper edges = 0.

Train-only feature filter: threshold=1.0e-12; global minimum retained active-feature std=6.085e-04; global maximum dropped std=—.

| rank | channel | n | selected capacity | fixed-1e-8 capacity | selected - fixed, 95% CI | selected - local, 95% CI |
|---:|---|---:|---:|---:|---:|---:|
| 3 | uniform local | 16 | 4.8223 | 4.0820 | +0.74 [+0.69, +0.79] | +0.00 [+0.00, +0.00] |
| 5 | unequal local | 16 | 4.3656 | 3.7155 | +0.65 [+0.60, +0.69] | -0.46 [-0.58, -0.33] |
| 2 | thermal | 16 | 4.8523 | 4.0309 | +0.82 [+0.73, +0.90] | +0.03 [-0.04, +0.10] |
| 6 | collective | 16 | 3.7821 | 3.1511 | +0.63 [+0.59, +0.66] | -1.04 [-1.12, -0.96] |
| 1 | loss + exchange | 16 | 5.0826 | 4.1478 | +0.93 [+0.83, +1.02] | +0.26 [+0.19, +0.32] |
| 4 | pair loss | 16 | 4.7518 | 4.0901 | +0.66 [+0.60, +0.72] | -0.07 [-0.14, +0.00] |

Per-seed winner counts across complete six-channel rankings: uniform local=1, unequal local=0, thermal=1, collective=0, loss + exchange=13, pair loss=1 (n=16).

Channels with a positive paired lower 95% bound versus uniform local loss: loss + exchange.

Interpretation rule: use the selected-ridge column for channel comparisons. The selected-minus-fixed interval tests whether the historical ridge materially affected each paired seed.

### Corrected parity reference rows

Completion: **32/32**. Global maximum dropped training-feature std=2.550e-16.

| reference | n | selected capacity | SE | selected - local, 95% CI |
|---|---:|---:|---:|---:|
| reset-unitary reference | 16 | 2.2951 | 0.1248 | -2.53 [-2.74, -2.33] |
| dephasing | 16 | 0.0000 | 0.0000 | -4.82 [-4.90, -4.75] |

## 2. Normalised-coupling scaling

Completion: **80/80** checkpoints (complete). Positive STM percentages favour collective loss; positive NARMA percentages mean lower collective NMSE.

Scaling ridge-boundary audit: zero selected in 12 fits; maximum ridge selected in 0 fits; unresolved rising upper edges = 0.

Scaling invariant audit: all passed = True; maximum relative jump-budget error = 0.000e+00.

### variance normalisation

| N | pairs | local STM | collective STM | collective - local, 95% CI | relative STM advantage, 95% CI | relative NARMA improvement, 95% CI |
|---:|---:|---:|---:|---:|---:|---:|
| 4 | 8 | 7.7706 | 10.0746 | +2.30 [+1.78, +2.77] | +29.69% [+22.77, +35.39]% | +31.17% [+21.82, +40.29]% |
| 5 | 8 | 8.4982 | 12.3385 | +3.84 [+3.34, +4.33] | +45.44% [+38.92, +52.34]% | +34.88% [+26.40, +43.65]% |
| 6 | 8 | 8.8989 | 13.8581 | +4.96 [+4.50, +5.40] | +55.86% [+50.26, +61.19]% | +44.08% [+36.71, +50.89]% |
| 7 | 8 | 9.3872 | 15.0070 | +5.62 [+5.00, +6.04] | +60.20% [+52.63, +66.10]% | +46.40% [+39.00, +52.70]% |
| 8 | 8 | 9.6949 | 15.6889 | +5.99 [+5.59, +6.46] | +61.98% [+57.16, +67.36]% | +51.26% [+44.97, +57.27]% |

Seed-level linear slope of relative STM advantage per added qubit: +7.93% [+6.21, +9.61]%.

## Claim boundary

- **Fixed-N claim:** N=5 is an exact anchor because both coupling multipliers equal one there. Its paired result is an independent fresh-seed replication of the structural comparison.
- **Trend claim:** growth with N is supported only when the paired seed-level slope interval excludes zero under a normalised coupling scheme. A positive point estimate alone is not described as a confirmed growth law.
- All seeds are disjoint from the 64-seed definitive-protocol pool, and every raw row contains coupling/input hashes.
