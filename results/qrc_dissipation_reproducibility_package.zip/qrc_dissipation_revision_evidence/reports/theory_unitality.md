# Unitality as a conditional screen in Hamiltonian-encoded QRC

## Claim boundary

For a Hamiltonian-encoded Lindblad reservoir,

\[
\mathcal L_s(\rho)=-i[H(s),\rho]+\sum_k\mathcal D[L_k](\rho),
\]

the dissipator is unital exactly when

\[
\mathcal D[I]=\sum_k[L_k,L_k^\dagger]=0.
\]

Unitality makes the maximally mixed state \(I/2^N\) a common fixed point for
every input. It does **not**, by itself, prove convergence to that state or
input blindness: invariant sectors, symmetries, or decoherence-free subspaces
can prevent strict contraction. Non-unitality is likewise not sufficient for
useful computation.

## What is proved for this repository

The dephasing family is the only unital channel in the reported comparison.
For its jumps \(L_i=\sqrt{\gamma_i}Z_i\), with every \(\gamma_i>0\), the
implemented transverse single-qubit field connects every edge of the
computational-basis hypercube for all allowed inputs. This additional structure
gives a model-specific theorem: every one-step map strictly contracts the
traceless Hilbert--Schmidt subspace, and compactness of the input interval makes
the contraction constant uniform over \(s\in[0,1]\).

Consequently, for the reported driven-dephasing protocol,

\[
\left\|\rho_n-\frac{I}{2^N}\right\|_2
\le \lambda^n
\left\|\rho_0-\frac{I}{2^N}\right\|_2,
\qquad \lambda<1,
\]

for every switched input sequence. Every bounded Pauli signal therefore
vanishes uniformly in absolute magnitude. This is an absolute-signal statement,
not a proof that a scale-invariant normalized capacity must be zero at every
finite washout when arbitrarily large readout gain is allowed. The reported
STM zero also uses the capacity routine's near-constant-prediction guard;
corrected parity instead uses the train-only precision floor documented in its
protocol. The full proof, exact assumptions, and regression
checks are in:

- `reports/dephasing_uniform_contraction_proof.md`
- `tests/test_dephasing_contraction_proof.py`

## Interpretation

The safe design rule is:

1. use unitality as an operator-only warning that an input-independent common
   fixed point exists;
2. establish contraction or exclude invariant sectors for the particular
   driven model before concluding input blindness; and
3. rank the surviving channels with model- and task-specific evidence.

This report intentionally makes no universal claim that a unital dissipator
cannot compute and no converse claim that a non-unital dissipator must compute.
