# Realized jump activity on the primary driven test trajectories

**Status:** deterministic descriptive/post-hoc sensitivity analysis.

This analysis replays the sealed 32-seed primary STM ensemble at $N=5$ and the fixed Frobenius jump-strength normalization. It uses the original 200 washout, 600 training, and 400 held-out test input intervals. No target, readout fit, validation choice, or task score enters the activity calculation.

For the declared jump unraveling, the instantaneous expected jump rate is

$$A(t)=\sum_k\gamma_k\,\mathrm{Tr}(L_k^\dagger L_k\rho(t)).$$

The reported value integrates this rate through each continuously evolved, piecewise-constant input interval and divides the total expected count by the held-out physical duration $400\times0.5=200$.

| design | mean activity | descriptive 95% t interval | ratio of means vs local | paired higher/lower count |
|---|---:|---:|---:|---:|
| uniform local | 1.481811256 | [1.440080318, 1.523542193] | 1.000000 | 0/0 |
| collective | 1.199200757 | [1.131670011, 1.266731503] | 0.809280 | 1/31 |
| unequal local | 1.242526750 | [1.169251820, 1.315801681] | 0.838519 | 0/32 |
| pair loss | 0.759593520 | [0.722209046, 0.796977994] | 0.512612 | 0/32 |
| thermal | 2.193823221 | [2.184545699, 2.203100742] | 1.480501 | 32/0 |
| loss + exchange | 2.212532512 | [2.199114859, 2.225950165] | 1.493127 | 32/0 |
| dephasing | 2.500000000 | [2.500000000, 2.500000000] | 1.687124 | 32/0 |

## Headline local--collective comparison

At the same Frobenius normalization, collective loss has a mean realized activity ratio of 0.809280 relative to uniform local damping. The mean paired activity difference is -0.282610499, with a descriptive 95% t interval [-0.330512458, -0.234708540] and 1/32 instances above local.

This quantifies whether the fixed Frobenius convention realizes the same environmental activity on the actual driven ensemble. It does **not** establish collective performance superiority after activity matching; that would require a separate, frozen rate-matching and fresh-test protocol.

## Reproducibility and numerical audit

- Sealed baseline archive SHA-256: `e24df615f8762ba9aa950673b5d776eddbc186a9ad277086c2930cde0ea46948`.
- Protocol SHA-256: `769584ad42bf8be8dbb11a2530ef99a27280a7dc7ed9bbd542ff6d14400a4d3a`.
- Source-environment SHA-256: `c23ddadf77f8c5aa86c812647b9cb615ea9cf6d266296df1d5118a06e3f468d1`.
- Coverage: 224/224 jobs.
- Maximum relative Frobenius-strength error: 3.553e-16.
- Maximum trace error: 1.870e-13.
- Maximum imaginary integration residue: 4.319e-16.
- Minimum interval-integrated activity: 2.779e-01.

## Limitations

- The analysis reuses the reported held-out STM test trajectories and is descriptive/post-hoc, not a fresh confirmatory test.
- It characterizes activity at fixed Frobenius normalization; it does not rerun task performance after matching activity.
- Jump activity is tied to the declared gauge-fixed jump unraveling and is not a generator-invariant cost.
- The density-matrix expectation is the mean jump count of that unraveling; no stochastic trajectories are sampled.
- It is neither dissipated energy nor entropy production; those require an explicit bath/thermodynamic model.

Raw per-method/per-seed checkpoints and the machine-readable aggregate are stored in `results/primary_driven_activity/`.
