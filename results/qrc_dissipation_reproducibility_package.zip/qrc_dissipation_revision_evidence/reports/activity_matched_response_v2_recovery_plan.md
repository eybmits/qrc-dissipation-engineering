# Frozen recovery rule after v2 reachability failure

**Frozen before any task score:** 25 July 2026.

The v2 activity-response protocol froze five targets from eight label-free
pilot reservoirs before calibrating 24 fresh reservoirs. During that
label-free calibration, collective seed `1428615478` reached activity
`0.643340452` at the prespecified upper rate `16`. It therefore could not
reach targets `0.470668127`, `0.525466696`, or `0.586645308`. These cells were
correctly written as `censored_target_unreachable`. At the time this recovery
rule was frozen, no task-score checkpoint existed.

The v2 branch is a failed prospective feasibility attempt and will never be
task-scored. Its label-free calibration may finish only to complete the
reachability audit; those additional values cannot alter the rule below.

## One permitted recovery

One v3 attempt is allowed:

- retain \(N=5\), \(h=\Delta t=0.5\), the calibration and task splits, the
  activity functional, five-target freeze rule, fixed ridge, inference, and
  all failure gates;
- leave the already feasible local branch unchanged at \([0.05,0.5]\), with
  anchor \(0.25\);
- double only the failing collective upper rate exactly once, from
  \([4,16]\) to \([4,32]\), retaining anchor \(8\);
- use new pilot and task namespaces `505` and `506`, disjoint from every v1/v2
  pool and all prior task evidence;
- rerun the activity-only pilot and freeze a new five-target common range
  before any v3 fresh calibration;
- require all \(2\times24\times5=240\) v3 calibration cells to be uncensored
  and within \(0.5\%\), then freeze their rates and hashes before any task
  score.

The raw rate domains need not be symmetric because the estimand equates
activity, not rate. Changing the already feasible local branch would add a
researcher degree of freedom and possible turnover without improving target
reachability. The one collective expansion is an outcome-blind response to its
endpoint failure and is not selected from STM performance. No second
extension, manual target adjustment, seed reuse, or further branch change is
permitted. If the v3 pilot or fresh calibration fails its existing gates, the
operational comparison is reported as infeasible within the declared recovery
and no STM dominance claim is made.

## Frozen v2 identifiers

- pilot manifest SHA-256:
  `82d5b08f93f37d3a34c210c1a9fc0f2d02fa56b262595fbfd95e7319ecc6c631`
- frozen-target file SHA-256:
  `0652e6b0d3cbaa0506cf74d111711e29e56c837360559f5e57a687413ebc05b5`
- task manifest SHA-256:
  `c648a6b7a6ece46f85e00e8fea2e4ac7910d6d4d4ae537419724f0422fe8b72e`
- embedded task-protocol SHA-256:
  `b0d3ddf3bd3cca1b6acbdb4369d6c75ce9d6b4cacadafc0f0be9d836814b2e60`
