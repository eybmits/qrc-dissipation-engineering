# Primary STM/NARMA readout-regularisation control

## Result

The isolated control completed all 224 paired jobs
(7 dissipators × 32 seeds), with
STM and NARMA-10 scored from every shared trajectory.  Every score uses the
frozen 200 wash / 450 train / 150 validation / 400 untouched test protocol.
Ridge selection uses validation only; both selected and fixed-1e-8 fits are
refitted on train+validation.  STM delay `d` retains its own `450-d` training
rows and `600-d` refit rows, exactly preserving the primary per-delay fits.

## STM capacity (delays 1–20)

Metric direction: **higher is better**.  The “selection improvement” column
is signed so positive always means validation-selected ridge improved on the
fixed-1e-8 result.

| Rank | Dissipator | selected-ridge test | fixed-1e-8 test | selection improvement |
|---:|---|---:|---:|---:|
| 1 | collective (`B3_collective`) | 12.2149 [95% CI 12.0105, 12.4193] | 12.2056 [95% CI 12.0002, 12.411] | 0.00927817 [95% CI -0.00235007, 0.0209064] |
| 2 | unequal local (`A1_heterogeneous`) | 9.8401 [95% CI 9.59776, 10.0824] | 9.8445 [95% CI 9.60189, 10.0871] | -0.00440054 [95% CI -0.0105911, 0.00179006] |
| 3 | pair loss (`B5_pair`) | 9.20041 [95% CI 9.03302, 9.3678] | 9.2033 [95% CI 9.0366, 9.37] | -0.00288728 [95% CI -0.0080612, 0.00228664] |
| 4 | uniform local (`CD_paper`) | 8.63083 [95% CI 8.49, 8.77166] | 8.63371 [95% CI 8.49222, 8.77521] | -0.00288288 [95% CI -0.00856294, 0.00279718] |
| 5 | thermal (`B2_thermal`) | 8.32295 [95% CI 8.20417, 8.44172] | 8.30668 [95% CI 8.18806, 8.42531] | 0.0162614 [95% CI 0.00134529, 0.0311775] |
| 6 | loss + exchange (`B4_loss_exchange`) | 7.58575 [95% CI 7.49036, 7.68113] | 7.41283 [95% CI 7.32046, 7.5052] | 0.172915 [95% CI 0.131468, 0.214361] |
| 7 | dephasing (`B1_dephasing`) | 2.67766e-31 [95% CI 2.27522e-31, 3.08011e-31] | 3.13179e-31 [95% CI 2.73661e-31, 3.52698e-31] | -4.54129e-32 [95% CI -8.74528e-32, -3.37309e-33] |

### Paired effects versus uniform local loss

The paired advantage is signed so positive always favours the listed method.

| Dissipator | paired method advantage | seed wins |
|---|---:|---:|
| collective (`B3_collective`) | 3.58403 [95% CI 3.37573, 3.79234] | 32/32 |
| unequal local (`A1_heterogeneous`) | 1.20927 [95% CI 1.00504, 1.4135] | 32/32 |
| pair loss (`B5_pair`) | 0.569579 [95% CI 0.361997, 0.777162] | 26/32 |
| thermal (`B2_thermal`) | -0.307885 [95% CI -0.387599, -0.228171] | 3/32 |
| loss + exchange (`B4_loss_exchange`) | -1.04509 [95% CI -1.17517, -0.915005] | 0/32 |
| dephasing (`B1_dephasing`) | -8.63083 [95% CI -8.77166, -8.49] | 0/32 |

Per-seed winner counts:
`{"A1_heterogeneous": 0, "B1_dephasing": 0, "B2_thermal": 0, "B3_collective": 32, "B4_loss_exchange": 0, "B5_pair": 0, "CD_paper": 0}`.

## NARMA-10 NMSE

Metric direction: **lower is better**.  The “selection improvement” column
is signed so positive always means validation-selected ridge improved on the
fixed-1e-8 result.

| Rank | Dissipator | selected-ridge test | fixed-1e-8 test | selection improvement |
|---:|---|---:|---:|---:|
| 1 | collective (`B3_collective`) | 0.233378 [95% CI 0.220624, 0.246132] | 0.229448 [95% CI 0.217042, 0.241855] | -0.0039296 [95% CI -0.00763492, -0.00022428] |
| 2 | unequal local (`A1_heterogeneous`) | 0.269556 [95% CI 0.255782, 0.28333] | 0.26594 [95% CI 0.25194, 0.279941] | -0.00361606 [95% CI -0.00800631, 0.000774193] |
| 3 | pair loss (`B5_pair`) | 0.294893 [95% CI 0.278572, 0.311213] | 0.288515 [95% CI 0.273432, 0.303597] | -0.00637802 [95% CI -0.0152359, 0.00247989] |
| 4 | uniform local (`CD_paper`) | 0.318076 [95% CI 0.301289, 0.334863] | 0.314597 [95% CI 0.298652, 0.330542] | -0.00347873 [95% CI -0.00946309, 0.00250564] |
| 5 | thermal (`B2_thermal`) | 0.339123 [95% CI 0.323502, 0.354744] | 0.336835 [95% CI 0.321252, 0.352419] | -0.0022879 [95% CI -0.00518294, 0.000607144] |
| 6 | loss + exchange (`B4_loss_exchange`) | 0.434835 [95% CI 0.413481, 0.456189] | 0.441401 [95% CI 0.423384, 0.459419] | 0.00656648 [95% CI -0.00193745, 0.0150704] |
| 7 | dephasing (`B1_dephasing`) | 1.03718 [95% CI 1.01443, 1.05992] | 1.02005 [95% CI 1.00839, 1.03171] | -0.0171327 [95% CI -0.0322648, -0.00200055] |

### Paired effects versus uniform local loss

The paired advantage is signed so positive always favours the listed method.

| Dissipator | paired method advantage | seed wins |
|---|---:|---:|
| collective (`B3_collective`) | 0.0846977 [95% CI 0.0699206, 0.0994747] | 32/32 |
| unequal local (`A1_heterogeneous`) | 0.0485194 [95% CI 0.0366193, 0.0604194] | 30/32 |
| pair loss (`B5_pair`) | 0.0231827 [95% CI 0.0078753, 0.0384901] | 24/32 |
| thermal (`B2_thermal`) | -0.0210472 [95% CI -0.0339106, -0.00818388] | 8/32 |
| loss + exchange (`B4_loss_exchange`) | -0.116759 [95% CI -0.135169, -0.0983487] | 0/32 |
| dephasing (`B1_dephasing`) | -0.719103 [95% CI -0.748963, -0.689244] | 0/32 |

Per-seed winner counts:
`{"A1_heterogeneous": 4, "B1_dephasing": 0, "B2_thermal": 0, "B3_collective": 25, "B4_loss_exchange": 0, "B5_pair": 3, "CD_paper": 0}`.


## Readout and integrity diagnostics

- Upper ridge boundary bracketed: **True**
  (32
  task/design/seed fits at ridge 100;
  `{"narma": 0, "stm": 32}`;
  0
  still improving at the boundary).
- Pairing, split, source, budget, and completeness audit:
  **True**.
- Fixed-1e-8 reproduction of the sealed primary table:
  **True**
  (384 active
  task/design/seed comparisons; maximum absolute differences
  `{"narma": 0.0, "stm": 1.4566126083082054e-13}`;
  64 guarded
  dephasing comparisons reported separately).

| Dissipator | jobs with guarded features | dropped-feature range |
|---|---:|---:|
| uniform local | 0/32 | 0–0 |
| collective | 0/32 | 0–0 |
| unequal local | 0/32 | 0–0 |
| pair loss | 0/32 | 0–0 |
| thermal | 0/32 | 0–0 |
| loss + exchange | 0/32 | 0–0 |
| dephasing | 32/32 | 45–45 |

The guard threshold was 1e-12, estimated on raw training rows
only; the bias was always retained.

## Runtime and provenance

- Sum of job runtimes: 1210.0 s
- Mean / maximum job runtime: 5.40 /
  17.98 s
- Protocol SHA-256: `d72ec65e561647f612c817e41735ec18840f2301ab136e72b2b8d3e5ecc517a3`
- Source-environment SHA-256: `f80e0597d244409b97d399b84676dd39c819cfd146b1d79bab66a3d4cb61121f`

Raw per-job checkpoints, protocol, and the machine-readable aggregate are in
`results/revision_primary_regularization/`.
