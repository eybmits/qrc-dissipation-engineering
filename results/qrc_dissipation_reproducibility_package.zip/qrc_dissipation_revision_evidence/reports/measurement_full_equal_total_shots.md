# Equal nominal sampling-budget measurement comparison

## Status

**Complete and validated.**  The final artifact is protocol
`measurement-full-v3-2026-07-23` in `results/measurement_full_v3/`.
It contains 120 atomic checkpoints and 1,920 raw score rows:

- \(N=5\);
- six active dissipator designs;
- 20 paired Hamiltonian/input seeds;
- independent-observable and grouped \(X/Y/Z\) measurement models;
- seven finite nominal sampling budgets plus the exact endpoint; and
- validation-selected regularisation for every
  seed/channel/model/budget combination.

The preliminary `measurement_full` result and v2 are superseded.  V2 correctly
failed its final QA because 26 low-budget fits selected the largest finite ridge.
V3 closes the grid with the analytic \(\lambda\to\infty\) correlation direction
instead of substituting another arbitrary finite ceiling.

## Protocol

There are 45 Pauli readout observables at \(N=5\).  Let \(q\) be the
independent-model nominal samples per observable.  At every reservoir time
step,

\[
B_{\rm independent}=45q,\qquad
B_{\rm grouped}=3(15q)=45q.
\]

Thus both models use the same nominal count \(B\) of state preparations.  The grouped
model draws joint bitstrings in the three all-\(X\), all-\(Y\), and all-\(Z\)
product bases and estimates every weight-one and same-axis weight-two
observable from the shared samples, retaining their covariance.  The
independent model draws an exact binomial estimate for every observable
separately.

The dynamics and task splits are washout 200, train 480, validation 120, and
test 400.  All 20 STM delays use the same aligned rows: the first 20 post-wash
rows are omitted from readout fitting.  Ridge selection maximises summed
validation capacity, after which the readout is refit on train plus validation
and scored once on test.  The candidate set is

\[
\lambda\in\{0,10^{-10},10^{-8},10^{-6},10^{-4},10^{-3},10^{-2},
10^{-1},1,10,10^2,10^3,10^4,\infty\}.
\]

For the last candidate, the prediction direction is evaluated analytically as
\(W\propto X^\mathsf{T}Y\), the \(\lambda\to\infty\) ridge limit up to an
irrelevant nonzero scale.  Squared-correlation capacity is invariant to this
scale.  A regression test verifies agreement with a very large finite ridge.

## Main result

Numbers are mean held-out STM capacity over 20 paired instances. For the seven
finite budgets, the displayed collective-minus-uniform-local intervals use a
two-sided Bonferroni correction over the complete family of 210 paired
contrasts: all 15 channel pairs, two measurement models, and seven budgets.
They therefore have simultaneous 95% familywise coverage for that finite-budget
family. The exact endpoint is outside the searched finite-budget family, is
identical between measurement models by construction, and retains its
pointwise 95% paired interval.

| nominal preparations \(B\) per time step | independent winner | independent local | independent collective | paired difference [95% band] | grouped winner | grouped local | grouped collective | paired difference [95% band] |
|---:|---|---:|---:|---:|---|---:|---:|---:|
| 2,880 | pair loss | 0.28 | 0.09 | -0.19 [-0.32, -0.07] | unequal local | 1.09 | 0.69 | -0.40 [-0.57, -0.23] |
| 11,520 | pair loss | 0.68 | 0.29 | -0.39 [-0.59, -0.20] | unequal local | 1.81 | 1.44 | -0.37 [-0.63, -0.12] |
| 46,080 | unequal local | 1.23 | 0.77 | -0.46 [-0.68, -0.24] | unequal local | 2.64 | 2.53 | -0.10 [-0.39, +0.18] |
| 184,320 | unequal local | 1.94 | 1.59 | -0.34 [-0.63, -0.05] | unequal local | 3.57 | 3.94 | +0.38 [+0.05, +0.71] |
| 737,280 | unequal local | 2.78 | 2.68 | -0.10 [-0.40, +0.21] | collective | 4.46 | 5.72 | +1.26 [+0.88, +1.63] |
| 2,949,120 | unequal local | 3.67 | 4.13 | +0.46 [+0.09, +0.83] | collective | 5.32 | 7.40 | +2.08 [+1.64, +2.52] |
| 11,796,480 | collective | 4.58 | 5.82 | +1.24 [+0.78, +1.70] | collective | 6.12 | 9.04 | +2.91 [+2.41, +3.42] |
| exact | collective | 8.56 | 12.24 | +3.67 [+3.41, +3.93] | collective | 8.56 | 12.24 | +3.67 [+3.41, +3.93] |

At the exact endpoint the complete ordering is:

| channel | mean test STM capacity | 95% interval for the mean |
|---|---:|---:|
| collective loss | 12.24 | [11.99, 12.49] |
| unequal local loss | 9.80 | [9.43, 10.16] |
| pair loss | 9.23 | [8.99, 9.46] |
| uniform local loss | 8.56 | [8.35, 8.78] |
| thermal loss | 8.28 | [8.10, 8.46] |
| loss plus exchange | 7.63 | [7.52, 7.75] |

## Interpretation

The measurement model changes the estimator-level design map even after
nominal state-preparation counts and regularisation selection are controlled.

- In the independent model, collective first beats uniform local with a
  simultaneous band excluding zero at \(B=2{,}949{,}120\), and first becomes
  the descriptive mean winner at \(B=11{,}796{,}480\).
- With grouped measurement, the first simultaneous collective-over-local
  point is \(B=184{,}320\), two positions below the independent point on the
  frozen fourfold grid; the two tested budgets differ by \(16\times\). This is
  a discrete-grid estimator comparison, not a fitted continuous or
  experimental crossover ratio. Collective first becomes the descriptive
  grouped mean winner at \(B=737{,}280\), but that argmax change is not treated
  as a second resolved threshold.
- Grouping improves collective capacity relative to the independent estimator
  in all 20 paired instances at every finite budget.  The mean grouped gains
  range from 0.61 [0.55, 0.67] at \(B=2{,}880\) to
  3.22 [3.13, 3.31] at \(B=11{,}796{,}480\). These cross-model intervals are
  separate pointwise descriptive summaries and are not members of the
  210-contrast channel-pair family.
- Pair loss is the low-budget mean winner only under independent measurement;
  unequal local loss is the low-budget mean winner under grouped measurement.
  Winner labels are descriptive mean rankings, not multiplicity-adjusted
  pairwise significance claims.

A “resolved local crossing” means the first tested grid point whose
collective-minus-uniform-local simultaneous band excludes zero. It is a
statement about the frozen discrete grid. No continuous threshold, uncertainty
interval for a threshold ratio, or between-grid interpolation is inferred.

This is a stronger and more operational statement than “sampling noise lowers
all channels”: **the useful dissipator depends jointly on the dynamical
structure and measurement architecture.**

## Ridge and numerical QA

- All 1,920 rows pass schema, finiteness, range, total-shot, exact-endpoint, and
  split checks.
- The \(\lambda\to\infty\) endpoint is selected in 26 rows, all in the
  independent model: 19 at \(B=2{,}880\), six at \(B=11{,}520\), and one at
  \(B=46{,}080\).  These are now closed endpoint selections rather than
  unbracketed finite-grid optima.
- One row selects finite \(\lambda=10^4\); it is bracketed on its right by the
  explicitly evaluated infinity endpoint.
- The maximum discrepancy between exact Pauli features and moments recovered
  from the grouped outcome probabilities is \(1.70\times10^{-15}\).
- The maximum trajectory trace error is \(2.67\times10^{-13}\).
- The maximum relative Frobenius-budget mismatch is
  \(3.56\times10^{-16}\).
- Every exact endpoint is identical between the two measurement models by
  construction and validation.

## Artifacts

- Driver: `experiments/run_measurement_full.py`
- Regression tests: `tests/test_measurement_full.py`
- Frozen protocol: `results/measurement_full_v3/protocol.json`
- Aggregate, raw rows, paired intervals, ridge counts, and winners:
  `results/measurement_full_v3/measurement_full_aggregate.json`
- Simultaneous 210-contrast finite-budget inference:
  `results/revision_tuning/critique_response_inference.json`
- Deterministic inference driver: `experiments/revision_inference.py`
- Atomic raw checkpoints: `results/measurement_full_v3/jobs/`
- Portable archive: `results/measurement_full_v3_results.tar.gz`
- Archive SHA-256:
  `b25131d42411232ceb9d8c3a1e1d24266240db76dd4af98b235d822c2b6d356c`

The archive checksum above must be regenerated if any v3 file is changed.

## Claim boundary

Equal \(B\) here means equal nominal state preparations per reservoir time
step. It excludes trajectory replay after destructive measurements,
basis-change latency, circuit reset and preparation time, detector bias,
readout mitigation, drift, correlated errors, and platform noise. It is
therefore not an experimental resource threshold. Each problem seed has one
deterministic measurement draw per model and budget; uncertainty is taken
across the 20 paired problem/measurement instances.

The exact v3 capacities use validation-selected regularisation and common
delay-aligned training rows.  Do not mix their absolute values with earlier
fixed-\(10^{-8}\) measurement curves without explicitly distinguishing the
protocols.
