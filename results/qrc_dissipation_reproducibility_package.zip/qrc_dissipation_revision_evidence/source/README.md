# Dissipator structure shapes what a quantum reservoir remembers

This repository contains the code, tests, raw numerical evidence, figures, and
canonical Quantum-format manuscript for:

> *Dissipator structure shapes what a quantum reservoir remembers*

The manuscript entry point is
[`paper/dissipation_qrc.tex`](paper/dissipation_qrc.tex), and the compiled paper
is [`paper/dissipation_qrc.pdf`](paper/dissipation_qrc.pdf). Build details and
the human submission checklist are in [`paper/README.md`](paper/README.md) and
[`paper/SUBMISSION.md`](paper/SUBMISSION.md).

## Handoff status

The rejection-level coauthor revision has completed local repository,
manuscript, and release-package QA. The frozen
prospective activity-matching audit terminated before task scoring, exactly as
required by its all-cells feasibility gate. The scientific revision is sealed
at commit `0e12030`; both submission archives verify and reproduce from fresh
extractions. The pre-revision `main` checkout was left untouched pending author
review and integration.
[`HANDOFF.md`](HANDOFF.md) records the scientific claim boundary, exact
evidence artifacts, reproduction commands, and restart path.

The repository does not certify coauthor approval, funding and conflict
declarations, journal or arXiv submission, reviewer-facing upload permissions,
or durable public archival. Those remain explicit human and external gates in
[`paper/SUBMISSION.md`](paper/SUBMISSION.md).

## Scientific contribution

Sannia *et al.*, Quantum **8**, 1291 (2024), established continuous uniform
local damping as a quantum-reservoir-computing resource and optimized its scalar
strength. This study asks the natural next question: how does performance change
when the jump-operator structure itself is engineered?

The paper maps the uniform-local reference and six engineered alternatives
(unequal local, collective, pair, exchange-assisted, thermal, and dephasing),
then separately studies learned damping profiles. Its central results are:

- in a bounded search over drive, input-step duration, dissipative strength, and
  ridge with separate screening, selection, and test ensembles, collective
  loss beats independently selected uniform local loss by 29.6% on 24 held-out
  reservoirs, with 24/24 paired wins. A wider common grid brackets the selected
  collective strength and reproduces a 28.7% gain on 24 new held-out
  reservoirs, again with 24/24 wins. These comparisons impose no
  cross-design strength equality and do not equate hardware cost;
- in a complementary seven-design structural map at fixed Frobenius
  normalization, collective loss provides 41% more short-term-memory capacity
  than uniform local loss at five qubits, with 32/32 paired wins. The
  normalization \(\sum_k\operatorname{Tr}(L_k^\dagger L_k)\) is a controlled
  mathematical convention, not power, heat, activity, relaxation time, or a
  platform cost. For the one-body lowering sector,
  \(\mathcal B=2^{N-1}\operatorname{Tr}\Gamma\), so it fixes the total
  one-body decay-matrix rate weight but not how that weight is distributed;
- a separate attempt calibrates uniform local and collective rates
  to five expected-jump-activity targets using task-independent inputs on 24
  new paired reservoirs. Of 240 calibration cases, 236 match and four local
  cases cannot reach the highest targets. The protocol therefore stops before
  selecting rates or scoring STM. No activity-matched superiority or Pareto
  curve is reported;
- repeating the complete seven-design STM and NARMA-10 map with a
  validation-selected ridge for every design, task, and reservoir preserves
  both mean orderings; the recomputed fixed-\(10^{-8}\) branch reproduces
  all 384 active-design task--seed scores. This reuses the reported primary
  test blocks and is therefore a post-hoc sensitivity control, not a fresh
  confirmatory ensemble;
- after every non-dephasing design receives its own validation-selected scalar
  strength at the primary Hamiltonian operating point, the ordinary paired
  intervals are descriptive because folds share calibration records. A
  deterministic 50,000-draw selection-aware bootstrap sensitivity check (seed
  20260724) that strictly excludes every duplicate of the held-out reservoir
  from selection leaves all five collective-contrast lower endpoints positive;
- in a separate fixed-regime channel-by-profile comparison, learned collective
  loss exceeds learned local loss by 0.662 capacity units, with 18/24 wins and
  an all-ten-contrast simultaneous 95% interval of [0.033, 1.292]; this is not
  a joint optimization over operating point, strength, ridge, and profile;
- the advantage is task-specific: collective loss is worse on parity and does
  not beat a training-mean prediction on the sealed 150-step forecast, while
  local, unequal-local, pair, and thermal loss have lower error than both
  simple forecast checks. A corrected validation-regularized parity protocol
  supports a smaller exchange-assisted gain;
- for the driven local-dephasing model, an analytic contraction result proves
  uniform exponential collapse of the traceless state deviation and Pauli
  signals over the complete continuous input interval; no universal claim is
  made for arbitrary unital channels;
- for collective loss, a separate frozen numerical scan resolves the complete
  1024-mode spectrum for ten Hamiltonians at 21 constant inputs: all 210
  generators have one numerical stationary mode and a positive gap. This is a
  finite-grid, fixed-input diagnostic, not a continuum or switched-input
  contraction proof;
- the six-design midpoint-gap pattern was measured after those designs were
  scored. A separate rule, chosen before task scoring, reproduces the complete
  six-point ordering on 48 independent reservoirs within a nearly monotone
  local-to-collective interpolation at four and five qubits. This supports
  ordering within that family, not a general design rule. The diagnostic uses
  only the representative midpoint input \(s=0.5\);
- at equal nominal sampling budgets, independent-observable and grouped
  three-setting measurement models can reorder the descriptive means among the
  tested dissipators even when every readout is validation-regularized.
  Bonferroni-simultaneous bands
  cover all 210 finite-budget design-pair/model/budget contrasts. Grouping
  supplies roughly 15-fold feature-level sample reuse, so its earlier
  collective--local resolution is generic estimator efficiency rather than a
  dissipator-specific factor; and
- two secondary fixed-strength finite-size protocols retain positive
  collective STM and NARMA effects at every tested size from four through eight
  qubits. Neither protocol retunes dissipative strength independently at each
  \(N\), the gap separation narrows, and no mechanistic, size-optimized, or
  asymptotic scaling claim is made.

The manuscript displays complete design-specific strength curves and reports
the failed five-target activity calibration as a negative feasibility audit.
It does not claim a globally optimal dissipator, a universal gap law,
hardware-independent superiority, or a complete joint optimization over
dissipator structure and learned spatial profiles.

## Verify and reproduce

Python 3.11 or newer and a standard LaTeX installation are recommended. The
Quantum class and bibliography style are bundled under `paper/`.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

PYTHONPATH=src:experiments python -m pytest -q
```

The deterministic reviewer evidence archive is built only from a clean,
committed tree and refuses incomplete or internally inconsistent result groups:

```bash
python scripts/build_revision_evidence_package.py build \
  --require-complete \
  --output results/qrc_dissipation_reproducibility_package.zip
python scripts/build_revision_evidence_package.py verify \
  --require-complete \
  results/qrc_dissipation_reproducibility_package.zip
python scripts/build_quantum_source_archive.py build
python scripts/build_quantum_source_archive.py verify \
  results/quantum_submission_source.zip
```

The evidence ZIP stores repository files under `source/` and the result groups
under sibling `results/`. After extracting it, run these commands from its
single top-level directory:

```bash
mkdir reproduction
cp -R source/. reproduction/
cp -R results reproduction/
cp -R reports reproduction/
cd reproduction
tar -xzf results/final_protocol_results.tar.gz -C results
tar -xzf results/review_protocol_results.tar.gz -C results
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
PYTHONPATH=src:experiments python -m pytest -q
PYTHONPATH=src:experiments python experiments/revision_inference.py
PYTHONPATH=src:experiments python \
  experiments/validate_revision_primary_regularization_artifacts.py
PYTHONPATH=src:experiments python \
  experiments/validate_collective_loss_full_input_artifacts.py
PYTHONPATH=src:experiments python \
  experiments/validate_nested_operating_point_artifacts.py
PYTHONPATH=src:experiments python \
  experiments/audit_nested_prescreen_stability.py validate
MPLCONFIGDIR=.mplconfig python paper/make_figures.py
cd paper
latexmk -pdf -interaction=nonstopmode -halt-on-error dissipation_qrc.tex
```

The figure generator recomputes empirical marks from raw per-job rows and fails
closed on incomplete revision artifacts. The evidence archive includes the
experiment drivers, exact seed lists, protocol manifests, stage-specific source
snapshots, raw checkpoints, aggregate results, reports, tests, and checksums.

## Repository map

```text
src/qrc/                    reservoir, Lindblad, task, readout, and diagnostics code
experiments/                checkpointed experiment and validation drivers
tests/                      automated physics, protocol, and packaging tests
results/*.tar.gz, *.zip     portable baseline and revision evidence archives
reports/                    current numerical and theorem reports
paper/sections/             canonical manuscript sections
paper/figures/              generated vector figures
paper/make_figures.py       fail-closed figure regeneration
paper/dissipation_qrc.tex   Quantum-format manuscript entry point
```

The code, stored results, manuscript source, and complete checksum-verified
reproducibility archive are available at
[eybmits/qrc-dissipation-engineering](https://github.com/eybmits/qrc-dissipation-engineering).
The same archive and its checksum sidecar are supplied with the submission so
that referee access does not depend on repository permissions.

## License

The software is available under the [MIT License](LICENSE). Publication and
preprint licensing for the manuscript, figures, and data must be selected by
the author during the arXiv and journal submission workflows.
