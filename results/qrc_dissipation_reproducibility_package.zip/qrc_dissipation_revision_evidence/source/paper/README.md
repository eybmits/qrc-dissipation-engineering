# Quantum manuscript

The canonical manuscript is
[`dissipation_qrc.tex`](dissipation_qrc.tex), built with the bundled
`quantumarticle` class and `quantum.bst`. The compiled submission PDF is
[`dissipation_qrc.pdf`](dissipation_qrc.pdf).

The retained [`dissipation_ieee.tex`](dissipation_ieee.tex) and
[`dissipation_ieee.pdf`](dissipation_ieee.pdf) are a legacy alternate layout,
not the canonical submission source.

## Build

From this directory:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error dissipation_qrc.tex
```

`latexmk` runs BibTeX against [`references.bib`](references.bib) and performs
the required LaTeX passes. A successful final build must have no undefined
references, missing citations, overfull boxes, or Type 3/unembedded figure
fonts.

To rebuild the figures first, run from the repository root after extracting the
reviewer evidence and baseline archives:

```bash
PYTHONPATH=src:experiments .venv/bin/python experiments/revision_inference.py
MPLCONFIGDIR=.mplconfig .venv/bin/python paper/make_figures.py
cd paper
latexmk -pdf -interaction=nonstopmode -halt-on-error dissipation_qrc.tex
```

The figure generator stops with an error if a revision aggregate is missing,
incomplete, hash-inconsistent, or lacks the required paired coverage.

## Figure inventory

| File | Manuscript role |
|---|---|
| `fig_designspace.pdf` | Scalar damping strength in prior work versus jump-family/profile structure here |
| `fig_map.pdf` | Fixed-Frobenius map across tasks and dissipative designs |
| `fig_budget.pdf` | Design-specific strength selection and held-out ranking |
| `fig_predict.pdf` | Dephasing diagnostic and six-design gap pattern measured after scoring |
| `fig_prospective.pdf` | Within-family rank check chosen before scoring and tested on independent data |
| `fig_shotmap.pdf` | Independent and grouped models at equal nominal preparation counts |
| `fig_scaling.pdf` | Original and variance-normalized system-size conventions |
| `fig_adaptive.pdf` | Static, learned, adaptive, and jump-family--profile controls |

The exact data sources, uncertainty conventions, and visual checks for each
figure are recorded in [`FIGURE_QA.md`](FIGURE_QA.md).

## Scientific validation

From the repository root:

```bash
PYTHONPATH=src:experiments .venv/bin/python -m pytest -q
PYTHONPATH=src:experiments .venv/bin/python experiments/revision_inference.py
PYTHONPATH=src:experiments .venv/bin/python \
  experiments/validate_revision_primary_regularization_artifacts.py
PYTHONPATH=src:experiments .venv/bin/python \
  experiments/validate_collective_loss_full_input_artifacts.py
PYTHONPATH=src:experiments .venv/bin/python \
  experiments/validate_nested_operating_point_artifacts.py
PYTHONPATH=src:experiments .venv/bin/python \
  experiments/audit_nested_prescreen_stability.py validate
.venv/bin/python scripts/build_quantum_source_archive.py build
.venv/bin/python scripts/build_quantum_source_archive.py verify \
  results/quantum_submission_source.zip
.venv/bin/python scripts/build_revision_evidence_package.py verify \
  --require-complete \
  results/qrc_dissipation_reproducibility_package.zip
```

The source builder allowlists the main TeX file, section files, bibliography,
generated `.bbl`, Quantum class/style, and exactly the eight included vector
figures. Its internal checksum manifest is verified before handoff.

The supplementary archive is allowlist-based and contains raw checkpoints,
protocol manifests, exact seed lists, stage-specific source snapshots, current
reports, tests, and SHA-256 manifests. It deliberately excludes superseded
measurement/prospective outputs and local build artifacts.

The local technical gate was completed on 26 July 2026: both archives verified,
the source ZIP compiled independently, and the evidence ZIP reconstructed a
runnable tree that passed the full tests, regenerated all eight figures, and
  rebuilt the manuscript. Remote synchronization, upload permissions, and
the human declarations below remain separate gates.

## Submission boundary

The technical package is designed for the Quantum/arXiv workflow, but final
submission requires the author's metadata and attestations. Complete
[`SUBMISSION.md`](SUBMISSION.md), including author order, ORCID, funding,
acknowledgements, conflicts, licensing, the arXiv `quant-ph` identifier, and
supplementary-file upload. The manuscript uses the final public repository URL:
<https://github.com/eybmits/qrc-dissipation-engineering>. Before submission,
switch the repository to public, push the final branch, and verify the link
from a logged-out session. Supply the verified evidence ZIP and checksum
sidecar directly to the referees as supplementary files; repository access
must not be their only route to the archive.
