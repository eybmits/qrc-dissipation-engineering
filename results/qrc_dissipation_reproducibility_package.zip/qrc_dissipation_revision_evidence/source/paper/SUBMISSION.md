# Quantum submission checklist

Canonical manuscript:

> *Dissipator structure shapes what a quantum reservoir remembers*

Quantum submissions use an arXiv identifier cross-listed to `quant-ph`. The
prepared deliverables are:

```text
qrc_dissipation_quantum_submission.pdf
quantum_submission_source.zip
qrc_dissipation_reproducibility_package.zip
qrc_dissipation_reproducibility_package.zip.sha256
SHA256SUMS.txt
```

The PDF and source use the bundled `quantumarticle` class. The source archive
contains the main TeX file, section files, bibliography, generated `.bbl`,
Quantum class/style files, and the eight used vector figures. The separate
evidence archive contains the simulation code, tests, raw checkpoints,
protocols, current reports, source snapshots, and internal checksums.

## Automated technical gate

All of the following must pass on the final committed state:

```bash
git diff --check
PYTHONPATH=src:experiments .venv/bin/python -m pytest -q
PYTHONPATH=src:experiments .venv/bin/python experiments/revision_inference.py
PYTHONPATH=src:experiments .venv/bin/python \
  experiments/validate_revision_primary_regularization_artifacts.py
PYTHONPATH=src:experiments .venv/bin/python \
  experiments/validate_collective_loss_full_input_artifacts.py
PYTHONPATH=src:experiments .venv/bin/python \
  experiments/validate_nested_operating_point_artifacts.py
PYTHONPATH=src:experiments .venv/bin/python \
  experiments/audit_nested_prescreen_stability.py validate
MPLCONFIGDIR=.mplconfig .venv/bin/python paper/make_figures.py
(cd paper && latexmk -pdf -interaction=nonstopmode -halt-on-error \
  dissipation_qrc.tex)
.venv/bin/python scripts/build_quantum_source_archive.py build \
  --output results/quantum_submission_source.zip
.venv/bin/python scripts/build_quantum_source_archive.py verify \
  results/quantum_submission_source.zip
.venv/bin/python scripts/build_revision_evidence_package.py build \
  --require-complete \
  --output results/qrc_dissipation_reproducibility_package.zip
.venv/bin/python scripts/build_revision_evidence_package.py verify \
  --require-complete \
  results/qrc_dissipation_reproducibility_package.zip
```

In addition:

- [x] Fresh-extract the source ZIP and compile it without repository files.
- [x] Fresh-extract the evidence ZIP. From its single top-level directory,
      create `reproduction/`, copy `source/.`, `results/`, and `reports/` into
      it, extract both baseline archives with `-C reproduction/results`, install
      `requirements.txt`, run the full tests, regenerate all eight figures,
      and compile the manuscript. The generated archive README gives the exact
      commands.
- [x] Confirm all citations and references resolve and the LaTeX log has no
      overfull boxes or missing files.
- [x] Confirm every PDF font is embedded and there are no Type 3 fonts.
- [x] Inspect every standalone figure and every rendered manuscript page at
      publication scale.
- [x] Verify the local SHA-256 sidecars and manifests against the generated
      files. Repeat this check after any external upload.
- [ ] Make `https://github.com/eybmits/qrc-dissipation-engineering` public,
      push the final committed branch, and verify logged-out access to the
      source and complete evidence archive.
- [ ] Open the uploaded evidence ZIP and checksum sidecar through the same
      reviewer-facing link or portal permissions that reviewers will receive.
- [ ] Confirm the Git working tree is clean and the public remote branch is
      synchronized.

## Human-only declarations

These cannot be inferred or completed by an agent:

- [ ] Confirm the complete author list and order, corresponding author, email,
      affiliations, and ORCID iDs.
- [ ] Confirm the author-contribution statement and approval of the submitted
      version by every author.
- [ ] Add exact funding bodies, grant identifiers, acknowledgements, and any
      required institutional/facility wording. State “no specific funding” only
      if true.
- [ ] Confirm the competing-interest declaration.
- [ ] Review and approve the manuscript's AI-tools disclosure.
- [ ] Select the appropriate arXiv and journal licences.
- [ ] Confirm the manuscript is not published elsewhere and is not under
      consideration by another journal.

## Submission actions

- [ ] Upload the source package to arXiv, complete its metadata/declarations,
      cross-list to `quant-ph`, and resolve any arXiv TeX warnings.
- [ ] Record the resulting arXiv identifier in the Quantum submission form.
- [ ] Copy the title, abstract, authors, and affiliations from the final PDF,
      not from an older draft.
- [ ] Upload the checksum-verified evidence ZIP and its sidecar as
      supplementary material.
- [ ] Confirm that referees received the complete evidence ZIP and checksum
      sidecar, and that the public repository contains the identical archive.
- [ ] Check the generated journal proof and supplementary-file links before
      final confirmation.

The manuscript now uses the final public-release wording. At the time of this
checklist update, repository visibility is still an external release step.
Do not submit the manuscript until the repository URL and complete archive
work from a logged-out browser. Referees must also receive the evidence ZIP
and checksum sidecar directly through the journal workflow.
