"""Regenerate the publication figures from the archived per-instance JSON.

Run from the repository root (or anywhere):

    python3 paper/make_figures.py

The figures use embedded TrueType fonts, a shared color/marker vocabulary, and
explicit paired uncertainty.  No paper number is hard-coded: every empirical
mark is recomputed from the canonical baseline archives or the sealed revision
artifacts under ``results/``.
"""
from __future__ import annotations

import glob
import json
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Rectangle
import numpy as np
from scipy import stats


HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
FINAL_DIR = os.path.join(ROOT, "results", "final_protocol")
REVIEW_DIR = os.path.join(ROOT, "results", "review_protocol")
REVISION_TUNING_DIR = os.path.join(ROOT, "results", "revision_tuning")
REVISION_PROSPECTIVE = os.path.join(
    REVISION_TUNING_DIR,
    "fresh_interpolation",
    "fresh_interpolation_results.json",
)
REVISION_MEASUREMENT = os.path.join(
    ROOT, "results", "measurement_full_v3", "measurement_full_aggregate.json"
)
REVISION_PARITY = os.path.join(
    ROOT, "results", "revision_parity_control", "paper_aggregate.json"
)
REVISION_SCALING = os.path.join(
    ROOT,
    "results",
    "revision_normalized_scaling",
    "paper_variance_aggregate.json",
)
OUTDIR = os.path.join(HERE, "figures")

# Quantum embeds vector figures.  Type 42 keeps text searchable and prevents
# Matplotlib's default Type 3 glyph outlines.
plt.rcParams.update(
    {
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "font.family": "DejaVu Sans",
        "mathtext.fontset": "dejavusans",
        "font.size": 9.2,
        "axes.titlesize": 9.8,
        "axes.labelsize": 9.2,
        "legend.fontsize": 8.6,
        "xtick.labelsize": 8.8,
        "ytick.labelsize": 8.8,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.linewidth": 0.75,
        "lines.linewidth": 1.6,
        "figure.dpi": 220,
        "savefig.dpi": 300,
    }
)

INK = "#20242A"
MUTED = "#6B7280"
GRID = "#D8DEE7"
PAPER = "#FFFFFF"
BLUE = "#0072B2"
SKY = "#56B4E9"
GOLD = "#E69F00"
ORANGE = "#D55E00"
GREEN = "#009E73"
PURPLE = "#7B61A8"
OLIVE = "#827717"

# Stable method semantics across all empirical figures.  Every line also has a
# non-color encoding, so the set remains readable in grayscale.
C = {
    "CD_paper": MUTED,
    "B3_collective": BLUE,
    "A1_heterogeneous": GOLD,
    "B5_pair": ORANGE,
    "B4_loss_exchange": GREEN,
    "B2_thermal": OLIVE,
    "B1_dephasing": INK,
    "FN": PURPLE,
}
MARKER = {
    "CD_paper": "D",
    "B3_collective": "o",
    "A1_heterogeneous": "s",
    "B5_pair": "^",
    "B4_loss_exchange": "v",
    "B2_thermal": "P",
    "B1_dephasing": "X",
    "FN": "^",
}
LINESTYLE = {
    "CD_paper": "-",
    "B3_collective": "-",
    "A1_heterogeneous": "--",
    "B5_pair": "-.",
    "B4_loss_exchange": ":",
    "B2_thermal": (0, (5, 2, 1, 2)),
    "B1_dephasing": ":",
    "FN": "--",
}
LABEL = {
    "CD_paper": "uniform local loss",
    "B3_collective": "collective loss",
    "A1_heterogeneous": "unequal rates",
    "B5_pair": "pair loss",
    "B4_loss_exchange": "exchange loss",
    "B2_thermal": "thermal loss",
    "B1_dephasing": "dephasing",
    "FN": "reset-encoded FN",
}
HIGHER = {"stm": True, "narma": False, "parity": True, "mg": False}

_REVIEW_CACHE = None
_PARITY_CACHE = None


def _read_jsons(pattern: str) -> list[dict]:
    rows = []
    for path in sorted(glob.glob(pattern)):
        try:
            with open(path, encoding="utf-8") as handle:
                rows.append(json.load(handle))
        except (OSError, json.JSONDecodeError):
            continue
    return rows


def load() -> list[dict]:
    """Load canonical results, replacing the superseded forecasting cells."""
    rows = _read_jsons(os.path.join(FINAL_DIR, "*.json"))
    rows = [
        row
        for row in rows
        if not (row.get("block") == "A_table" and row.get("task") == "mg")
    ]
    for row in _read_jsons(os.path.join(REVIEW_DIR, "R_mgfix__*.json")):
        row = dict(row)
        row["block"] = "A_table"
        rows.append(row)
    return rows


def load_review() -> list[dict]:
    global _REVIEW_CACHE
    if _REVIEW_CACHE is None:
        _REVIEW_CACHE = _read_jsons(os.path.join(REVIEW_DIR, "*.json"))
    if len(_REVIEW_CACHE) < 3000:
        raise SystemExit(
            "ERROR: results/review_protocol is missing or incomplete "
            f"({len(_REVIEW_CACHE)} rows). Extract the archived raw data first."
        )
    return _REVIEW_CACHE


def load_revision_parity() -> dict[str, dict[int, float]]:
    """Load the leak-free, validation-selected parity comparison.

    The six active channels and the two reference rows are hash-linked but
    deliberately stored as separate protocols because FN is not a Lindblad
    channel and dephasing is a negative control.
    """
    global _PARITY_CACHE
    if _PARITY_CACHE is not None:
        return _PARITY_CACHE

    result_dir = os.path.dirname(REVISION_PARITY)
    reference_aggregate_path = os.path.join(
        result_dir, "paper_reference_aggregate.json"
    )
    for path in (REVISION_PARITY, reference_aggregate_path):
        if not os.path.isfile(path):
            raise SystemExit(f"ERROR: missing corrected parity artifact {path}")
    with open(REVISION_PARITY, encoding="utf-8") as handle:
        active = json.load(handle)
    with open(reference_aggregate_path, encoding="utf-8") as handle:
        references = json.load(handle)

    expected = (
        (active, 96, 96),
        (references, 32, 32),
    )
    for aggregate, checkpoints, raw_rows in expected:
        if (
            aggregate.get("status") != "complete"
            or int(aggregate.get("expected_checkpoints", -1)) != checkpoints
            or int(aggregate.get("complete_checkpoints", -1)) != checkpoints
            or aggregate.get("missing_checkpoints")
            or len(aggregate.get("raw_rows", [])) != raw_rows
            or aggregate.get("ridge_boundary_audit", {}).get(
                "n_unresolved_upper", -1
            )
            != 0
        ):
            raise SystemExit("ERROR: corrected parity aggregate is incomplete")
    if references.get("active_protocol_sha256") != active.get("protocol_sha256"):
        raise SystemExit(
            "ERROR: corrected parity reference rows are not linked to the "
            "active-channel protocol"
        )

    rows = [*active["raw_rows"], *references["raw_rows"]]
    methods = {
        "FN",
        "CD_paper",
        "B3_collective",
        "A1_heterogeneous",
        "B5_pair",
        "B2_thermal",
        "B4_loss_exchange",
        "B1_dephasing",
    }
    out = {
        method: {
            int(row["seed"]): float(row["selected_test_capacity"])
            for row in rows
            if row.get("method") == method and row.get("status") == "complete"
        }
        for method in methods
    }
    if any(len(values) != 16 for values in out.values()):
        counts = {method: len(values) for method, values in out.items()}
        raise SystemExit(f"ERROR: corrected parity rows are incomplete: {counts}")
    common_seeds = {tuple(sorted(values)) for values in out.values()}
    if len(common_seeds) != 1:
        raise SystemExit("ERROR: corrected parity rows are not fully paired")
    _PARITY_CACHE = out
    return out


def map_cell(
    rows: list[dict],
    task: str,
    method: str,
) -> dict[int, float]:
    if task == "parity":
        return load_revision_parity()[method]
    return cell(rows, "A_table", task, method, N=5)


def cell(
    rows: list[dict],
    block: str,
    task: str,
    method: str,
    N: int | None = None,
    **match,
) -> dict[int, float]:
    out = {}
    for row in rows:
        if (
            row.get("block") != block
            or row.get("task") != task
            or row.get("method") != method
            or row.get("value") is None
        ):
            continue
        if N is not None and row.get("N") != N:
            continue
        if any(row.get(key) != value for key, value in match.items()):
            continue
        out[row["seed"]] = float(row["value"])
    return out


def t_summary(values) -> dict:
    values = np.asarray(list(values), dtype=float)
    n = len(values)
    if n == 0:
        return {"n": 0, "mean": np.nan, "lo": np.nan, "hi": np.nan}
    mean = float(values.mean())
    if n == 1:
        return {"n": 1, "mean": mean, "lo": mean, "hi": mean}
    half = float(
        stats.t.ppf(0.975, n - 1) * values.std(ddof=1) / np.sqrt(n)
    )
    return {"n": n, "mean": mean, "lo": mean - half, "hi": mean + half}


def paired_summary(
    a: dict[int, float],
    b: dict[int, float],
    higher_better: bool = True,
    percent: bool = False,
) -> dict:
    """Paired effect ``a-b``; positive always favors ``a``."""
    shared = sorted(set(a) & set(b))
    if not shared:
        return {
            "n": 0,
            "mean": np.nan,
            "lo": np.nan,
            "hi": np.nan,
            "raw": np.array([]),
        }
    direction = 1.0 if higher_better else -1.0
    diff = direction * np.array([a[seed] - b[seed] for seed in shared], float)
    scale = 1.0
    if percent:
        baseline_mean = np.mean([b[seed] for seed in shared])
        scale = 100.0 / baseline_mean
    summary = t_summary(diff * scale)
    summary["raw"] = diff
    summary["shared"] = shared
    return summary


def signflip_permutation_p(diff: np.ndarray, n_resamples: int = 100_000) -> float:
    """Two-sided sign-flip test on the paired mean.

    The exact distribution is counted by meet-in-the-middle enumeration for
    n<=32. Larger samples use the deterministic 100,000-resample policy
    documented in the manuscript.
    """
    diff = np.asarray(diff, dtype=float)
    n = len(diff)
    if n == 0 or np.allclose(diff, 0):
        return 1.0
    tolerance = 1e-12
    observed_sum = abs(float(diff.sum()))
    if n <= 32:
        def signed_sums(values: np.ndarray) -> np.ndarray:
            sums = np.array([0.0])
            for value in values:
                sums = np.concatenate((sums + value, sums - value))
            return sums

        split = n // 2
        left = signed_sums(diff[:split])
        right = np.sort(signed_sums(diff[split:]))
        threshold = observed_sum - tolerance * n
        if threshold <= 0:
            return 1.0
        below = np.searchsorted(right, -threshold - left, side="right")
        above = len(right) - np.searchsorted(
            right, threshold - left, side="left"
        )
        exceed = int(np.sum(below, dtype=np.int64) + np.sum(above, dtype=np.int64))
        return exceed / (1 << n)

    observed = observed_sum / n
    batch = 8192
    exceed = 0
    rng = np.random.default_rng(12345)
    for start in range(0, n_resamples, batch):
        size = min(batch, n_resamples - start)
        signs = rng.integers(0, 2, size=(size, n), dtype=np.int8)
        signs = 1 - 2 * signs
        permuted = signs @ diff / n
        exceed += int(np.count_nonzero(np.abs(permuted) >= observed - tolerance))
    return (exceed + 1) / (n_resamples + 1)


def holm_adjust(pvalues: dict[tuple, float]) -> dict[tuple, float]:
    ordered = sorted(pvalues.items(), key=lambda item: item[1])
    adjusted = {}
    running = 0.0
    m = len(ordered)
    for rank, (key, pvalue) in enumerate(ordered):
        running = max(running, min(1.0, (m - rank) * pvalue))
        adjusted[key] = running
    return adjusted


def interval_error(summary: dict):
    return np.array(
        [[summary["mean"] - summary["lo"]], [summary["hi"] - summary["mean"]]]
    )


def style_axis(ax, grid_axis: str = "y"):
    ax.set_axisbelow(True)
    ax.grid(axis=grid_axis, color=GRID, linewidth=0.65, alpha=0.8)
    ax.tick_params(width=0.75, length=3.5, color=INK)
    ax.spines["left"].set_color(INK)
    ax.spines["bottom"].set_color(INK)


def panel_title(ax, letter: str, title: str):
    ax.set_title(f"({letter}) {title}", loc="left", color=INK, weight="bold", pad=7)


def method_errorbar(ax, x, y, summary, method, **kwargs):
    return ax.errorbar(
        x,
        y,
        yerr=interval_error(summary),
        color=C[method],
        marker=MARKER[method],
        linestyle=LINESTYLE[method],
        markerfacecolor=PAPER if method in ("CD_paper", "FN") else C[method],
        markeredgecolor=C[method],
        markeredgewidth=1.0,
        capsize=2.2,
        elinewidth=1.0,
        **kwargs,
    )


def save(fig, filename: str):
    os.makedirs(OUTDIR, exist_ok=True)
    fig.savefig(
        os.path.join(OUTDIR, filename),
        facecolor=PAPER,
        metadata={"Creator": "paper/make_figures.py"},
    )
    plt.close(fig)


def fig_designspace():
    """Editorial design-space schematic annotated with the actual generators.

    The only non-empirical figure (see FIGURE_QA.md): panel (a) is a
    schematic curve; panel (b) carries every channel's jump-operator set
    under its column label, every profile's rate rule under its row label,
    a hatched learned/collective cell for the bounded 2x2 joint check, and
    a footer stating the shared Frobenius normalization and the 6 + 1 = 7 design
    accounting.  The editorial serif/cream style is scoped to this figure
    via rc_context so the seven empirical figures keep the shared style.
    """
    from matplotlib.gridspec import GridSpec
    from matplotlib.patches import Polygon

    BG = "#ffffff"
    INK_E = "#241f1a"
    GREY_E = "#8a7f70"
    RULE_E = "#b9ac99"
    A_, Af = "#3a4e7a", "#dfe3ee"  # channel sweep (uniform profile)
    B_, Bf = "#ab5327", "#f2ddcd"  # profile sweep (local loss)
    NULLF = "#f4efe6"

    FS_TITLE, FS_LAB, FS_TICK, FS_MATH, FS_CELL, FS_LEG, FS_FOOT = (
        8.4, 7.3, 6.6, 5.8, 5.9, 5.9, 5.4,
    )

    channel_items = [
        ("local", r"$\sigma_i^-$"),
        ("collective", r"$\sum_i c_i\,\sigma_i^-$"),
        ("pair", r"$\sigma_i^-\sigma_j^-$"),
        ("exchange", r"$\sigma_i^-,\ \sigma_i^-\sigma_j^+$"),
        ("thermal", r"$\sigma_i^-,\ \sigma_i^+$"),
        ("dephasing", r"$\sigma_i^z$"),
    ]
    profile_items = [
        ("uniform", r"$\gamma_i=\gamma$"),
        ("unequal", r"$\gamma_i\neq\gamma_j$"),
        ("learned", r"$\gamma_i$ fitted"),
        ("input-adaptive", r"$\gamma_i(s)$"),
    ]
    n_chan, n_prof = len(channel_items), len(profile_items)

    style = {
        "font.family": "serif",
        "font.serif": ["TeX Gyre Pagella", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "text.color": INK_E,
        "axes.labelcolor": INK_E,
        "axes.edgecolor": RULE_E,
        "xtick.color": INK_E,
        "ytick.color": INK_E,
        "axes.linewidth": 0.6,
        "xtick.major.width": 0.6,
        "xtick.major.size": 2.4,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "figure.facecolor": BG,
        "axes.facecolor": BG,
    }
    with plt.rc_context(style):
        fig = plt.figure(figsize=(6.77, 3.30))
        gs = GridSpec(
            1, 2, width_ratios=[1.0, 1.70], wspace=0.26,
            left=0.070, right=0.995, top=0.875, bottom=0.105,
        )

        # -------------------------------------------- (a) scalar rate
        ax = fig.add_subplot(gs[0, 0])
        g = np.linspace(0, 4.6, 700)
        y = np.where(g > 0, g ** 0.95 * np.exp(-g / 0.82), 0.0)
        y /= y.max()
        gopt = g[int(np.argmax(y))]

        ax.fill_between(g, 0, y, color=Af, alpha=0.95, lw=0, zorder=1)
        ax.plot(g, y, color=A_, lw=1.25, zorder=3)
        ax.axhline(0, color=RULE_E, lw=0.7, zorder=2)
        ax.plot([gopt], [1.0], "o", ms=4.2, mfc=BG, mec=A_, mew=1.1, zorder=5)
        ax.annotate(
            "optimum strength",
            xy=(gopt + 0.05, 1.0), xytext=(gopt + 0.50, 1.14),
            fontsize=FS_TICK, color=INK_E, va="center", ha="left",
            annotation_clip=False,
            arrowprops=dict(
                arrowstyle="-", lw=0.6, color=GREY_E, shrinkA=1.5, shrinkB=3
            ),
        )
        ax.text(
            0.97, 0.60,
            "one scalar knob\n"
            r"fixed jumps  $L_i=\sigma_i^-$" "\n"
            r"uniform rates  $\gamma_i=\gamma$",
            transform=ax.transAxes, ha="right", va="top",
            fontsize=FS_TICK, color=GREY_E, linespacing=1.6,
        )

        ax.set_xlim(-0.06, 4.6)
        ax.set_ylim(0, 1.33)
        ax.set_xticks([0, 1, 2, 3, 4])
        ax.set_yticks([])
        ax.set_xlabel(r"damping strength $\gamma$", fontsize=FS_LAB, labelpad=2.5)
        ax.set_ylabel("performance (schematic)", fontsize=FS_LAB, labelpad=4)
        ax.tick_params(axis="x", labelsize=FS_TICK, pad=2)
        ax.spines["bottom"].set_visible(False)
        ax.set_title(
            "(a)  Sannia et al.: scalar rate $\\gamma$",
            fontsize=FS_TITLE, fontweight="bold", loc="left", pad=7,
        )

        # ------------------------------------- (b) channel x profile
        bx = fig.add_subplot(gs[0, 1])
        bx.set_axis_off()
        cw, ch = 1.0, 0.80
        gw, gh = n_chan * cw, n_prof * ch

        def xy(col, row):
            return col * cw, (n_prof - 1 - row) * ch

        def role(row, col):
            if (row, col) == (0, 0):
                return "prior"
            if row == 0:
                return "chan"
            if col == 0:
                return "prof"
            return "null"

        fill = {"chan": Af, "prof": Bf, "null": NULLF, "prior": Af}

        for row in range(n_prof):
            for col in range(n_chan):
                x, yy = xy(col, row)
                bx.add_patch(
                    Rectangle(
                        (x, yy), cw, ch, facecolor=fill[role(row, col)],
                        edgecolor="none", zorder=1,
                    )
                )
        # the nested prior-work design belongs to both sweeps
        x, yy = xy(0, 0)
        bx.add_patch(
            Polygon(
                [[x, yy], [x + cw, yy], [x, yy + ch]], closed=True,
                facecolor=Bf, edgecolor="none", zorder=1.6,
            )
        )
        # bounded 2x2 joint check (learned x collective), promised by the
        # caption and the FIGURE_QA contract
        x, yy = xy(1, 2)
        bx.add_patch(
            Rectangle(
                (x, yy), cw, ch, facecolor=NULLF, edgecolor=GREY_E,
                lw=0.0, hatch="///", zorder=2,
            )
        )
        # hairline rules, then heavier rules bracketing the two swept slices
        for i in range(n_prof + 1):
            bx.plot([0, gw], [i * ch] * 2, color=RULE_E, lw=0.55, zorder=3)
        for j in range(n_chan + 1):
            bx.plot([j * cw] * 2, [0, gh], color=RULE_E, lw=0.55, zorder=3)
        bx.plot([0, gw], [gh, gh], color=A_, lw=1.3, zorder=4)
        bx.plot([0, gw], [gh - ch, gh - ch], color=A_, lw=1.3, zorder=4)
        bx.plot([0, 0], [0, gh], color=B_, lw=1.3, zorder=4)
        bx.plot([cw, cw], [0, gh], color=B_, lw=1.3, zorder=4)

        x, yy = xy(0, 0)
        bx.text(
            x + cw / 2, yy + ch / 2, "prior\nwork", ha="center", va="center",
            fontsize=FS_CELL, color=INK_E, linespacing=1.25, zorder=6,
        )

        # profile axis: name + rate rule
        for row, (name, rate) in enumerate(profile_items):
            _, yy = xy(0, row)
            yc = yy + ch / 2
            bx.text(
                -0.16, yc + 0.16, name, ha="right", va="center",
                fontsize=FS_LAB, color=A_ if row == 0 else INK_E,
                fontweight="bold" if row == 0 else "normal",
            )
            bx.text(
                -0.16, yc - 0.18, rate, ha="right", va="center",
                fontsize=FS_MATH, color=GREY_E,
            )

        # channel axis: name + jump operators
        for col, (name, op) in enumerate(channel_items):
            x, _ = xy(col, 0)
            bx.text(
                x + cw / 2, -0.13, name, ha="center", va="top",
                fontsize=FS_TICK, color=B_ if col == 0 else INK_E,
                fontweight="bold" if col == 0 else "normal",
            )
            bx.text(
                x + cw / 2, -0.39, op, ha="center", va="top",
                fontsize=FS_MATH, color=GREY_E, linespacing=1.45,
            )

        bx.text(
            -0.16, gh + 0.10, "rate profile", ha="right", va="bottom",
            fontsize=FS_TICK, color=GREY_E, style="italic",
        )
        bx.text(
            gw / 2, -0.92, "jump family: what the environment removes",
            ha="center", va="top", fontsize=FS_LAB, color=INK_E,
        )
        bx.text(
            gw / 2, gh + 0.10, r"jump operators $L_k$", ha="center",
            va="bottom", fontsize=FS_TICK, color=GREY_E, style="italic",
        )

        # key
        leg_y, sw, sh = -1.42, 0.30, 0.20
        for dx, row, fc, ec, hatch, label in [
            (0.00, 0, Af, A_, None, "jump-family sweep (uniform profile)"),
            (0.00, 1, Bf, B_, None, "profile sweep (local loss)"),
            (3.60, 0, NULLF, RULE_E, None, "not swept here"),
            (3.60, 1, NULLF, GREY_E, "///", r"$2\times2$ joint check"),
        ]:
            yy = leg_y - row * 0.32
            bx.add_patch(
                Rectangle(
                    (dx, yy), sw, sh, facecolor=fc, edgecolor=ec, lw=0.8,
                    hatch=hatch, clip_on=False, zorder=3,
                )
            )
            bx.text(
                dx + sw + 0.13, yy + sh / 2, label, ha="left", va="center",
                fontsize=FS_LEG, color=INK_E,
            )

        # what is actually being compared
        bx.text(
            gw / 2, leg_y - 0.62,
            "jump-family map and fixed-profile designs use one Frobenius "
            "normalization\n"
            r"$\mathcal{B}=\sum_k \mathrm{Tr}(L_k^{\dagger}L_k)$" "\n"
            "six jump families at a uniform profile + unequal × local",
            ha="center", va="top", fontsize=FS_FOOT, color=GREY_E,
            linespacing=1.55, style="italic",
        )

        bx.set_xlim(-1.90, gw + 0.06)
        bx.set_ylim(leg_y - 1.30, gh + 0.46)
        bx.text(
            -1.90, gh + 0.46, "(b)  This work: jump family and profile",
            ha="left", va="bottom", fontsize=FS_TITLE, fontweight="bold",
            color=INK_E,
        )

        os.makedirs(OUTDIR, exist_ok=True)
        fig.savefig(
            os.path.join(OUTDIR, "fig_designspace.pdf"),
            facecolor=BG,
            metadata={"Creator": "paper/make_figures.py"},
        )
        plt.close(fig)


def fig_map(rows: list[dict]):
    """Central channel-task map with the documented permutation-test contract."""
    methods = [
        "FN",
        "CD_paper",
        "B3_collective",
        "A1_heterogeneous",
        "B5_pair",
        "B2_thermal",
        "B4_loss_exchange",
        "B1_dephasing",
    ]
    tasks = ["stm", "narma", "parity", "mg"]
    row_labels = [
        "ORIGINAL QRC\nreset FN (Fujii-Nakajima, 2017)",
        "PRIOR DISSIPATION\nuniform local (Sannia et al., 2024)",
        "OUR WORK\ncollective loss",
        "unequal rates",
        "pair loss",
        "thermal loss",
        "exchange loss",
        "dephasing",
    ]
    task_labels = [
        "STM\nlinear\nmemory",
        "NARMA-10\nnonlinear\nmemory",
        "parity\nmemory +\nmixing",
        "Mackey-Glass\nclosed-loop\nforecast",
    ]

    gain_matrix = np.zeros((len(methods), len(tasks)))
    raw_pvalues = {}
    sample_sizes = {}
    for row_index, method in enumerate(methods):
        for col_index, task in enumerate(tasks):
            if method == "CD_paper":
                continue
            method_values = map_cell(rows, task, method)
            baseline_values = map_cell(rows, task, "CD_paper")
            paired = paired_summary(
                method_values,
                baseline_values,
                higher_better=HIGHER[task],
                percent=True,
            )
            gain_matrix[row_index, col_index] = paired["mean"]
            raw_pvalues[(row_index, col_index)] = signflip_permutation_p(
                paired["raw"]
            )
            sample_sizes[task] = paired["n"]
    adjusted = holm_adjust(raw_pvalues)

    benefit_map = LinearSegmentedColormap.from_list(
        "benefit", [ORANGE, "#FFFDF9", BLUE], N=256
    )
    fig, ax = plt.subplots(figsize=(7.05, 4.05))
    clipped = np.clip(gain_matrix, -60, 60)
    image = ax.imshow(
        clipped,
        cmap=benefit_map,
        vmin=-60,
        vmax=60,
        aspect="auto",
        interpolation="nearest",
    )
    ax.add_patch(
        Rectangle(
            (-0.5, 0.5),
            len(tasks),
            1,
            facecolor="#F2F3F5",
            edgecolor="none",
            zorder=2,
        )
    )

    for row_index, method in enumerate(methods):
        if method == "CD_paper":
            ax.text(
                1.5,
                row_index,
                "reference: every cell is paired against this row",
                ha="center",
                va="center",
                color=MUTED,
                fontsize=9,
                style="italic",
                zorder=3,
            )
            continue
        for col_index, task in enumerate(tasks):
            value = gain_matrix[row_index, col_index]
            pvalue = adjusted[(row_index, col_index)]
            stars = (
                "***"
                if pvalue < 0.001
                else ("**" if pvalue < 0.01 else ("*" if pvalue < 0.05 else ""))
            )
            label = f"{value:+.0f}%{stars}"
            if task in ("stm", "parity"):
                raw_mean = np.mean(
                    list(map_cell(rows, task, method).values())
                )
                if raw_mean < 1e-6:
                    label = "ZERO"
            ax.text(
                col_index,
                row_index,
                label,
                ha="center",
                va="center",
                fontsize=9,
                weight="bold" if method == "B3_collective" else "normal",
                color=PAPER if abs(clipped[row_index, col_index]) >= 41 else INK,
                zorder=3,
            )

    ax.axhline(0.5, color=INK, linewidth=1.2)
    ax.axhline(1.5, color=INK, linewidth=1.2)
    ax.set_xticks(range(len(tasks)))
    ax.set_xticklabels(task_labels)
    ax.set_yticks(range(len(methods)))
    ax.set_yticklabels(row_labels)
    ax.get_yticklabels()[0].set_color(PURPLE)
    ax.get_yticklabels()[1].set_color(MUTED)
    ax.set_xlim(-0.5, 3.5)
    ax.set_title(
        "Fixed-Frobenius performance relative to uniform local loss",
        loc="left",
        color=INK,
        weight="bold",
        pad=29,
    )
    ax.text(
        0,
        1.035,
        "N=5; paired samples: 32 STM/NARMA, 16 parity, 64 forecast; "
        "positive = better.",
        transform=ax.transAxes,
        fontsize=8.8,
        color=MUTED,
        va="bottom",
    )
    colorbar = fig.colorbar(image, ax=ax, fraction=0.045, pad=0.045, extend="both")
    colorbar.set_label("change vs reference (%)", fontsize=9)
    colorbar.ax.tick_params(labelsize=8.8)
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.tick_params(axis="x", length=0)
    ax.tick_params(axis="y", length=0, pad=6)
    fig.subplots_adjust(left=0.31, right=0.88, bottom=0.21, top=0.80)
    save(fig, "fig_map.pdf")
    print(
        "  fig_map: paired sign-flip permutation + Holm; "
        f"minimum adjusted p={min(adjusted.values()):.3g}"
    )


def fig_plane(rows: list[dict]):
    methods = [
        "B3_collective",
        "A1_heterogeneous",
        "B5_pair",
        "B2_thermal",
        "B4_loss_exchange",
        "FN",
    ]
    fig, ax = plt.subplots(figsize=(3.35, 3.0))
    ax.axhline(0, color=INK, linewidth=0.8)
    ax.axvline(0, color=INK, linewidth=0.8)
    ax.add_patch(
        Rectangle(
            (15, 8),
            47,
            19,
            facecolor="#F2F3F5",
            edgecolor=MUTED,
            linewidth=0.7,
            linestyle=":",
            zorder=0,
        )
    )
    offsets = {
        "B3_collective": (-49, -12),
        "A1_heterogeneous": (5, -10),
        "B5_pair": (5, 6),
        "B2_thermal": (-47, -14),
        "B4_loss_exchange": (-55, 7),
        "FN": (-10, 7),
    }
    short_label = {
        "B3_collective": "collective",
        "A1_heterogeneous": "unequal",
        "B5_pair": "pair",
        "B2_thermal": "thermal",
        "B4_loss_exchange": "exchange",
        "FN": "reset FN",
    }
    for method in methods:
        memory = paired_summary(
            cell(rows, "A_table", "stm", method, N=5),
            cell(rows, "A_table", "stm", "CD_paper", N=5),
            percent=True,
        )
        parity = paired_summary(
            cell(rows, "A_table", "parity", method, N=5),
            cell(rows, "A_table", "parity", "CD_paper", N=5),
            percent=True,
        )
        ax.errorbar(
            memory["mean"],
            parity["mean"],
            xerr=interval_error(memory),
            yerr=interval_error(parity),
            marker=MARKER[method],
            markersize=6.5,
            color=C[method],
            markerfacecolor=PAPER if method == "FN" else C[method],
            markeredgecolor=C[method],
            linestyle="none",
            capsize=2,
            elinewidth=0.9,
            zorder=3,
        )
        ax.annotate(
            short_label[method],
            (memory["mean"], parity["mean"]),
            xytext=offsets[method],
            textcoords="offset points",
            fontsize=8.8,
        )
    ax.text(
        38,
        17,
        "no jump family\nwins strongly\non both",
        ha="center",
        va="center",
        fontsize=8.8,
        color=MUTED,
    )
    ax.set_xlim(-62, 62)
    ax.set_ylim(-58, 27)
    ax.set_xlabel("STM gain (%)")
    ax.set_ylabel("parity gain (%)")
    ax.set_title("Jump-family specialisms", loc="left", color=INK, weight="bold", pad=7)
    ax.text(
        0.02,
        0.98,
        "n=32; 95% paired t-CIs",
        transform=ax.transAxes,
        fontsize=8.5,
        color=MUTED,
        va="top",
    )
    style_axis(ax, "both")
    fig.subplots_adjust(left=0.20, right=0.98, bottom=0.18, top=0.80)
    save(fig, "fig_plane.pdf")


def fig_scaling(rows: list[dict]):
    if not os.path.isfile(REVISION_SCALING):
        raise SystemExit(
            f"ERROR: missing sealed normalized-scaling artifact {REVISION_SCALING}"
        )
    with open(REVISION_SCALING, encoding="utf-8") as handle:
        normalized = json.load(handle)
    if (
        normalized.get("status") != "complete"
        or normalized.get("complete_checkpoints") != 80
        or normalized.get("expected_checkpoints") != 80
        or normalized.get("ridge_boundary_audit", {}).get(
            "upper_boundary_is_bracketed"
        )
        is not True
        or normalized.get("invariant_audit", {}).get("all_passed") is not True
        or normalized.get("protocol", {}).get("schemes") != ["variance"]
    ):
        raise SystemExit(
            "ERROR: normalized-scaling artifact is incomplete or failed its "
            "production audits"
        )

    sizes = [4, 5, 6, 7, 8]
    normalized_summary = normalized["summary_by_scheme"]["variance"]
    raw_normalized_rows = normalized["raw_rows"]

    def percentile_interval(summary: dict, scale: float = 1.0):
        lo, hi = summary["ci95_percentile"]
        return {
            "mean": scale * float(summary["mean"]),
            "lo": scale * float(lo),
            "hi": scale * float(hi),
        }

    fig, axes = plt.subplots(
        1,
        3,
        figsize=(7.05, 3.20),
        gridspec_kw={"width_ratios": [1.0, 1.0, 1.05]},
    )
    ax_original, ax_normalized, ax_absolute = axes

    # Panel a reproduces the original U[-1,1] coupling convention.  Both
    # protocols use the same estimand: the mean within-instance relative
    # improvement.  Student-t intervals here remain distinct from the fresh
    # percentile-bootstrap control in panel b.
    for task, color, marker, linestyle, label in (
        ("stm", BLUE, "o", "-", "STM"),
        ("narma", SKY, "s", "--", "NARMA"),
    ):
        summaries = []
        for size in sizes:
            collective = cell(
                rows, "B_scale", task, "B3_collective", N=size
            )
            local = cell(rows, "B_scale", task, "CD_paper", N=size)
            shared = sorted(set(collective) & set(local))
            if task == "stm":
                relative = np.asarray(
                    [
                        (collective[seed] - local[seed]) / local[seed]
                        for seed in shared
                    ],
                    dtype=float,
                )
            else:
                relative = np.asarray(
                    [
                        (local[seed] - collective[seed]) / local[seed]
                        for seed in shared
                    ],
                    dtype=float,
                )
            summaries.append(t_summary(100.0 * relative))
        means = np.array([item["mean"] for item in summaries])
        lower = means - np.array([item["lo"] for item in summaries])
        upper = np.array([item["hi"] for item in summaries]) - means
        ax_original.errorbar(
            sizes,
            means,
            yerr=np.vstack([lower, upper]),
            color=color,
            marker=marker,
            linestyle=linestyle,
            markerfacecolor=color if task == "stm" else PAPER,
            markeredgecolor=color,
            capsize=2.2,
            label=label,
        )
    ax_original.axhline(0, color=INK, linewidth=0.8)
    ax_original.set_xticks(sizes)
    ax_original.set_xlabel("qubits, $N$")
    ax_original.set_ylabel("collective improvement (%)")
    ax_original.legend(frameon=False, loc="upper left")
    panel_title(ax_original, "a", "Original couplings")
    style_axis(ax_original, "y")

    # Panel b is the fresh, fully paired variance-normalized control.  The
    # aggregate stores mean within-seed relative effects and deterministic
    # percentile-bootstrap intervals.
    for key, color, marker, linestyle, label in (
        ("stm_relative_advantage", BLUE, "o", "-", "STM"),
        ("narma_relative_improvement", SKY, "s", "--", "NARMA"),
    ):
        summaries = [
            percentile_interval(normalized_summary[str(size)][key], 100.0)
            for size in sizes
        ]
        means = np.array([item["mean"] for item in summaries])
        lower = means - np.array([item["lo"] for item in summaries])
        upper = np.array([item["hi"] for item in summaries]) - means
        ax_normalized.errorbar(
            sizes,
            means,
            yerr=np.vstack([lower, upper]),
            color=color,
            marker=marker,
            linestyle=linestyle,
            markerfacecolor=color if key.startswith("stm") else PAPER,
            markeredgecolor=color,
            capsize=2.2,
            label=label,
        )
    ax_normalized.axhline(0, color=INK, linewidth=0.8)
    ax_normalized.set_xticks(sizes)
    ax_normalized.set_xlabel("qubits, $N$")
    ax_normalized.set_ylabel("collective improvement (%)")
    ax_normalized.legend(frameon=False, loc="center right")
    panel_title(ax_normalized, "b", "Variance-normalized")
    style_axis(ax_normalized, "y")

    # Panel c shows the absolute STM scale behind the relative effect in panel b.
    # Student-t intervals are recomputed directly from the eight raw instances.
    for method in ("B3_collective", "CD_paper"):
        summaries = []
        for size in sizes:
            values = [
                float(row["stm"]["selected_test"])
                for row in raw_normalized_rows
                if row["scheme"] == "variance"
                and row["n_qubits"] == size
                and row["method"] == method
            ]
            summaries.append(t_summary(values))
        means = np.array([item["mean"] for item in summaries])
        lower = means - np.array([item["lo"] for item in summaries])
        upper = np.array([item["hi"] for item in summaries]) - means
        ax_absolute.errorbar(
            sizes,
            means,
            yerr=np.vstack([lower, upper]),
            color=C[method],
            marker=MARKER[method],
            linestyle=LINESTYLE[method],
            markerfacecolor=PAPER if method == "CD_paper" else C[method],
            markeredgecolor=C[method],
            capsize=2.0,
            label="collective" if method == "B3_collective" else "uniform local",
        )
    ax_absolute.set_xticks(sizes)
    ax_absolute.set_xlabel("qubits, $N$")
    ax_absolute.set_ylabel("memory capacity")
    ax_absolute.legend(frameon=False, fontsize=8.1, loc="upper left")
    panel_title(ax_absolute, "c", "Absolute STM")
    style_axis(ax_absolute, "y")

    fig.text(
        0.5,
        0.985,
        "Original: paired t-CIs (n=30 at N=4-7; n=20 at N=8). "
        "Normalized: independent paired bootstrap CIs (n=8).",
        ha="center",
        va="top",
        fontsize=8.3,
        color=MUTED,
    )
    fig.subplots_adjust(left=0.08, right=0.995, bottom=0.18, top=0.80, wspace=0.42)
    save(fig, "fig_scaling.pdf")


def fig_budget():
    strength_path = os.path.join(
        REVISION_TUNING_DIR, "strength_extension", "six_channel_aggregate.json"
    )
    if not os.path.isfile(strength_path):
        raise SystemExit(
            f"ERROR: missing revision tuning artifact {strength_path}"
        )
    with open(strength_path, encoding="utf-8") as handle:
        strength = json.load(handle)

    methods = [
        "CD_paper",
        "B3_collective",
        "A1_heterogeneous",
        "B2_thermal",
        "B4_loss_exchange",
        "B5_pair",
    ]
    if set(strength.get("methods", {})) != set(methods):
        raise SystemExit(
            "ERROR: revision strength aggregate does not contain exactly the "
            "six non-dephasing jump families"
        )
    expected_rows = 0
    for method in methods:
        method_result = strength["methods"][method]
        bracket = method_result.get("curve_bracket", {})
        curve = bracket.get("curve", [])
        if not bracket.get("bracketed"):
            raise SystemExit(
                f"ERROR: {method} validation maximum is not bracketed; "
                "refusing to plot an incomplete strength ranking"
            )
        if len(curve) < 7 or any(int(point.get("n", 0)) != 20 for point in curve):
            raise SystemExit(
                f"ERROR: {method} strength curve is incomplete or has an "
                "unexpected seed count"
            )
        multipliers = [float(point["multiplier"]) for point in curve]
        if len(set(multipliers)) != len(multipliers):
            raise SystemExit(f"ERROR: duplicate strength point for {method}")
        expected_rows += 20 * len(curve)
    if len(strength.get("raw_rows", [])) != expected_rows:
        raise SystemExit(
            "ERROR: strength aggregate raw-row count does not match its "
            "complete validation curves"
        )
    if len(strength.get("raw_provenance", [])) != expected_rows:
        raise SystemExit("ERROR: strength aggregate provenance is incomplete")

    fig, axes = plt.subplots(
        1,
        2,
        figsize=(7.05, 3.20),
        gridspec_kw={"width_ratios": [1.55, 1.0]},
    )
    ax_curve, ax_rank = axes

    for method in methods:
        curve = strength["methods"][method]["curve_bracket"]["curve"]
        x = np.array([float(item["multiplier"]) for item in curve])
        mean = np.array([float(item["validation_mean"]) for item in curve])
        half = np.array(
            [
                stats.t.ppf(0.975, int(item["n"]) - 1)
                * float(item["validation_se"])
                for item in curve
            ]
        )
        ax_curve.errorbar(
            x,
            mean,
            yerr=half,
            color=C[method],
            marker=MARKER[method],
            linestyle=LINESTYLE[method],
            markerfacecolor=PAPER if method == "CD_paper" else C[method],
            markeredgecolor=C[method],
            markersize=3.8,
            capsize=1.4,
            elinewidth=0.75,
            label=LABEL[method],
        )
    ax_curve.set_xscale("log")
    ax_curve.set_xlabel("strength multiplier")
    ax_curve.set_ylabel("validation STM capacity")
    panel_title(ax_curve, "a", "Validation curves")
    style_axis(ax_curve, "both")

    ranked = sorted(
        methods,
        key=lambda method: strength["methods"][method]["leave_one_seed_out"][
            "test_mean"
        ],
    )
    for y, method in enumerate(ranked):
        item = strength["methods"][method]["leave_one_seed_out"]
        half = stats.t.ppf(0.975, 19) * float(item["test_se"])
        ax_rank.errorbar(
            float(item["test_mean"]),
            y,
            xerr=half,
            color=C[method],
            marker=MARKER[method],
            markerfacecolor=PAPER if method == "CD_paper" else C[method],
            markeredgecolor=C[method],
            markersize=5.3,
            linestyle="none",
            capsize=2.0,
            elinewidth=0.9,
        )
    ax_rank.set_yticks(range(len(ranked)))
    ax_rank.set_yticklabels(
        [
            {
                "CD_paper": "local",
                "B3_collective": "collective",
                "A1_heterogeneous": "unequal",
                "B2_thermal": "thermal",
                "B4_loss_exchange": "exchange",
                "B5_pair": "pair",
            }[method]
            for method in ranked
        ],
        fontsize=8.2,
    )
    ax_rank.set_xlabel("held-out STM capacity")
    panel_title(ax_rank, "b", "Held-out ranking")
    style_axis(ax_rank, "x")

    handles, _ = ax_curve.get_legend_handles_labels()
    fig.legend(
        handles,
        ["uniform local", "collective", "unequal", "thermal", "exchange", "pair"],
        frameon=False,
        fontsize=8.0,
        loc="upper center",
        bbox_to_anchor=(0.53, 0.89),
        ncol=3,
        columnspacing=1.3,
        handlelength=2.2,
    )
    fig.text(
        0.5,
        0.985,
        "Complete six-design strength archive (920 validation rows); "
        "n=20 per point and design; pointwise 95% t-CIs.",
        ha="center",
        va="top",
        fontsize=8.3,
        color=MUTED,
    )
    fig.subplots_adjust(left=0.075, right=0.985, bottom=0.18, top=0.72, wspace=0.36)
    save(fig, "fig_budget.pdf")


def diagnostic_values(rows: list[dict], N: int, method: str, key: str) -> list[float]:
    return [
        float(row["diagnostics"][key])
        for row in rows
        if row.get("block") == "E_diag"
        and row.get("N") == N
        and row.get("method") == method
        and row.get("diagnostics")
        and isinstance(row["diagnostics"].get(key), (int, float))
    ]


def fig_predict(rows: list[dict]):
    methods = [
        "B3_collective",
        "CD_paper",
        "A1_heterogeneous",
        "B5_pair",
        "B2_thermal",
        "B4_loss_exchange",
        "B1_dephasing",
    ]
    fig, (ax_gate, ax_gap) = plt.subplots(
        1,
        2,
        figsize=(7.05, 2.95),
        gridspec_kw={"width_ratios": [0.95, 1.25]},
    )

    defect_summaries = [
        t_summary(diagnostic_values(rows, 5, method, "unitality_defect"))
        for method in methods
    ]
    defect_means = [item["mean"] for item in defect_summaries]
    defect_errors = np.array(
        [
            [
                item["mean"] - item["lo"] for item in defect_summaries
            ],
            [
                item["hi"] - item["mean"] for item in defect_summaries
            ],
        ]
    )
    y_positions = np.arange(len(methods))
    ax_gate.barh(
        y_positions,
        defect_means,
        xerr=defect_errors,
        color=[C[method] for method in methods],
        alpha=0.88,
        edgecolor=INK,
        linewidth=0.5,
        error_kw={"elinewidth": 0.9, "capsize": 2},
    )
    ax_gate.scatter(
        [0],
        [methods.index("B1_dephasing")],
        marker="X",
        s=42,
        color=INK,
        zorder=3,
    )
    ax_gate.annotate(
        "zero",
        (0, methods.index("B1_dephasing")),
        xytext=(7, 0),
        textcoords="offset points",
        fontsize=8.8,
        va="center",
    )
    ax_gate.set_yticks(y_positions)
    ax_gate.set_yticklabels(
        [
            "collective",
            "uniform local",
            "unequal",
            "pair",
            "thermal",
            "exchange",
            "dephasing",
        ]
    )
    ax_gate.invert_yaxis()
    ax_gate.set_xlabel(r"unitality defect $\Vert\sum_k[L_k,L_k^\dagger]\Vert$")
    panel_title(ax_gate, "a", "Operator-level gate")
    style_axis(ax_gate, "x")

    x_means, y_means = [], []
    offsets = {
        "B3_collective": (5, 5),
        "CD_paper": (5, 4),
        "A1_heterogeneous": (5, -14),
        "B5_pair": (5, 8),
        "B2_thermal": (-53, -14),
        "B4_loss_exchange": (-61, 5),
    }
    short_label = {
        "B3_collective": "collective",
        "CD_paper": "uniform local",
        "A1_heterogeneous": "unequal",
        "B5_pair": "pair",
        "B2_thermal": "thermal",
        "B4_loss_exchange": "exchange",
    }
    for method in methods:
        if method == "B1_dephasing":
            continue
        gap = t_summary(diagnostic_values(rows, 5, method, "spectral_gap"))
        memory = t_summary(
            cell(rows, "A_table", "stm", method, N=5).values()
        )
        x_means.append(gap["mean"])
        y_means.append(memory["mean"])
        ax_gap.errorbar(
            gap["mean"],
            memory["mean"],
            xerr=interval_error(gap),
            yerr=interval_error(memory),
            marker=MARKER[method],
            markersize=6.2,
            color=C[method],
            markerfacecolor=PAPER if method in ("CD_paper", "FN") else C[method],
            markeredgecolor=C[method],
            linestyle="none",
            capsize=2,
            elinewidth=0.9,
            zorder=3,
        )
        ax_gap.annotate(
            short_label[method],
            (gap["mean"], memory["mean"]),
            xytext=offsets.get(method, (5, 5)),
            textcoords="offset points",
            fontsize=8.6,
        )
    rho, _ = stats.spearmanr(x_means, y_means)
    ax_gap.set_xlabel("driven-generator relaxation rate")
    ax_gap.set_ylabel("memory capacity")
    panel_title(ax_gap, "b", "Six-design pattern after scoring")
    ax_gap.text(
        0.97,
        0.95,
        rf"Spearman $\rho={rho:+.2f}$",
        transform=ax_gap.transAxes,
        ha="right",
        va="top",
        fontsize=8.8,
        bbox={"boxstyle": "round,pad=0.25", "fc": PAPER, "ec": GRID, "lw": 0.7},
    )
    style_axis(ax_gap, "both")

    fig.text(
        0.5,
        0.985,
        "Diagnostics: n=10 Hamiltonian instances (95% t-intervals). "
        "Memory: n=32 independent paired instances.",
        ha="center",
        va="top",
        fontsize=8.7,
        color=MUTED,
    )
    fig.subplots_adjust(left=0.15, right=0.995, bottom=0.19, top=0.78, wspace=0.48)
    save(fig, "fig_predict.pdf")


def fig_shotmap():
    if not os.path.isfile(REVISION_MEASUREMENT):
        raise SystemExit(
            "ERROR: complete equal-nominal-preparation aggregate not found at "
            + REVISION_MEASUREMENT
        )
    with open(REVISION_MEASUREMENT, encoding="utf-8") as handle:
        result = json.load(handle)
    if result.get("validation", {}).get("status") != "complete":
        raise SystemExit(
            "ERROR: equal-nominal-preparation measurement aggregate is incomplete"
        )

    methods = [
        "B3_collective",
        "A1_heterogeneous",
        "B5_pair",
        "B2_thermal",
        "B4_loss_exchange",
    ]
    finite_budgets = sorted(
        {
            int(row["budget"])
            for row in result["paired_vs_local"]
            if row["budget"] != "exact"
        }
    )
    measurement_models = {
        row["measurement_model"]
        for row in result["paired_vs_local"]
        if row["budget"] != "exact"
    }
    all_methods = {
        row["channel"]
        for row in result["paired_vs_local"]
        if row["budget"] != "exact"
    }
    simultaneous_family = (
        len(measurement_models)
        * len(finite_budgets)
        * len(all_methods)
        * (len(all_methods) - 1)
        // 2
    )
    if simultaneous_family != 210:
        raise SystemExit(
            "ERROR: unexpected measurement-inference family size "
            f"{simultaneous_family}, expected 210"
        )
    simultaneous_critical = stats.t.ppf(
        1.0 - 0.05 / (2.0 * simultaneous_family), 19
    )
    exact_position = finite_budgets[-1] * 8
    lookup = {
        (row["measurement_model"], row["budget"], row["channel"]): row
        for row in result["paired_vs_local"]
    }

    fig, axes = plt.subplots(1, 2, figsize=(7.05, 3.22), sharey=True)
    for ax, model, letter, title in (
        (axes[0], "independent", "a", "Independent observables"),
        (axes[1], "grouped", "b", "Three Pauli settings"),
    ):
        for method in methods:
            summaries = [
                lookup[(model, str(budget), method)] for budget in finite_budgets
            ]
            means = np.array([item["mean"] for item in summaries])
            simultaneous_half_width = simultaneous_critical * np.array(
                [item["se"] for item in summaries]
            )
            ax.errorbar(
                finite_budgets,
                means,
                yerr=simultaneous_half_width,
                color=C[method],
                marker=MARKER[method],
                linestyle=LINESTYLE[method],
                markerfacecolor=C[method],
                markeredgecolor=C[method],
                markersize=4.0,
                capsize=1.6,
                elinewidth=0.85,
                label=LABEL[method],
            )
            exact = lookup[(model, "exact", method)]
            ax.plot(
                [finite_budgets[-1], exact_position],
                [means[-1], exact["mean"]],
                color=C[method],
                linestyle=":",
                linewidth=1.0,
                alpha=0.75,
            )
            ax.errorbar(
                [exact_position],
                [exact["mean"]],
                yerr=np.array(
                    [
                        [exact["mean"] - exact["ci95_low"]],
                        [exact["ci95_high"] - exact["mean"]],
                    ]
                ),
                color=C[method],
                marker=MARKER[method],
                linestyle="none",
                markerfacecolor=PAPER,
                markeredgecolor=C[method],
                markersize=5.0,
                capsize=1.8,
                elinewidth=0.85,
            )
        ax.axhspan(0, 4.25, color="#EAF4FB", alpha=0.35, zorder=-3)
        ax.axhline(0, color=INK, linewidth=0.9)
        ax.axvline(
            finite_budgets[-1] * 3,
            color=GRID,
            linewidth=0.9,
            linestyle=":",
        )
        ax.set_xscale("log")
        ax.set_xlim(2_000, exact_position * 1.2)
        ax.set_ylim(-3.05, 4.25)
        ax.set_xticks(
            [
                finite_budgets[0],
                finite_budgets[2],
                finite_budgets[4],
                finite_budgets[-1],
                exact_position,
            ]
        )
        ax.set_xticklabels(["2.9k", "46k", "0.74m", "11.8m", "exact"])
        ax.get_xticklabels()[-1].set_ha("right")
        ax.minorticks_off()
        ax.set_xlabel("nominal state preparations per time step")
        panel_title(ax, letter, title)
        style_axis(ax, "y")

    axes[0].set_ylabel("paired STM-capacity gain over uniform local")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        frameon=False,
        fontsize=7.9,
        loc="upper center",
        bbox_to_anchor=(0.52, 0.89),
        ncol=3,
        columnspacing=1.1,
        handlelength=2.2,
    )

    fig.text(
        0.5,
        0.985,
        "Equal nominal preparations; n=20 paired; validation-selected ridge.\n"
        "Finite points: 95% Bonferroni-simultaneous bands (210 contrasts).",
        ha="center",
        va="top",
        fontsize=8.7,
        color=MUTED,
    )
    fig.subplots_adjust(left=0.09, right=0.995, bottom=0.19, top=0.72, wspace=0.16)
    save(fig, "fig_shotmap.pdf")


def fig_adaptive(rows: list[dict]):
    review = load_review()
    uniform = cell(rows, "F_adaptive", "stm", "A0_uniform", N=5)
    unequal = cell(rows, "F_adaptive", "stm", "A1_random", N=5)
    optimized = {
        method: {
            row["seed"]: row["value"]
            for row in review
            if row.get("block") == "R_optfix" and row.get("method") == method
        }
        for method in ("A3_eq", "A4_eq")
    }
    profile_summaries = [
        paired_summary(unequal, uniform),
        paired_summary(optimized["A3_eq"], uniform),
        paired_summary(optimized["A4_eq"], uniform),
    ]
    profile_seed_sets = {
        tuple(sorted(values))
        for values in (uniform, unequal, *optimized.values())
    }
    if (
        any(item["n"] != 32 for item in profile_summaries)
        or len(profile_seed_sets) != 1
    ):
        raise SystemExit(
            "ERROR: profile-ladder data are not a complete 32-seed paired grid"
        )

    fig, (ax_ladder, ax_joint) = plt.subplots(
        1,
        2,
        figsize=(7.05, 2.8),
        gridspec_kw={"width_ratios": [1.15, 0.85]},
    )
    x_positions = np.arange(3)
    profile_colors = [GOLD, "#B9770E", "#E7B75B"]
    profile_markers = ["s", "o", "^"]
    profile_labels = ["unequal\nstatic", "learned\nstatic", "input-\nadaptive"]
    for x_position, summary, color, marker in zip(
        x_positions, profile_summaries, profile_colors, profile_markers
    ):
        ax_ladder.vlines(x_position, 0, summary["mean"], color=color, linewidth=2)
        ax_ladder.errorbar(
            x_position,
            summary["mean"],
            yerr=interval_error(summary),
            color=color,
            marker=marker,
            markerfacecolor=color,
            markeredgecolor=INK,
            markeredgewidth=0.6,
            markersize=7,
            linestyle="none",
            capsize=3,
        )
        if x_position == 0:
            label_x, label_ha = x_position + 0.06, "left"
        elif x_position == 2:
            label_x, label_ha = x_position - 0.06, "right"
        else:
            label_x, label_ha = x_position, "center"
        ax_ladder.text(
            label_x,
            summary["hi"] + 0.09,
            f"{summary['mean']:+.2f}",
            ha=label_ha,
            fontsize=8.8,
            weight="bold" if x_position == 1 else "normal",
        )
    ax_ladder.axhline(0, color=INK, linewidth=0.8)
    ax_ladder.set_xticks(x_positions)
    ax_ladder.set_xticklabels(profile_labels)
    ax_ladder.set_ylim(-0.05, 1.75)
    ax_ladder.set_ylabel("paired memory-capacity gain\nvs uniform profile")
    panel_title(ax_ladder, "a", "Static profile learning is the useful lever")
    style_axis(ax_ladder, "y")

    joint_rows = [
        row
        for row in rows
        if row.get("block") == "G_joint" and row.get("task") == "stm"
    ]
    joint_cells = {
        method: {
            row["seed"]: row["value"]
            for row in joint_rows
            if row.get("method") == method
        }
        for method in (
            "G_local_uniform",
            "G_local_learned",
            "G_coll_uniform",
            "G_coll_learned",
        )
    }
    local_gain = paired_summary(
        joint_cells["G_local_learned"], joint_cells["G_local_uniform"]
    )
    collective_gain = paired_summary(
        joint_cells["G_coll_learned"], joint_cells["G_coll_uniform"]
    )
    joint_seed_sets = {
        tuple(sorted(values)) for values in joint_cells.values()
    }
    if (
        local_gain["n"] != 24
        or collective_gain["n"] != 24
        or len(joint_seed_sets) != 1
    ):
        raise SystemExit(
            "ERROR: family-profile data are not a complete 24-seed paired grid"
        )
    joint_summaries = [local_gain, collective_gain]
    joint_labels = ["local loss", "collective loss"]
    joint_colors = [MUTED, BLUE]
    joint_markers = ["D", "o"]
    y_positions = [1, 0]
    ax_joint.axvline(0, color=INK, linewidth=0.8)
    for y_position, summary, label, color, marker in zip(
        y_positions,
        joint_summaries,
        joint_labels,
        joint_colors,
        joint_markers,
    ):
        ax_joint.errorbar(
            summary["mean"],
            y_position,
            xerr=interval_error(summary),
            color=color,
            marker=marker,
            markerfacecolor=PAPER if label == "local loss" else color,
            markeredgecolor=color,
            markersize=7,
            linestyle="none",
            capsize=3,
        )
        if label == "local loss":
            label_x, horizontal = summary["lo"] - 0.07, "right"
        else:
            label_x, horizontal = summary["hi"] + 0.07, "left"
        ax_joint.text(
            label_x,
            y_position,
            f"{summary['mean']:+.2f}",
            ha=horizontal,
            va="center",
            fontsize=8.8,
        )
    ax_joint.set_yticks(y_positions)
    ax_joint.set_yticklabels(joint_labels)
    ax_joint.set_xlim(-0.1, 2.05)
    ax_joint.set_ylim(-0.55, 1.55)
    ax_joint.set_xlabel("gain from learning the profile")
    panel_title(ax_joint, "b", "Profile learning by family")
    style_axis(ax_joint, "x")

    fig.text(
        0.5,
        0.985,
        "Paired 95% t-intervals: rate-profile comparison n=32 (dense grid); "
        "interaction n=24 (exact sparse).",
        ha="center",
        va="top",
        fontsize=8.3,
        color=MUTED,
    )
    fig.subplots_adjust(left=0.10, right=0.99, bottom=0.21, top=0.76, wspace=0.47)
    save(fig, "fig_adaptive.pdf")


def fig_prospective():
    """Diagnostic rule fixed before scoring on an independent task ensemble."""
    if not os.path.isfile(REVISION_PROSPECTIVE):
        raise SystemExit(
            f"ERROR: missing sealed fresh interpolation {REVISION_PROSPECTIVE}"
        )
    with open(REVISION_PROSPECTIVE, encoding="utf-8") as handle:
        result = json.load(handle)
    if (
        result.get("status") != "complete"
        or result.get("diagnostic_seed_count") != 20
        or result.get("fresh_task_seed_count") != 24
        or result.get("seed_overlap_with_frozen_diagnostics") != []
        or result.get("expected_checkpoint_count") != 288
        or result.get("complete_checkpoint_count") != 288
        or result.get("ridge_upper_boundary_hits") != 0
        or "not out-of-family" not in result.get("operator_family_status", "")
    ):
        raise SystemExit(
            "ERROR: fresh interpolation is incomplete or violates its "
            "disjoint-ensemble contract"
        )
    diagnostic_rows = result["frozen_diagnostic_rows"]
    task_rows = result["raw_rows"]
    alphas = [
        float(item["alpha"])
        for item in result["results_by_N"]["4"]["summary"]
    ]
    if alphas != [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]:
        raise SystemExit(f"ERROR: unexpected fresh interpolation grid {alphas}")
    selected_by_n = {
        N: float(result["results_by_N"][str(N)]["frozen_selected_alpha"])
        for N in (4, 5)
    }
    if len(set(selected_by_n.values())) != 1:
        raise SystemExit(
            f"ERROR: frozen selection differs across sizes {selected_by_n}"
        )
    selected_alpha = selected_by_n[4]
    if {
        int(row["seed"]) for row in diagnostic_rows
    } & {
        int(row["seed"]) for row in task_rows
    }:
        raise SystemExit(
            "ERROR: plotted diagnostic and task ensembles are not disjoint"
    )

    fig, (ax_gap, ax_task) = plt.subplots(
        1,
        2,
        figsize=(7.05, 3.15),
        gridspec_kw={"width_ratios": [1, 1]},
    )
    series = {
        4: {"color": SKY, "marker": "s", "linestyle": "--", "fill": PAPER},
        5: {"color": BLUE, "marker": "o", "linestyle": "-", "fill": BLUE},
    }
    summaries = {"gap": {}, "task": {}}
    for N in (4, 5):
        summaries["gap"][N] = []
        summaries["task"][N] = []
        for alpha in alphas:
            gap_values = [
                row["spectral_gap"]
                for row in diagnostic_rows
                if row["N"] == N and float(row["alpha"]) == alpha
            ]
            task_values = [
                row["test_mc"]
                for row in task_rows
                if row["N"] == N and float(row["alpha"]) == alpha
            ]
            summaries["gap"][N].append(t_summary(gap_values))
            summaries["task"][N].append(t_summary(task_values))

    for ax in (ax_gap, ax_task):
        ax.axvspan(
            selected_alpha - 0.035,
            selected_alpha + 0.035,
            facecolor="#FFF0CC",
            edgecolor="none",
            zorder=0,
        )
        ax.axvline(
            selected_alpha,
            color=GOLD,
            linewidth=1.0,
            linestyle=":",
            zorder=1,
        )
        ax.set_xlim(-0.03, 1.07)
        ax.set_xticks(alphas)
        ax.set_xticklabels(
            ["0\nlocal", "0.2", "0.4", "0.6", "0.8", "1\ncollective"]
        )
        endpoint_labels = ax.get_xticklabels()
        endpoint_labels[0].set_ha("left")
        endpoint_labels[-1].set_ha("right")
        ax.set_xlabel(r"collectivity $\alpha$")
        style_axis(ax, "y")

    for N in (4, 5):
        style = series[N]
        for ax, key in ((ax_gap, "gap"), (ax_task, "task")):
            values = summaries[key][N]
            means = np.array([item["mean"] for item in values])
            lower = means - np.array([item["lo"] for item in values])
            upper = np.array([item["hi"] for item in values]) - means
            ax.errorbar(
                alphas,
                means,
                yerr=np.vstack([lower, upper]),
                color=style["color"],
                marker=style["marker"],
                linestyle=style["linestyle"],
                markerfacecolor=style["fill"],
                markeredgecolor=style["color"],
                markeredgewidth=1.1,
                markersize=5.6,
                capsize=2.2,
                elinewidth=1.0,
                label=f"$N={N}$",
                zorder=3,
            )
            selected_index = alphas.index(selected_alpha)
            ax.scatter(
                [selected_alpha],
                [means[selected_index]],
                s=105,
                facecolor="none",
                edgecolor=GOLD,
                linewidth=1.7,
                zorder=4,
            )

    ax_gap.set_ylabel("Liouvillian spectral gap")
    panel_title(ax_gap, "a", "Relaxation rule chosen first")
    ax_gap.legend(frameon=False, loc="lower left")
    ax_gap.text(
        selected_alpha,
        0.97,
        "selected",
        transform=ax_gap.get_xaxis_transform(),
        ha="center",
        va="top",
        fontsize=8.6,
        color="#8A5A00",
        weight="bold",
    )

    ax_task.set_ylabel("held-out STM capacity")
    panel_title(ax_task, "b", "Independent task ensemble")
    rank_four = result["results_by_N"]["4"]
    rank_five = result["results_by_N"]["5"]
    ax_task.text(
        0.04,
        0.95,
        "diagnostic-gap vs task-score ranks\n"
        rf"$N=4:\ \rho={rank_four['frozen_gap_vs_fresh_mean_spearman_rho']:.2f}$, "
        rf"$p={rank_four['frozen_gap_vs_fresh_mean_exact_permutation_p']:.4f}$"
        "\n"
        rf"$N=5:\ \rho={rank_five['frozen_gap_vs_fresh_mean_spearman_rho']:.2f}$, "
        rf"$p={rank_five['frozen_gap_vs_fresh_mean_exact_permutation_p']:.4f}$",
        transform=ax_task.transAxes,
        ha="left",
        va="top",
        fontsize=8.2,
        bbox={"boxstyle": "round,pad=0.28", "fc": PAPER, "ec": GRID, "lw": 0.7},
    )

    fig.suptitle(
        "Within-family check on independent task data",
        x=0.5,
        y=0.985,
        fontsize=10.5,
        weight="bold",
        color=INK,
    )
    fig.text(
        0.5,
        0.91,
        r"Means and 95% t-intervals: diagnostics n=20; independent tasks n=24; "
        "zero shared seeds.\n"
        r"$\alpha=0.8$ was selected before task evaluation; monotone "
        "local-to-collective interpolation.",
        ha="center",
        va="top",
        fontsize=8.1,
        color=MUTED,
        linespacing=1.2,
    )
    fig.subplots_adjust(left=0.09, right=0.995, bottom=0.19, top=0.72, wspace=0.34)
    save(fig, "fig_prospective.pdf")


REQUIRED_BLOCKS = {
    "A_table": 1200,
    "B_scale": 1300,
    "E_diag": 380,
    "F_adaptive": 120,
    "G_joint": 100,
}


def main():
    rows = load()
    counts = {}
    for row in rows:
        block = row.get("block")
        counts[block] = counts.get(block, 0) + 1
    missing = [
        f"  {block}: found {counts.get(block, 0)}, need >= {minimum}"
        for block, minimum in REQUIRED_BLOCKS.items()
        if counts.get(block, 0) < minimum
    ]
    if missing:
        raise SystemExit(
            f"ERROR: {FINAL_DIR} is incomplete:\n"
            + "\n".join(missing)
            + "\nRe-extract results/final_protocol_results.tar.gz before plotting."
        )
    print(f"loaded {len(rows)} canonical result files")
    fig_designspace()
    fig_map(rows)
    fig_scaling(rows)
    fig_predict(rows)
    fig_adaptive(rows)
    fig_prospective()
    fig_budget()
    fig_shotmap()
    print("wrote 8 publication figures to", OUTDIR)


if __name__ == "__main__":
    main()
