"""Regression tests for the critique-response inference layer."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

import revision_inference as inference


ROOT = Path(__file__).resolve().parents[1]


def test_cluster_exclusion_removes_every_duplicate_target_copy():
    methods = ["left"]
    # Target cluster 0 has an extreme validation preference for column 1.
    # The two independent calibration clusters prefer column 0.
    validation = {
        "left": np.asarray(
            [
                [0.0, 1000.0],
                [4.0, 0.0],
                [6.0, 0.0],
            ]
        )
    }
    test = {
        "left": np.asarray(
            [
                [7.0, -7.0],
                [0.0, 0.0],
                [0.0, 0.0],
            ]
        )
    }
    counts = np.asarray([3, 1, 1])

    means, selected = inference.cluster_excluded_selected_means(
        counts, methods, validation, test
    )

    # For target 0, all three copies are excluded, so clusters 1 and 2 choose
    # column 0. Its held-out contribution is therefore +7 rather than -7.
    assert means[0] == 4.2
    assert selected["left"].tolist() == [3, 2]


def test_current_measurement_family_spans_all_210_contrasts():
    aggregate = json.loads(
        (
            ROOT
            / "results"
            / "measurement_full_v3"
            / "measurement_full_aggregate.json"
        ).read_text(encoding="utf-8")
    )
    result = inference.measurement_simultaneous_inference(aggregate)

    assert result["family_size"] == 210
    assert np.isclose(result["critical_t"], 4.512931737106608)
    assert result["first_familywise_resolved_collective_over_local"] == {
        "grouped": "184320",
        "independent": "2949120",
    }


def test_current_joint_learned_comparison_survives_all_pairs_family():
    rows = [
        json.loads(path.read_text(encoding="utf-8"))
        for path in sorted(
            (ROOT / "results" / "final_protocol").glob(
                inference.DEFAULT_JOINT_GLOB
            )
        )
    ]
    result = inference.joint_profile_simultaneous_inference(rows)
    row = next(
        item
        for item in result["pairwise_intervals"]
        if item["left"] == "G_local_learned"
        and item["right"] == "G_coll_learned"
    )

    assert result["family_size"] == 10
    assert row["mean_difference"] < 0.0
    assert row["simultaneous_high"] < 0.0
    assert row["wins"] == 6
    assert np.isclose(-row["mean_difference"], 0.6622642948649515)
    assert np.isclose(-row["simultaneous_high"], 0.032824829768294705)
    assert np.isclose(-row["simultaneous_low"], 1.2917037599616084)
