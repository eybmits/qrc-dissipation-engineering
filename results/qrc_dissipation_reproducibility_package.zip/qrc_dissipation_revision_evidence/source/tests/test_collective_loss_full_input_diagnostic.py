"""Integrity and numerical tests for the collective-loss full-input diagnostic."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pytest

from qrc import dissipators as dsp
from qrc import liouvillian as dense_lio
from qrc.operators import pauli_op

EXPERIMENTS = Path(__file__).resolve().parents[1] / "experiments"
sys.path.insert(0, str(EXPERIMENTS))

import run_collective_loss_full_input_diagnostic as diagnostic  # noqa: E402
import validate_collective_loss_full_input_artifacts as portable  # noqa: E402


def test_protocol_predeclares_full_grid_and_existing_washout_seeds():
    assert len(diagnostic.S_GRID) == 21
    assert diagnostic.S_GRID[0] == 0.0
    assert diagnostic.S_GRID[-1] == 1.0
    assert np.allclose(np.diff(diagnostic.S_GRID), 0.05, rtol=0.0, atol=1e-15)
    expected = tuple(
        int(value)
        for value in np.random.default_rng(2024).integers(
            0,
            2**31 - 1,
            10,
        )
    )
    assert diagnostic.WASHOUT_CONTROL_SEEDS == expected
    assert len(set(expected)) == 10


def test_protocol_declares_model_budget_solver_and_claim_boundary():
    protocol = diagnostic.protocol_dict()
    assert protocol["n_qubits"] == 5
    assert protocol["h"] == 0.5
    assert protocol["dt"] == 0.5
    assert protocol["liouvillian_dimension"] == 1024
    assert protocol["s_grid_count"] == 21
    assert protocol["seed_count"] == 10
    assert "matched" in protocol["jump_budget"]
    assert protocol["dense_solver"]["spectrum"] == (
        "all eigenvalues and right eigenvectors"
    )
    assert len(protocol["sparse_crosscheck"]["cases"]) == 6
    assert "do not prove" in protocol["interpretation_caveat"]
    assert set(protocol["scientific_sources_sha256"]) == set(
        diagnostic.SOURCE_FILES
    )


def test_dense_analysis_is_deterministic_and_has_small_residuals():
    n_qubits = 2
    hamiltonian = (
        0.31 * pauli_op("x", 0, n_qubits)
        + 0.17 * pauli_op("z", 1, n_qubits)
        + 0.23
        * (
            pauli_op("x", 0, n_qubits)
            @ pauli_op("x", 1, n_qubits)
        )
    )
    jumps = dsp.local_loss(n_qubits, 0.7)
    matrix = dense_lio.lindbladian(hamiltonian, jumps)
    first, first_values = diagnostic.analyze_dense_liouvillian(matrix)
    second, second_values = diagnostic.analyze_dense_liouvillian(matrix)
    assert diagnostic._canonical_json(first) == diagnostic._canonical_json(second)
    assert np.array_equal(first_values, second_values)
    assert first["eigenvalue_count"] == 16
    assert first["stationary_mode_count"] == 1
    assert first["first_nonstationary_decay_gap"] > 0.0
    assert first["max_all_mode_relative_residual"] < (
        diagnostic.RELATIVE_RESIDUAL_TOL
    )


def test_generated_artifacts_cover_full_grid_and_hash_chain():
    aggregate = portable.validate_complete_artifacts()
    protocol_file = json.loads(diagnostic.PROTOCOL_PATH.read_text())
    raw = json.loads(diagnostic.RAW_PATH.read_text())

    assert protocol_file["status"] == "frozen_before_diagnostic_rows"
    assert raw["protocol_sha256"] == protocol_file["protocol_sha256"]
    assert aggregate["protocol_sha256"] == protocol_file["protocol_sha256"]
    assert aggregate["raw_payload_sha256"] == diagnostic._sha256_json(raw)
    assert aggregate["raw_file_sha256"] == diagnostic._sha256_file(
        diagnostic.RAW_PATH
    )
    assert aggregate["protocol_file_sha256"] == diagnostic._sha256_file(
        diagnostic.PROTOCOL_PATH
    )

    expected = {
        (seed, s_index)
        for seed in diagnostic.WASHOUT_CONTROL_SEEDS
        for s_index in range(len(diagnostic.S_GRID))
    }
    observed = {(row["seed"], row["s_index"]) for row in raw["rows"]}
    assert raw["row_count"] == 210
    assert len(raw["rows"]) == 210
    assert observed == expected
    assert len(observed) == len(raw["rows"])
    assert all(len(row["spectrum"]) == 1024 for row in raw["rows"])


def test_artifact_validation_is_runtime_version_independent(monkeypatch):
    monkeypatch.setattr(diagnostic.platform, "python_version", lambda: "0.0")
    monkeypatch.setattr(diagnostic.np, "__version__", "0.0")
    monkeypatch.setattr(diagnostic.scipy, "__version__", "0.0")
    aggregate = portable.validate_complete_artifacts()
    assert aggregate["row_count"] == 210


def test_artifact_validation_rejects_scientific_source_drift(monkeypatch):
    hashes = diagnostic._source_hashes()  # noqa: SLF001
    hashes["src/qrc/tasks.py"] = "0" * 64
    monkeypatch.setattr(diagnostic, "_source_hashes", lambda: hashes)
    with pytest.raises(RuntimeError, match="scientific field"):
        portable.validate_complete_artifacts()


def test_generated_spectra_are_unique_gapped_finite_and_accurate():
    raw = json.loads(diagnostic.RAW_PATH.read_text())
    gaps = np.asarray(
        [row["first_nonstationary_decay_gap"] for row in raw["rows"]]
    )
    assert np.all(np.isfinite(gaps))
    assert np.all(gaps > diagnostic.MIN_GAP_TOL)
    assert all(row["stationary_mode_count"] == 1 for row in raw["rows"])
    assert max(
        row["positive_real_part_leakage"] for row in raw["rows"]
    ) <= diagnostic.POSITIVE_REAL_TOL
    assert max(
        row["max_all_mode_relative_residual"] for row in raw["rows"]
    ) <= diagnostic.RELATIVE_RESIDUAL_TOL
    assert max(
        row["trace_preservation_relative_residual"] for row in raw["rows"]
    ) <= diagnostic.TRACE_PRESERVATION_TOL
    assert max(
        row["relative_jump_budget_error"] for row in raw["rows"]
    ) <= 1e-14


def test_sparse_crosschecks_are_complete_and_within_tolerance():
    aggregate = json.loads(diagnostic.AGGREGATE_PATH.read_text())
    assert aggregate["sparse_crosscheck_count"] == len(
        diagnostic.SPARSE_CROSSCHECK_CASES
    )
    observed = {
        (row["seed"], row["s"]) for row in aggregate["sparse_crosschecks"]
    }
    assert observed == set(diagnostic.SPARSE_CROSSCHECK_CASES)
    assert aggregate["maximum_sparse_matrix_abs_difference"] <= (
        diagnostic.SPARSE_MATRIX_TOL
    )
    assert aggregate["maximum_sparse_dense_eigenvalue_abs_difference"] <= (
        diagnostic.SPARSE_EIGENVALUE_TOL
    )
    assert aggregate["maximum_sparse_relative_residual"] <= (
        diagnostic.SPARSE_RELATIVE_RESIDUAL_TOL
    )
    assert all(
        row["near_zero_sparse_stationary_count"] == 1
        for row in aggregate["sparse_crosschecks"]
    )


def test_report_explicitly_rejects_switched_input_proof_claim():
    report = diagnostic.REPORT_PATH.read_text(encoding="utf-8")
    assert "do not prove" in report
    assert "arbitrary switched-input" in report
    assert "**Status: PASS.**" in report


def test_aggregate_validator_fails_closed_on_zero_gap():
    aggregate = json.loads(diagnostic.AGGREGATE_PATH.read_text())
    broken = json.loads(json.dumps(aggregate))
    broken["minimum_sampled_gap"]["gap"] = 0.0
    with pytest.raises(RuntimeError, match="minimum sampled gap"):
        diagnostic._validate_aggregate(broken)
