"""Tests for the sealed target-only forecasting baseline audit."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest


EXPERIMENTS = Path(__file__).resolve().parents[1] / "experiments"
sys.path.insert(0, str(EXPERIMENTS))

import forecast_baseline_audit as forecast  # noqa: E402


@pytest.fixture(scope="module")
def audit() -> dict[str, object]:
    return forecast.build_audit()


def test_audit_uses_the_complete_sealed_grid(audit):
    assert audit["status"] == "complete"
    assert audit["expected_checkpoints"] == 8 * 64
    assert audit["complete_checkpoints"] == 8 * 64
    protocol = audit["protocol"]
    assert protocol["forecast_horizon"] == 150
    assert protocol["seed_count"] == 64
    assert forecast.HORIZON == forecast.TCFG.mg_horizon
    assert forecast.MG_SAMPLE_EVERY == forecast.TCFG.mg_sample_every
    assert protocol["mackey_glass"] == {
        "tau": 17,
        "beta": 0.2,
        "decay": 0.1,
        "exponent": 10,
        "integration_step": 1.0,
        "sample_every": 3,
        "initial_value": 1.2,
        "discarded_integration_samples": 500,
    }


def test_stored_artifact_matches_the_deterministic_rebuild(audit):
    stored_path = (
        Path(__file__).resolve().parents[1]
        / "results"
        / "forecast_baseline_audit"
        / "aggregate.json"
    )
    stored = json.loads(stored_path.read_text(encoding="utf-8"))
    assert stored == audit
    claimed = stored.pop("deterministic_payload_sha256")
    recomputed = forecast._sha256(  # noqa: SLF001
        forecast._canonical_json(stored).encode("utf-8")  # noqa: SLF001
    )
    assert claimed == recomputed


def test_simple_baseline_means_match_the_canonical_stream(audit):
    baselines = audit["baseline_summaries"]
    assert baselines["training_mean"]["mean"] == pytest.approx(
        0.05988117726234181
    )
    assert baselines["last_value"]["mean"] == pytest.approx(
        0.10512461672287352
    )


def test_dephasing_is_the_training_mean_prediction(audit):
    validation = audit["validation"]
    assert validation["dephasing_matches_training_mean_seedwise"] is True
    assert (
        validation[
            "maximum_dephasing_minus_training_mean_mse_absolute_error"
        ]
        < 1e-12
    )


def test_collective_forecast_interpretation_is_bounded(audit):
    collective = audit["paired_comparisons"]["B3_collective"]
    versus_mean = collective["versus_training_mean"]
    versus_last = collective["versus_last_value"]
    assert versus_mean["mean"] == pytest.approx(0.03700192125682818)
    assert versus_mean["descriptive_95pct_t_interval"][0] > 0.0
    assert versus_last["descriptive_95pct_t_interval"][0] < 0.0
    assert versus_last["descriptive_95pct_t_interval"][1] > 0.0


@pytest.mark.parametrize(
    "method",
    (
        "CD_paper",
        "A1_heterogeneous",
        "B5_pair",
        "B2_thermal",
    ),
)
def test_four_reservoirs_have_lower_errors_than_both_simple_predictions(
    audit, method
):
    comparison = audit["paired_comparisons"][method]
    assert comparison["versus_training_mean"][
        "interval_excludes_zero_in_better_direction"
    ]
    assert comparison["versus_last_value"][
        "interval_excludes_zero_in_better_direction"
    ]
