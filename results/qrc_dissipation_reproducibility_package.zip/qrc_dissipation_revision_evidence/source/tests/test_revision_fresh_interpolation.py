"""Tests for the fresh-only interpolation aggregation and provenance."""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

EXPERIMENTS = Path(__file__).resolve().parents[1] / "experiments"
sys.path.insert(0, str(EXPERIMENTS))

import run_revision_fresh_interpolation as fresh  # noqa: E402
import run_revision_tuning as base  # noqa: E402


def test_exact_six_point_spearman_enumerates_720_permutations():
    result = fresh.exact_spearman_permutation(
        [0, 1, 2, 3, 4, 5],
        [10, 11, 12, 13, 14, 15],
    )
    assert result["rho"] == 1.0
    assert result["exact"]
    assert result["n_permutations"] == 720
    assert np.isclose(result["exact_p_two_sided"], 2 / 720)


def test_fresh_protocol_is_disjoint_and_self_describing():
    protocol = fresh.protocol_payload()
    task = protocol["task_protocol"]
    source = protocol["frozen_diagnostic_source"]
    assert source["diagnostic_seed_count"] == 20
    assert task["fresh_task_seed_count"] == 24
    assert task["seed_overlap_with_frozen_diagnostics"] == []
    assert task["expected_checkpoint_count"] == 288
    assert task["ridge_grid"][-1] == 100.0
    assert "not out-of-family" in task["operator_family_status"]
    assert fresh.HELPER_RELATIVE in protocol["scientific_sources_sha256"]
    assert fresh.MAIN_RELATIVE in protocol["scientific_sources_sha256"]


def test_main_fresh_job_hard_fails_at_ridge_upper_boundary_contract():
    assert base.RIDGES[-4:] == (0.1, 1.0, 10.0, 100.0)
    pools = base.seed_namespaces()
    assert not (
        set(pools["fresh_interpolation"])
        & set(pools["legacy_diagnostic"])
    )
