"""Protocol and artifact tests for the append-only nested-search extension."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

EXPERIMENTS = Path(__file__).resolve().parents[1] / "experiments"
sys.path.insert(0, str(EXPERIMENTS))

import run_nested_operating_point_extension as extension  # noqa: E402
import run_revision_tuning as base  # noqa: E402
import validate_nested_operating_point_artifacts as portable  # noqa: E402


def _ranking_entry(config, mean, ridge=1e-6):
    return {
        "config": list(config),
        "best_ridge": ridge,
        "ridge_upper_boundary_unresolved": False,
        "mean_validation_mc": mean,
    }


def test_common_screen_grid_is_identical_and_extends_through_x128():
    assert extension.BASE_STRENGTHS[: len(base.NESTED_MULTIPLIERS)] == (
        base.NESTED_MULTIPLIERS
    )
    assert extension.BASE_STRENGTHS[-3:] == (32.0, 64.0, 128.0)
    grid = extension.common_grid(extension.BASE_STRENGTHS)
    expected = (
        len(extension.H_GRID)
        * len(extension.DT_GRID)
        * len(extension.BASE_STRENGTHS)
    )
    assert len(grid) == expected
    assert len(grid) == len(set(grid))
    assert (0.25, 0.1, 128.0) in grid
    assert extension.CHANNELS == ("CD_paper", "B3_collective")


def test_source_reuse_is_byte_compatible_with_sealed_protocol():
    manifest = extension.validate_source_protocol()
    assert manifest["protocol_sha256"] == (
        "fabd0c774f6d966591c0cf800f4cead24bdfe4f5cb86b78cea4ce64e5ce6673b"
    )
    source_hashes = manifest["protocol"]["scientific_sources_sha256"]
    current_hashes = extension._current_source_hashes()  # noqa: SLF001
    for path, expected in source_hashes.items():
        assert current_hashes[path] == expected


def test_fresh_test_seeds_exclude_every_sealed_namespace_and_are_hashed():
    ledger = extension.seed_ledger_payload()
    excluded = set(ledger["excluded_seeds"])
    fresh = ledger["fresh_test_seeds"]
    assert len(fresh) == extension.TEST_SEEDS
    assert len(fresh) == len(set(fresh))
    assert not (set(fresh) & excluded)
    assert set(ledger["known_old_test_seeds"]) <= excluded
    assert set(ledger["reused_screen_seeds"]) <= excluded
    assert set(ledger["reused_selection_seeds"]) <= excluded
    assert ledger["excluded_seeds_sha256"] == extension.sha256_json(
        ledger["excluded_seeds"]
    )
    assert ledger["fresh_test_seeds_sha256"] == extension.sha256_json(fresh)


def test_collective_bracket_requires_immediate_full_selection_neighbors():
    strengths = (8.0, 16.0, 32.0, 64.0)
    incomplete = [_ranking_entry((0.5, 1.0, 32.0), 10.0)]
    missing = extension.immediate_bracket(incomplete, strengths)
    assert not missing["bracketed"]
    assert missing["reason"] == "immediate_selection_neighbors_missing"
    assert missing["required_configs"] == [
        [0.5, 1.0, 16.0],
        [0.5, 1.0, 64.0],
    ]

    complete = [
        _ranking_entry((0.5, 1.0, 32.0), 10.0),
        _ranking_entry((0.5, 1.0, 16.0), 9.0),
        _ranking_entry((0.5, 1.0, 64.0), 8.0),
    ]
    bracket = extension.immediate_bracket(complete, strengths)
    assert bracket["bracketed"]
    assert bracket["reason"] == "strict_local_maximum_on_full_selection_ensemble"


def test_collective_boundary_requires_predeclared_doubling():
    strengths = (16.0, 32.0, 64.0, 128.0)
    ranking = [_ranking_entry((0.25, 1.0, 128.0), 10.0)]
    bracket = extension.immediate_bracket(ranking, strengths)
    assert not bracket["bracketed"]
    assert bracket["reason"] == "selected_strength_at_common_grid_boundary"
    mutable = list(strengths)
    extension._extend_strengths(mutable)  # noqa: SLF001
    assert mutable[-1] == 256.0


def test_json_roundtrip_hash_is_stable_with_integer_seed_keys():
    payload = {
        "scores_by_seed": {
            2: 1.25,
            10: 2.5,
            101: 3.75,
        }
    }
    round_tripped = json.loads(extension.canonical_json(payload))
    assert extension.json_roundtrip_sha256(payload) == (
        extension.sha256_json(round_tripped)
    )
    assert extension.json_roundtrip_sha256(payload) == (
        extension.json_roundtrip_sha256(round_tripped)
    )


def test_ridge_boundary_is_not_releasable_as_a_bracket():
    strengths = (8.0, 16.0, 32.0)
    ranking = [
        _ranking_entry((0.5, 1.0, 16.0), 10.0),
        _ranking_entry((0.5, 1.0, 8.0), 9.0),
        {
            **_ranking_entry((0.5, 1.0, 32.0), 8.0, ridge=base.RIDGES[-1]),
            "ridge_upper_boundary_unresolved": True,
        },
    ]
    bracket = extension.immediate_bracket(ranking, strengths)
    assert not bracket["bracketed"]
    assert bracket["reason"] == "ridge_upper_boundary_unresolved"


def test_complete_artifacts_are_paired_frozen_and_deterministic():
    if not extension.AGGREGATE_PATH.is_file():
        pytest.skip("full extension results have not been generated yet")
    aggregate = portable.validate_complete_artifacts()
    assert aggregate["common_grid_identical_for_channels"] is True
    assert aggregate["freeze_before_test_verified"] is True
    assert aggregate["seed_disjointness_verified"] is True
    assert aggregate["selected_ridge_upper_boundary_hits"] == 0
    assert aggregate["collective_vs_local"]["n"] == extension.TEST_SEEDS
    assert aggregate["coverage"]["fresh_test_complete"] == (
        len(extension.CHANNELS) * extension.TEST_SEEDS
    )

    selection_sha = extension.sha256_file(extension.SELECTION_PATH)
    test_rows = portable.validate_test_rows()
    assert {row["selection_sha256"] for row in test_rows} == {selection_sha}
    assert {
        (row["method"], row["seed"]) for row in test_rows
    } == {
        (method, seed)
        for method in extension.CHANNELS
        for seed in extension.seed_ledger_payload()["fresh_test_seeds"]
    }

    raw = json.loads(extension.AGGREGATE_PATH.read_text())
    stored = raw.pop("deterministic_payload_sha256")
    assert extension.sha256_json(raw) == stored


def test_portable_validation_does_not_require_git_metadata(monkeypatch):
    if not extension.AGGREGATE_PATH.is_file():
        pytest.skip("full extension results have not been generated yet")
    monkeypatch.setattr(extension, "git_head", lambda: None)
    aggregate = portable.validate_complete_artifacts()
    assert aggregate["protocol_sha256"] == (
        "1696169ac2b11c3bc832a562c1c0745a943ac1de555b5b7dab2e6f7d48275357"
    )


def test_portable_validation_rejects_scientific_source_drift(monkeypatch):
    current = extension._current_source_hashes()  # noqa: SLF001
    current["src/qrc/tasks.py"] = "0" * 64
    monkeypatch.setattr(extension, "_current_source_hashes", lambda: current)
    with pytest.raises(RuntimeError, match="scientific source differs"):
        portable.validate_complete_artifacts()


def test_missing_frozen_commit_is_allowed_only_in_shallow_history(monkeypatch):
    def shallow_run(args, **kwargs):
        if args[1] == "cat-file":
            return SimpleNamespace(returncode=128, stdout="")
        assert args[1:] == ["rev-parse", "--is-shallow-repository"]
        return SimpleNamespace(returncode=0, stdout="true\n")

    monkeypatch.setattr(portable.subprocess, "run", shallow_run)
    assert portable._recorded_commit_available("a" * 40) is False

    def full_run(args, **kwargs):
        if args[1] == "cat-file":
            return SimpleNamespace(returncode=128, stdout="")
        return SimpleNamespace(returncode=0, stdout="false\n")

    monkeypatch.setattr(portable.subprocess, "run", full_run)
    with pytest.raises(RuntimeError, match="unavailable from full Git history"):
        portable._recorded_commit_available("a" * 40)
