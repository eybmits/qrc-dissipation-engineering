import json
import math
from pathlib import Path

import build_revision_tuning_report as report


def _strength() -> dict:
    return json.loads(report.STRENGTH_PATH.read_text())


def test_simultaneous_family_covers_all_fifteen_pairs():
    result = report.simultaneous_pairwise_intervals(_strength())
    assert result["pair_count"] == 15
    assert result["degrees_of_freedom"] == 19
    assert len(result["pairs"]) == 15
    assert math.isclose(result["critical_t"], 3.3540361784427204)


def test_all_collective_intervals_exclude_zero():
    result = report.simultaneous_pairwise_intervals(_strength())
    thermal = report._oriented_pair(
        result, "B3_collective", "B2_thermal"
    )
    local = report._oriented_pair(result, "B3_collective", "CD_paper")
    assert math.isclose(
        thermal["simultaneous_ci95_low"], 0.8735886933105357
    )
    assert math.isclose(
        local["simultaneous_ci95_low"], 1.3826401222457099
    )
    for competitor in report.CHANNELS:
        if competitor != "B3_collective":
            assert (
                report._oriented_pair(
                    result, "B3_collective", competitor
                )["simultaneous_ci95_low"]
                > 0
            )


def test_reporter_never_calls_exact_sign_test_sign_flip():
    source = Path(report.__file__).read_text()
    assert "sign-flip" not in source
