"""Tests for the isolated camera-ready primary-task regularisation control."""

from __future__ import annotations

import copy
import json
import sys
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
EXPERIMENTS = ROOT / "experiments"
sys.path.insert(0, str(EXPERIMENTS))

import run_revision_primary_regularization as control  # noqa: E402
import validate_revision_primary_regularization_artifacts as portable  # noqa: E402


def test_protocol_freezes_complete_primary_design():
    protocol = control.build_protocol()
    assert tuple(protocol["methods"]) == control.METHODS
    assert protocol["seeds"] == control.deterministic_seeds(32)
    assert protocol["n_jobs"] == 7 * 32
    assert protocol["split"] == {
        "wash": 200,
        "train": 450,
        "validation": 150,
        "test": 400,
        "total_inputs": 1200,
        "post_wash_rows": 1000,
        "expected_effective_train_rows": {
            "stm_by_delay": list(range(449, 429, -1)),
            "narma": 440,
        },
        "expected_effective_refit_rows": {
            "stm_by_delay": list(range(599, 579, -1)),
            "narma": 590,
        },
        "expected_effective_validation_rows": 150,
        "expected_effective_test_rows": 400,
        "test_untouched_until_final_scoring": True,
    }
    assert tuple(protocol["readout"]["ridge_grid"]) == control.RIDGES
    assert protocol["readout"]["ridge_grid"][0] == 0.0
    assert protocol["readout"]["ridge_grid"][-1] == 100.0
    assert protocol["source_environment_sha256"] == control.sha256_json(
        protocol["source_environment"]
    )
    baseline = protocol["baseline_reproduction"]
    assert len(baseline["entries"]) == 2 * 7 * 32
    assert baseline["entries_sha256"] == control.sha256_json(baseline["entries"])


def test_feature_guard_is_train_only_and_preserves_bias():
    train = np.column_stack(
        [
            np.ones(8),
            np.arange(8, dtype=float),
            np.full(8, 4.0) + 1e-14 * np.arange(8),
        ]
    )
    validation = np.column_stack(
        [np.arange(3), np.arange(3), np.array([0.0, 1e8, -1e8])]
    )
    test = validation * 2
    guarded = control.train_only_feature_guard(train, validation, test)
    x_train, x_validation, x_test, metadata = guarded
    assert metadata["retained_nonbias_indices"] == [1]
    assert metadata["dropped_nonbias_indices"] == [0, 2]
    assert x_train.shape == (8, 2)
    assert x_validation.shape == (3, 2)
    assert x_test.shape == (3, 2)
    assert np.all(x_train[:, -1] == 1.0)
    assert np.all(x_validation[:, -1] == 1.0)
    assert np.all(x_test[:, -1] == 1.0)


def test_ridge_selection_ignores_test_and_refit_uses_validation(monkeypatch):
    x_train = np.array([[1.0, 1.0], [2.0, 1.0], [3.0, 1.0]])
    y_train = np.array([1.0, 2.0, 3.0])
    x_validation = np.array([[4.0, 1.0], [5.0, 1.0]])
    y_validation = np.array([4.0, 5.0])
    x_test = np.array([[6.0, 1.0]])
    calls = []
    original = control.refit_and_test

    def recording_refit(*args, **kwargs):
        calls.append((args[0].shape[0], args[2].shape[0], float(args[6])))
        return original(*args, **kwargs)

    monkeypatch.setattr(control, "refit_and_test", recording_refit)
    first = control.select_and_refit(
        x_train,
        y_train,
        x_validation,
        y_validation,
        x_test,
        np.array([6.0]),
        metric="nmse",
        ridges=(0.0, 1e-8, 1.0),
    )
    second = control.select_and_refit(
        x_train,
        y_train,
        x_validation,
        y_validation,
        x_test,
        np.array([-999.0]),
        metric="nmse",
        ridges=(0.0, 1e-8, 1.0),
    )
    assert first["selected_ridge"] == second["selected_ridge"]
    assert all(train_rows == 3 and validation_rows == 2 for train_rows, validation_rows, _ in calls)
    assert {ridge for _, _, ridge in calls} >= {first["selected_ridge"]}


def test_stm_selects_one_ridge_across_all_target_columns():
    rng = np.random.default_rng(7)
    x_train = control.readout.add_bias(rng.normal(size=(450, 3)))
    x_validation = control.readout.add_bias(rng.normal(size=(10, 3)))
    x_test = control.readout.add_bias(rng.normal(size=(12, 3)))
    weights = rng.normal(size=(4, 20))
    y_train = x_train @ weights
    for column, delay in enumerate(control.STM_DELAYS):
        y_train[:delay, column] = np.nan
    y_validation = x_validation @ weights
    y_test = x_test @ weights
    result = control.select_and_refit_stm(
        x_train,
        y_train,
        x_validation,
        y_validation,
        x_test,
        y_test,
        ridges=(0.0, 1e-8, 1.0),
    )
    assert result["metric"] == "capacity"
    assert len(result["selected_test_by_target"]) == 20
    assert len(result["fixed_test_by_target"]) == 20
    assert set(result["validation_by_ridge"]) == {"0", "1e-08", "1"}
    assert result["effective_train_rows_by_target"] == list(range(449, 429, -1))
    assert result["effective_refit_rows_by_target"] == list(range(459, 439, -1))


def _synthetic_rows(protocol: dict) -> list[dict]:
    rows = []
    for method_index, method in enumerate(protocol["methods"]):
        for seed_index, seed in enumerate(protocol["seeds"]):
            stm_baseline = protocol["baseline_reproduction"]["entries"][
                f"stm/{method}/{seed}"
            ]["value"]
            narma_baseline = protocol["baseline_reproduction"]["entries"][
                f"narma/{method}/{seed}"
            ]["value"]
            stm_selected = stm_baseline + 0.01
            narma_selected = narma_baseline - 0.01
            task_results = {
                "stm": {
                    "metric": "capacity",
                    "selected_ridge": 1e-4,
                    "fixed_ridge": 1e-8,
                    "selected_test": stm_selected,
                    "fixed_test": stm_baseline,
                    "selection_improvement": 0.01,
                    "selected_test_by_target": [stm_selected / 20] * 20,
                    "fixed_test_by_target": [stm_baseline / 20] * 20,
                    "effective_train_rows_by_target": list(
                        range(449, 429, -1)
                    ),
                    "effective_refit_rows_by_target": list(
                        range(599, 579, -1)
                    ),
                },
                "narma": {
                    "metric": "nmse",
                    "selected_ridge": 1e-4,
                    "fixed_ridge": 1e-8,
                    "selected_test": narma_selected,
                    "fixed_test": narma_baseline,
                    "selection_improvement": 0.01,
                    "selected_test_by_target": [narma_selected],
                    "fixed_test_by_target": [narma_baseline],
                },
            }
            rows.append(
                {
                    "protocol_sha256": control.protocol_sha256(protocol),
                    "source_environment_sha256": protocol[
                        "source_environment_sha256"
                    ],
                    "method": method,
                    "seed": seed,
                    "backend": "SparseLindbladReservoir exact expm_multiply",
                    "wash_rows": 200,
                    "raw_train_rows": 450,
                    "raw_validation_rows": 150,
                    "raw_test_rows": 400,
                    "effective_rows": {
                        "stm": {
                            "train_by_target": list(range(449, 429, -1)),
                            "validation": 150,
                            "test": 400,
                            "refit_by_target": list(range(599, 579, -1)),
                        },
                        "narma": {
                            "train": 440,
                            "validation": 150,
                            "test": 400,
                            "refit": 590,
                        },
                    },
                    "raw_feature_count": 45,
                    "task_results": task_results,
                    "jump_strength_error": 0.0,
                    "runtime_seconds": 1.0 + seed_index,
                    "feature_guard": {
                        "fit_on": "training rows only",
                        "threshold": 1e-12,
                        "retained_nonbias_features": 45,
                        "dropped_nonbias_features": 0,
                        "retained_features_including_bias": 46,
                    },
                    "coupling_sha256": f"coupling-{seed}",
                    "full_input_sha256": f"full-{seed}",
                    "post_wash_input_sha256": f"post-{seed}",
                    "target_sha256": {
                        "stm": f"stm-target-{seed}",
                        "narma": f"narma-target-{seed}",
                    },
                    "train_split_sha256": f"train-{seed}",
                    "validation_split_sha256": f"validation-{seed}",
                    "test_split_sha256": f"test-{seed}",
                }
            )
    return rows


def test_pairing_audit_catches_a_changed_hash():
    protocol = control.build_protocol(
        methods=control.METHODS,
        seeds=control.deterministic_seeds(32)[:2],
    )
    rows = _synthetic_rows(protocol)
    assert control.invariant_audit(rows, protocol)["passed"]
    rows[0]["test_split_sha256"] = "unpaired"
    audit = control.invariant_audit(rows, protocol)
    assert not audit["passed"]
    assert any("unpaired test_split_sha256" in error for error in audit["errors"])


def test_upper_ridge_boundary_is_fatal():
    rows = [
        {
            "method": "CD_paper",
            "seed": 1,
            "task_results": {
                "stm": {
                    "selected_ridge": 100.0,
                    "validation_by_ridge": {"10": 2.0, "100": 3.0},
                },
                "narma": {"selected_ridge": 1.0},
            },
        }
    ]
    audit = control.ridge_boundary_audit(rows)
    assert not audit["passed"]
    assert audit["selected_at_maximum_count"] == 1
    assert audit["unresolved_upper_boundary_count"] == 1


def test_flat_upper_ridge_plateau_is_bracketed():
    rows = [
        {
            "method": "B1_dephasing",
            "seed": 1,
            "task_results": {
                "stm": {
                    "selected_ridge": 100.0,
                    "validation_by_ridge": {"10": 0.0, "100": 0.0},
                },
                "narma": {"selected_ridge": 1.0},
            },
        }
    ]
    audit = control.ridge_boundary_audit(rows)
    assert audit["passed"]
    assert audit["selected_at_maximum_count"] == 1
    assert audit["unresolved_upper_boundary_count"] == 0


def test_aggregation_is_deterministic_under_input_order():
    protocol = control.build_protocol(
        methods=control.METHODS,
        seeds=control.deterministic_seeds(32)[:2],
    )
    rows = _synthetic_rows(protocol)
    forward = control.build_aggregate(copy.deepcopy(rows), protocol)
    reverse = control.build_aggregate(copy.deepcopy(list(reversed(rows))), protocol)
    assert forward == reverse
    assert forward["status"] == "complete"
    for task_name in control.TASKS:
        ranking = forward["task_summaries"][task_name]["ranking"]
        assert {row["method"] for row in ranking} == set(control.METHODS)
        assert len(ranking) == len(control.METHODS)


def test_baseline_reproduction_audit_fails_on_active_score_drift():
    protocol = control.build_protocol(
        methods=control.METHODS,
        seeds=control.deterministic_seeds(32)[:2],
    )
    rows = _synthetic_rows(protocol)
    assert control.baseline_reproduction_audit(rows, protocol)["passed"]
    active = next(row for row in rows if row["method"] == "CD_paper")
    active["task_results"]["stm"]["fixed_test"] += 1e-3
    audit = control.baseline_reproduction_audit(rows, protocol)
    assert not audit["passed"]
    assert any(
        violation["reason"] == "fixed score drifted from baseline"
        for violation in audit["violations"]
    )


def test_production_artifacts_are_complete_and_reproducible():
    """End-to-end artifact contract; run after generating the full control."""
    outdir = control.DEFAULT_OUTDIR
    protocol_file = control.protocol_path(outdir)
    aggregate_file = control.aggregate_path(outdir)
    if not protocol_file.exists() or not aggregate_file.exists():
        pytest.skip("full primary-task regularisation artifacts not generated")
    rebuilt = portable.validate_complete_artifacts()
    assert rebuilt["n_jobs"] == 224
    assert rebuilt["status"] == "complete"
    assert rebuilt["invariant_audit"]["passed"]
    assert rebuilt["ridge_boundary_audit"]["passed"]
    assert rebuilt["baseline_reproduction_audit"]["passed"]
    assert control.DEFAULT_REPORT.exists()


def test_production_validation_is_runtime_version_independent(monkeypatch):
    if not control.protocol_path(control.DEFAULT_OUTDIR).is_file():
        pytest.skip("full primary-task regularisation artifacts not generated")
    monkeypatch.setattr(control.platform, "python_version", lambda: "0.0")
    monkeypatch.setattr(control.np, "__version__", "0.0")
    monkeypatch.setattr(control.scipy, "__version__", "0.0")
    aggregate = portable.validate_complete_artifacts()
    assert aggregate["n_jobs"] == 224


def test_production_validation_rejects_scientific_source_drift(monkeypatch):
    if not control.protocol_path(control.DEFAULT_OUTDIR).is_file():
        pytest.skip("full primary-task regularisation artifacts not generated")
    source = control.source_environment_manifest()
    source["files"]["src/qrc/tasks.py"] = "0" * 64
    monkeypatch.setattr(control, "source_environment_manifest", lambda: source)
    with pytest.raises(RuntimeError, match="scientific sources differ"):
        portable.validate_complete_artifacts()


def test_portable_aggregate_comparison_limits_tolerance_to_ci_endpoints():
    stored = {
        "mean": 1.0,
        "ci95_low": 0.5,
        "ci95_high": 1.5,
    }
    rounding_only = {**stored, "ci95_low": 0.5 + 5e-17}
    portable._assert_portable_aggregate_equal(stored, rounding_only)

    changed_ci = {**stored, "ci95_low": 0.5 + 2e-15}
    with pytest.raises(RuntimeError, match="ci95_low"):
        portable._assert_portable_aggregate_equal(stored, changed_ci)

    changed_mean = {**stored, "mean": 1.0 + 2e-16}
    with pytest.raises(RuntimeError, match="mean"):
        portable._assert_portable_aggregate_equal(stored, changed_mean)
