"""One cluster job: evaluate ONE (N, method, seed, task) and checkpoint the result.

Embarrassingly parallel: launch one job per (N, method, seed, task) tuple (see
submit_scaling.sbatch). Writes results/cluster/<task>_N<N>_<method>_s<seed>.json and
skips if it already exists (restart-safe). Uses cached dense propagators for small
N and expm_multiply for large N (memory-aware).

Example:
    python scaling_job.py --N 6 --method B3_collective --seed 12345 --task stm
"""
import argparse
import json
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(ROOT, "src"))
OUTDIR = os.path.join(ROOT, "results", "cluster")
os.makedirs(OUTDIR, exist_ok=True)

import numpy as np
from qrc import reservoirs as res, readout, tasks, dissipators as dsp
from qrc.reservoirs import ising_xx_hamiltonian, transverse_drive, LindbladReservoir

# --- configuration (edit for the production run) ---------------------------
H, DT, GAMMA = 0.5, 0.5, 1.0          # matched-budget operating point
WASH, TRAIN, TEST = 1000, 1000, 1000  # paper scale
NARMA_ORDER, INPUT_SCALE = 10, 0.2
QUANT_SMALL = 64                      # cache propagators for N <= 5
N_CACHE_MAX = 5


def build_jumps(method, J, N, s, rng):
    if method == "FN":
        return None
    if method == "CD_paper":
        return dsp.normalize_jump_strength(dsp.local_loss(N, 1.0), s)
    if method == "A1_heterogeneous":
        g = dsp.loguniform_rates(N, 0.1, 10, rng, mean=1.0)
        return [(res.sminus(i, N), float(g[i])) for i in range(N)]
    if method == "B1_dephasing":
        return dsp.normalize_jump_strength(dsp.dephasing(N, 1.0), s)
    if method == "B2_thermal":
        return dsp.normalize_jump_strength(dsp.thermal(N, 1.0, 0.3), s)
    if method == "B3_collective":
        return dsp.normalize_jump_strength(dsp.collective_loss(N, 1.0), s)
    if method == "B4_loss_exchange":
        edges = dsp.graph_edges(J)
        return (dsp.normalize_jump_strength(dsp.local_loss(N, 1.0), 0.4 * s)
                + dsp.normalize_jump_strength(dsp.exchange(N, 1.0, edges), 0.6 * s))
    if method == "B5_pair":
        e = [(i, j) for i in range(N) for j in range(i + 1, N) if abs(J[i, j]) > 1e-9]
        return dsp.normalize_jump_strength(dsp.pair_loss(N, 1.0, e), s)
    raise ValueError(method)


def make_reservoir(method, J, N, s, rng):
    if method == "FN":
        return res.FujiNakajimaReservoir(N, J, H, DT)
    jumps = build_jumps(method, J, N, s, rng)
    H0 = ising_xx_hamiltonian(J, H, N); Hx = transverse_drive(N)
    quant = QUANT_SMALL if N <= N_CACHE_MAX else None  # expm_multiply for large N
    return LindbladReservoir.from_terms(N, H0 + H * Hx, H * Hx, jumps, DT, quantize=quant)


def stm_mc(X, post, max_delay=20):
    Xb = readout.add_bias(X); tr = slice(0, TRAIN); te = slice(TRAIN, TRAIN + TEST)
    tot = 0.0
    for d in range(1, max_delay + 1):
        y = tasks.delayed_target(post, d)
        a = np.zeros(len(y), bool); a[tr] = True; a &= ~np.isnan(y)
        b = np.zeros(len(y), bool); b[te] = True; b &= ~np.isnan(y)
        w = readout.train_readout(Xb[a], y[a], ridge=1e-8)
        tot += readout.capacity(y[b], readout.predict(Xb[b], w))
    return tot


def narma_nmse(X, post):
    Xb = readout.add_bias(X); tr = slice(0, TRAIN); te = slice(TRAIN, TRAIN + TEST)
    y = tasks.narma_target(post, order=NARMA_ORDER, input_scale=INPUT_SCALE)
    a = np.zeros(len(y), bool); a[tr] = True; a &= ~np.isnan(y)
    b = np.zeros(len(y), bool); b[te] = True; b &= ~np.isnan(y)
    w = readout.train_readout(Xb[a], y[a], ridge=1e-8)
    return readout.nmse(y[b], readout.predict(Xb[b], w))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--N", type=int, required=True)
    ap.add_argument("--method", required=True)
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--task", choices=["stm", "narma"], default="stm")
    args = ap.parse_args()

    out_path = os.path.join(OUTDIR, f"{args.task}_N{args.N}_{args.method}_s{args.seed}.json")
    if os.path.exists(out_path):
        print(f"skip (exists): {out_path}"); return

    t0 = time.time()
    rng = np.random.default_rng(args.seed)
    J = res.random_couplings(args.N, 1.0, rng)
    s = dsp.jump_strength(dsp.local_loss(args.N, GAMMA))
    obs = readout.pauli_observables(args.N, max_weight=2)
    total = WASH + TRAIN + TEST
    reservoir = make_reservoir(args.method, J, args.N, s, np.random.default_rng(args.seed + 1))
    if args.task == "stm":
        inp = tasks.stm_inputs(total, rng); X = reservoir.run(inp, obs, washout=WASH)
        value = stm_mc(X, inp[WASH:])
    else:
        inp = tasks.narma_inputs(total, rng); X = reservoir.run(inp, obs, washout=WASH)
        value = narma_nmse(X, inp[WASH:])
    json.dump({"N": args.N, "method": args.method, "seed": args.seed, "task": args.task,
               "value": value, "runtime_s": time.time() - t0}, open(out_path, "w"))
    print(f"done {out_path}: {value:.4f} ({time.time()-t0:.0f}s)")


if __name__ == "__main__":
    main()
