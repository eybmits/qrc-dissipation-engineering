"""Generate the parameter list (one line per cluster job) for the scaling study.

Edit NS / METHODS / N_SEEDS / TASKS for the production run, then:
    python gen_params.py > params.txt
and submit submit_scaling.sbatch as a SLURM array of size = number of lines.
"""
import numpy as np

NS = [5, 6, 7, 8]                 # reservoir sizes (N=7,8 need big-memory nodes)
METHODS = ["FN", "CD_paper", "A1_heterogeneous", "B1_dephasing", "B2_thermal",
           "B3_collective", "B4_loss_exchange", "B5_pair"]
N_SEEDS = 100
TASKS = ["stm", "narma"]

seeds = np.random.default_rng(2024).integers(0, 2 ** 31 - 1, N_SEEDS)
for N in NS:
    for m in METHODS:
        for sd in seeds:
            for t in TASKS:
                print(f"{N} {m} {int(sd)} {t}")
