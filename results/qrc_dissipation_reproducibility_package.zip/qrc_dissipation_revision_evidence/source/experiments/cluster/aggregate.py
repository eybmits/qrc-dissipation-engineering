"""Aggregate per-job cluster results into a scaling table (mean ± SE, σ vs CD)."""
import glob
import json
import os
from collections import defaultdict

import numpy as np

OUTDIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)))), "results", "cluster")


def load():
    data = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))  # task->N->method->[values]
    for f in glob.glob(os.path.join(OUTDIR, "*.json")):
        d = json.load(open(f))
        data[d["task"]][d["N"]][d["method"]].append(d["value"])
    return data


def main():
    data = load()
    for task in sorted(data):
        higher = task == "stm"
        print(f"\n=== {task.upper()} ({'MC ↑' if higher else 'NMSE ↓'}) — mean ± SE, σ vs CD_paper ===")
        for N in sorted(data[task]):
            d = data[task][N]
            cd = np.array(d.get("CD_paper", []))
            n_cd = len(cd)
            print(f"\n N={N}  (n={n_cd} seeds)")
            for m in sorted(d):
                a = np.array(d[m])
                if len(a) == 0:
                    continue
                se = a.std(ddof=1) / np.sqrt(len(a)) if len(a) > 1 else float("nan")
                line = f"   {m:18s} {a.mean():8.3f} ± {se:.3f}"
                if m != "CD_paper" and n_cd == len(a) and n_cd > 1:
                    diff = (a - cd) if higher else (cd - a)
                    sig = diff.mean() / (diff.std(ddof=1) / np.sqrt(len(a)) + 1e-12)
                    line += f"   ΔvsCD={diff.mean():+.3f}  {sig:+.1f}σ"
                print(line)


if __name__ == "__main__":
    main()
