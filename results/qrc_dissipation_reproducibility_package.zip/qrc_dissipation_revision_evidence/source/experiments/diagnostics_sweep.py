"""Phase-4 diagnostic sweep: Liouvillian spectral gap and mixing time vs gamma.

These are static (eigenvalue) quantities — no time evolution needed — so the
sweep is cheap.  It connects the dissipation rate to the reservoir's intrinsic
memory timescale (t_mix ~ 1/Delta_L), which underlies the memory/forgetting
trade-off seen in the STM gamma sweep.
"""
from __future__ import annotations

import _paths  # noqa: F401
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from qrc import reservoirs as res
from qrc import diagnostics as diag
from _paths import FIGURES_DIR, RESULTS_DIR
import json
import os


def sweep(n_qubits=5, h=1.0, dt=1.0, gammas=None, n_real=5, seed=7):
    gammas = gammas if gammas is not None else np.geomspace(0.02, 10, 12)
    rng = np.random.default_rng(seed)
    gap = np.zeros((n_real, len(gammas)))
    tmix = np.zeros((n_real, len(gammas)))
    for r in range(n_real):
        J = res.random_couplings(n_qubits, 1.0, rng)
        for gi, g in enumerate(gammas):
            reservoir = res.continuous_dissipation(n_qubits, J, h, g, dt)
            L = reservoir.liouvillian(0.5)
            gap[r, gi] = diag.spectral_gap(L)
            tmix[r, gi] = diag.mixing_time(L)
    return np.asarray(gammas), gap, tmix


def main():
    gammas, gap, tmix = sweep()
    fig, ax = plt.subplots(1, 2, figsize=(10, 4))
    ax[0].errorbar(gammas, gap.mean(0), yerr=gap.std(0), marker="o", capsize=3)
    ax[0].set_xscale("log"); ax[0].set_yscale("log")
    ax[0].set_xlabel(r"$\gamma$"); ax[0].set_ylabel(r"spectral gap $\Delta_L$")
    ax[0].set_title("Liouvillian gap vs dissipation"); ax[0].grid(alpha=0.3)
    ax[1].errorbar(gammas, tmix.mean(0), yerr=tmix.std(0), marker="s",
                   color="C1", capsize=3)
    ax[1].set_xscale("log"); ax[1].set_yscale("log")
    ax[1].set_xlabel(r"$\gamma$"); ax[1].set_ylabel(r"mixing time $t_{mix}\sim1/\Delta_L$")
    ax[1].set_title("Memory timescale vs dissipation"); ax[1].grid(alpha=0.3)
    fig.tight_layout()
    path = os.path.join(FIGURES_DIR, "spectral_gap_vs_gamma.png")
    fig.savefig(path, dpi=130); plt.close(fig)
    np.savez(os.path.join(RESULTS_DIR, "diagnostics_sweep.npz"),
             gammas=gammas, gap=gap, tmix=tmix)
    with open(os.path.join(RESULTS_DIR, "diagnostics_sweep.json"), "w") as f:
        json.dump({"gammas": gammas.tolist(),
                   "gap_mean": gap.mean(0).tolist(),
                   "tmix_mean": tmix.mean(0).tolist()}, f, indent=2)
    print("wrote spectral_gap_vs_gamma.png and diagnostics_sweep.npz")
    for g, gp, tm in zip(gammas, gap.mean(0), tmix.mean(0)):
        print(f"  gamma={g:7.3f}  gap={gp:.4f}  t_mix={tm:.3f}")


if __name__ == "__main__":
    main()
