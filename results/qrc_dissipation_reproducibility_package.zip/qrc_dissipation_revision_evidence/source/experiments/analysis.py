"""Plots, tables and statistical summaries from saved baseline results.

Loads the ``results/<task>.npz`` + ``.json`` pairs written by
``experiments_baseline.py`` and renders figures into ``reports/figures/`` and
markdown tables to stdout / ``reports/tables.md``.
"""
from __future__ import annotations

import _paths  # noqa: F401
import json
import os
from typing import Dict

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from _paths import RESULTS_DIR, FIGURES_DIR, REPORTS_DIR


# --------------------------------------------------------------------------
# loading
# --------------------------------------------------------------------------

def load(name: str) -> dict:
    npz = np.load(f"{RESULTS_DIR}/{name}.npz", allow_pickle=True)
    with open(f"{RESULTS_DIR}/{name}.json") as f:
        meta = json.load(f)
    out = dict(meta)
    dict_keys = meta.get("_dict_keys", {})
    # rebuild dict-of-array entries
    rebuilt: Dict[str, Dict[str, np.ndarray]] = {k: {} for k in dict_keys}
    for key in npz.files:
        if "__" in key:
            base, sub = key.split("__", 1)
            rebuilt.setdefault(base, {})[sub] = npz[key]
        else:
            out[key] = npz[key]
    out.update(rebuilt)
    return out


def _mean_std(arr: np.ndarray):
    return arr.mean(axis=0), arr.std(axis=0)


# --------------------------------------------------------------------------
# plots
# --------------------------------------------------------------------------

def plot_stm(name: str = "stm"):
    r = load(name)
    delays = np.asarray(r["delays"])
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for m in r["models"]:
        mean, std = _mean_std(r["capacity"][m])
        style = dict(marker="o", ms=4)
        if m == "FN":
            style.update(color="k", lw=2.2, zorder=5)
        ax.plot(delays, mean, label=m, **style)
        ax.fill_between(delays, mean - std, mean + std, alpha=0.12)
    ax.set_xlabel(r"delay $\tau$")
    ax.set_ylabel(r"capacity $C(\tau)$")
    ax.set_title("STM: FN vs CD (gamma sweep)")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3)
    _savefig(fig, "stm_capacity.png")

    # total memory capacity bar
    fig, ax = plt.subplots(figsize=(6, 4))
    names, mcs, errs = [], [], []
    for m in r["models"]:
        mc = r["capacity"][m].sum(axis=1)
        names.append(m); mcs.append(mc.mean()); errs.append(mc.std())
    ax.bar(names, mcs, yerr=errs, capsize=4,
           color=["k" if n == "FN" else "C0" for n in names])
    ax.set_ylabel("total memory capacity  $\\sum_\\tau C(\\tau)$")
    ax.set_title("STM total memory capacity")
    plt.xticks(rotation=30, ha="right")
    _savefig(fig, "stm_total_capacity.png")


def plot_stm_optimized(name: str = "confirm_stm"):
    """FN-best vs CD-best STM at each model's own optimal (h, Δt, γ)."""
    with open(f"{RESULTS_DIR}/{name}.json") as f:
        d = json.load(f)
    delays = np.asarray(d["delays"])
    fn = np.asarray(d["cap_fn"]); cd = np.asarray(d["cap_cd"])
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    for arr, lab, col in [(fn, f"FN  (h={d['fn_params'][0]}, Δt={d['fn_params'][1]})", "k"),
                          (cd, f"CD  (h={d['cd_params'][0]}, Δt={d['cd_params'][1]}, γ={d['cd_params'][2]})", "C0")]:
        m, s = arr.mean(0), arr.std(0)
        ax.plot(delays, m, marker="o", ms=4, color=col, lw=2, label=lab)
        ax.fill_between(delays, m - s, m + s, color=col, alpha=0.15)
    ax.set_xlabel(r"delay $\tau$"); ax.set_ylabel(r"capacity $C(\tau)$")
    ax.set_title(f"STM at each model's own optimum  (MC: CD={cd.mean(0).sum():.2f}, "
                 f"FN={fn.mean(0).sum():.2f})")
    ax.legend(fontsize=8); ax.grid(alpha=0.3)
    _savefig(fig, "stm_optimized.png")


def plot_track_a(name: str = "trackA_stm"):
    """Track A: STM capacity per rate profile, with uniform baseline highlighted."""
    r = load(name)
    delays = np.asarray(r["delays"])
    base = "A0_uniform"
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    for m in r["models"]:
        mean, std = _mean_std(r["capacity"][m])
        style = dict(marker="o", ms=3)
        if m == base:
            style.update(color="k", lw=2.4, zorder=5)
        ax.plot(delays, mean, label=m, **style)
    ax.set_xlabel(r"delay $\tau$"); ax.set_ylabel(r"capacity $C(\tau)$")
    ax.set_title(f"Track A — rate profiles on STM (γ̄={np.asarray(r['mean_gamma']):g}, matched)")
    ax.legend(fontsize=8); ax.grid(alpha=0.3)
    _savefig(fig, "track_a_stm_capacity.png")

    # paired MC difference vs uniform (same J/inputs per realization)
    base_mc = r["capacity"][base].sum(axis=1)
    fig, ax = plt.subplots(figsize=(6.5, 4))
    names, dmean, dstd = [], [], []
    for m in r["models"]:
        if m == base:
            continue
        d = r["capacity"][m].sum(axis=1) - base_mc   # paired difference
        names.append(m); dmean.append(d.mean()); dstd.append(d.std())
    colors = ["C2" if v > 0 else "C3" for v in dmean]
    ax.bar(names, dmean, yerr=dstd, capsize=4, color=colors)
    ax.axhline(0, color="k", lw=1)
    ax.set_ylabel("ΔMC vs uniform (paired)")
    ax.set_title("Track A — does heterogeneity beat uniform at matched γ̄?")
    plt.xticks(rotation=30, ha="right")
    _savefig(fig, "track_a_stm_deltaMC.png")


def table_track_a(name: str = "trackA_stm") -> str:
    r = load(name)
    base = "A0_uniform"
    base_mc = r["capacity"][base].sum(axis=1)
    lines = [f"### Track A — STM total memory capacity (γ̄={np.asarray(r['mean_gamma']):g}, matched)",
             "", "| profile | MC (mean ± std) | ΔMC vs uniform (paired) |", "|---|---|---|"]
    for m in r["models"]:
        mc = r["capacity"][m].sum(axis=1)
        if m == base:
            lines.append(f"| **{m}** | {mc.mean():.2f} ± {mc.std():.2f} | — (baseline) |")
        else:
            d = mc - base_mc
            sig = "**" if abs(d.mean()) > 2 * (d.std() / np.sqrt(len(d)) + 1e-9) else ""
            lines.append(f"| {m} | {mc.mean():.2f} ± {mc.std():.2f} | "
                         f"{sig}{d.mean():+.2f} ± {d.std():.2f}{sig} |")
    return "\n".join(lines)


def plot_track_b_regimes(name: str = "trackB_regimes"):
    """Track B: per-delay capacity (at γ=0.3) and paired ΔMC vs local loss across
    the strength-budget sweep."""
    with open(f"{RESULTS_DIR}/{name}.json") as f:
        d = json.load(f)
    gammas = d["gammas"]; fams = d["families"]; delays = np.asarray(d["delays"])
    cap = {g: {m: np.asarray(d["cap"][str(g)][m]) for m in fams} for g in gammas}

    # per-delay at the lowest budget (the validated-optimum strength)
    g0 = gammas[0]
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    for m in fams:
        mean = cap[g0][m].mean(0)
        style = dict(marker="o", ms=3)
        if m == "B0_local":
            style.update(color="k", lw=2.4, zorder=5)
        ax.plot(delays, mean, label=m, **style)
    ax.set_xlabel(r"delay $\tau$"); ax.set_ylabel(r"capacity $C(\tau)$")
    ax.set_title(f"Track B — jump families on STM (matched strength, γ={g0})")
    ax.legend(fontsize=8); ax.grid(alpha=0.3)
    _savefig(fig, "track_b_stm_capacity.png")

    # paired ΔMC vs B0 across budgets
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    for m in fams:
        if m == "B0_local":
            continue
        dmean, dstd = [], []
        for g in gammas:
            diff = cap[g][m].sum(1) - cap[g]["B0_local"].sum(1)
            dmean.append(diff.mean()); dstd.append(diff.std())
        ax.errorbar(gammas, dmean, yerr=dstd, marker="o", capsize=3, label=m)
    ax.axhline(0, color="k", lw=1); ax.set_xscale("log")
    ax.set_xlabel(r"strength budget $\gamma$"); ax.set_ylabel(r"paired $\Delta$MC vs local loss")
    ax.set_title("Track B — which dissipator beats local loss, and when?")
    ax.legend(fontsize=8); ax.grid(alpha=0.3)
    _savefig(fig, "track_b_regimes.png")


def table_track_b(name: str = "trackB_regimes") -> str:
    with open(f"{RESULTS_DIR}/{name}.json") as f:
        d = json.load(f)
    gammas = d["gammas"]; fams = d["families"]
    cap = {g: {m: np.asarray(d["cap"][str(g)][m]) for m in fams} for g in gammas}
    lines = ["### Track B — STM total memory capacity, paired ΔMC vs local loss",
             "", "| family | " + " | ".join(f"γ={g} (ΔMC)" for g in gammas) + " |",
             "|" + "---|" * (len(gammas) + 1)]
    for m in fams:
        cells = []
        for g in gammas:
            if m == "B0_local":
                cells.append(f"MC={cap[g][m].sum(1).mean():.2f}")
            else:
                diff = cap[g][m].sum(1) - cap[g]["B0_local"].sum(1)
                se = diff.std() / np.sqrt(len(diff)) + 1e-9
                sig = "**" if abs(diff.mean()) > 2 * se else ""
                cells.append(f"{sig}{diff.mean():+.2f}{sig}")
        lines.append(f"| {m} | " + " | ".join(cells) + " |")
    return "\n".join(lines)


def plot_narma(name: str = "narma"):
    r = load(name)
    orders = np.asarray(r["orders"])
    fig, ax = plt.subplots(figsize=(6.5, 4))
    width = 0.8 / len(r["models"])
    x = np.arange(len(orders))
    for i, m in enumerate(r["models"]):
        mean, std = _mean_std(r["nmse"][m])
        ax.bar(x + i * width, mean, width, yerr=std, capsize=3, label=m)
    ax.set_xticks(x + 0.4 - width / 2)
    ax.set_xticklabels([f"NARMA-{o}" for o in orders])
    ax.set_ylabel("test NMSE (lower = better)")
    ax.set_title("NARMA: FN vs CD")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3, axis="y")
    _savefig(fig, "narma_nmse.png")


def plot_parity(name: str = "parity"):
    r = load(name)
    delays = np.asarray(r["delays"])
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for m in r["models"]:
        mean, std = _mean_std(r["capacity"][m])
        style = dict(marker="s", ms=4)
        if m == "FN":
            style.update(color="k", lw=2.2)
        ax.plot(delays, mean, label=m, **style)
        ax.fill_between(delays, mean - std, mean + std, alpha=0.12)
    ax.set_xlabel(r"parity order $\tau$")
    ax.set_ylabel("capacity")
    ax.set_title(f"Parity (V={int(np.asarray(r['n_virtual']))} virtual nodes)")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3)
    _savefig(fig, "parity_capacity.png")


def plot_mackey_glass(name: str = "mackey_glass"):
    r = load(name)
    fig, ax = plt.subplots(figsize=(7.5, 4))
    truth = np.asarray(r["example_truth"])
    ax.plot(truth, "k-", lw=2, label="truth")
    for m in r["models"]:
        pred = np.asarray(r["example_pred"][m])
        ax.plot(pred, "--", label=f"{m}")
    ax.set_xlabel("autonomous step")
    ax.set_ylabel("Mackey-Glass (rescaled)")
    ax.set_title("Mackey-Glass autonomous forecast (realization 0)")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3)
    _savefig(fig, "mackey_glass_forecast.png")

    fig, ax = plt.subplots(figsize=(5.5, 4))
    names, mses, errs = [], [], []
    for m in r["models"]:
        v = np.asarray(r["mse"][m])
        names.append(m); mses.append(v.mean()); errs.append(v.std())
    ax.bar(names, mses, yerr=errs, capsize=4,
           color=["k" if n == "FN" else "C1" for n in names])
    ax.set_ylabel(f"MSE over first {int(np.asarray(r['horizon']))} steps")
    ax.set_title("Mackey-Glass autonomous MSE")
    plt.xticks(rotation=30, ha="right")
    _savefig(fig, "mackey_glass_mse.png")


# --------------------------------------------------------------------------
# tables
# --------------------------------------------------------------------------

def table_stm(name: str = "stm") -> str:
    r = load(name)
    delays = np.asarray(r["delays"])
    lines = ["### STM: capacity C(tau) (mean over realizations)", ""]
    header = "| model | " + " | ".join(f"τ={d}" for d in delays) + " | **MC** |"
    lines += [header, "|" + "---|" * (len(delays) + 2)]
    for m in r["models"]:
        mean = r["capacity"][m].mean(axis=0)
        mc = mean.sum()
        row = f"| {m} | " + " | ".join(f"{v:.3f}" for v in mean) + f" | **{mc:.2f}** |"
        lines.append(row)
    return "\n".join(lines)


def table_narma(name: str = "narma") -> str:
    r = load(name)
    orders = np.asarray(r["orders"])
    lines = ["### NARMA: test NMSE (mean +/- std)", ""]
    lines += ["| model | " + " | ".join(f"NARMA-{o}" for o in orders) + " |",
              "|" + "---|" * (len(orders) + 1)]
    for m in r["models"]:
        mean, std = _mean_std(r["nmse"][m])
        row = f"| {m} | " + " | ".join(f"{mu:.3f}±{sd:.3f}"
                                       for mu, sd in zip(mean, std)) + " |"
        lines.append(row)
    return "\n".join(lines)


def table_parity(name: str = "parity") -> str:
    r = load(name)
    delays = np.asarray(r["delays"])
    lines = ["### Parity: capacity (mean)", ""]
    lines += ["| model | " + " | ".join(f"τ={d}" for d in delays) + " |",
              "|" + "---|" * (len(delays) + 1)]
    for m in r["models"]:
        mean = r["capacity"][m].mean(axis=0)
        lines.append(f"| {m} | " + " | ".join(f"{v:.3f}" for v in mean) + " |")
    return "\n".join(lines)


def table_mackey_glass(name: str = "mackey_glass") -> str:
    r = load(name)
    lines = [f"### Mackey-Glass: autonomous MSE over {int(np.asarray(r['horizon']))} steps",
             "", "| model | MSE (mean ± std) |", "|---|---|"]
    for m in r["models"]:
        v = np.asarray(r["mse"][m])
        lines.append(f"| {m} | {v.mean():.4e} ± {v.std():.1e} |")
    return "\n".join(lines)


# --------------------------------------------------------------------------

def _savefig(fig, fname: str):
    path = os.path.join(FIGURES_DIR, fname)
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)
    print(f"  wrote {os.path.relpath(path, os.path.dirname(FIGURES_DIR))}")


def build_all():
    available = {n: os.path.exists(f"{RESULTS_DIR}/{n}.npz")
                 for n in ["stm", "narma", "parity", "mackey_glass"]}
    tables = []
    if available["stm"]:
        plot_stm(); tables.append(table_stm())
    if os.path.exists(f"{RESULTS_DIR}/confirm_stm.json"):
        plot_stm_optimized()
    if available["narma"]:
        plot_narma(); tables.append(table_narma())
    if available["parity"]:
        plot_parity(); tables.append(table_parity())
    if available["mackey_glass"]:
        plot_mackey_glass(); tables.append(table_mackey_glass())
    tbl = "\n\n".join(tables)
    with open(os.path.join(REPORTS_DIR, "tables.md"), "w") as f:
        f.write("# Baseline result tables\n\n" + tbl + "\n")
    print("\n" + tbl)
    return tbl


if __name__ == "__main__":
    build_all()
