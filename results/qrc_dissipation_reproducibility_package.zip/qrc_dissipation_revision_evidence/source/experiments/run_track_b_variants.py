"""Track B gaps: B3 collective with non-uniform c_i, and B5 pair loss (STM).

Families (all matched to B0 local-loss total strength Σ rate·Tr(L†L)):
  B0_local            σ^-_i
  B3_coll_uniform     L = Σ_i σ^-_i              (c_i = 1)
  B3_coll_random      L = Σ_i c_i σ^-_i          (c_i ~ |N(0,1)|, normalised)
  B3_coll_graph       L = Σ_i c_i σ^-_i          (c_i ∝ Σ_j|J_ij|, graph-informed)
  B5_pair             L_ij = σ^-_i σ^-_j         (on coupling edges, i<j)

Swept over strength budget γ ∈ {0.3, 1, 3}, paired per realization, at the
validated CD optimum (h=0.5, Δt=0.5).  Tests whether the collective coefficient
profile matters and whether pair loss is a viable (non-unital) dissipator.
"""
import _paths  # noqa: F401
import json
import time
import numpy as np

from qrc import reservoirs as res, readout, tasks
from qrc import dissipators as dsp
from experiments_baseline import make_config, evaluate_delays
from experiments_track_b import make_reservoir_with_jumps


def undirected_edges(J, eps=1e-9):
    n = J.shape[0]
    return [(i, j) for i in range(n) for j in range(i + 1, n) if abs(J[i, j]) > eps]


def build(J, n, gamma):
    target = dsp.jump_strength(dsp.local_loss(n, gamma))
    rng = np.random.default_rng(int(abs(J).sum() * 1e6) % (2**31))  # deterministic per J
    c_rand = np.abs(rng.standard_normal(n)) + 0.1
    c_graph = np.sum(np.abs(J), axis=1) + 1e-3
    fams = {
        "B0_local": dsp.local_loss(n, gamma),
        "B3_coll_uniform": dsp.collective_loss(n, gamma),
        "B3_coll_random": dsp.collective_loss(n, gamma, c=c_rand),
        "B3_coll_graph": dsp.collective_loss(n, gamma, c=c_graph),
        "B5_pair": dsp.pair_loss(n, gamma, undirected_edges(J)),
    }
    return {k: dsp.normalize_jump_strength(v, target) for k, v in fams.items()}


cfg = make_config("validation", h=0.5, dt=0.5, quantize=48,
                  n_realizations=4, washout=150, train_len=450, test_len=300)
gammas = [0.3, 1.0, 3.0]
delays = list(range(1, 16))
fam_names = ["B0_local", "B3_coll_uniform", "B3_coll_random", "B3_coll_graph", "B5_pair"]
obs = readout.pauli_observables(cfg.n_qubits, max_weight=cfg.max_weight)
rng_master = np.random.default_rng(cfg.seed + 600)
seeds = rng_master.integers(0, 2 ** 31 - 1, size=cfg.n_realizations)

cap = {g: {m: np.zeros((cfg.n_realizations, len(delays))) for m in fam_names}
       for g in gammas}
t0 = time.time()
for r_i, sd in enumerate(seeds):
    rng = np.random.default_rng(int(sd))
    J = res.random_couplings(cfg.n_qubits, cfg.J_s, rng)
    inputs = tasks.stm_inputs(cfg.total_len, rng)
    post = inputs[cfg.washout:]
    for g in gammas:
        fams = build(J, cfg.n_qubits, g)
        for m in fam_names:
            reservoir = make_reservoir_with_jumps(J, cfg, fams[m])
            X = reservoir.run(inputs, obs, washout=cfg.washout, n_virtual=1)
            caps = evaluate_delays(X, post, tasks.delayed_target, delays, cfg, "capacity")
            cap[g][m][r_i] = [caps[d] for d in delays]
    print(f"  realization {r_i+1}/{cfg.n_realizations} ({time.time()-t0:.0f}s)")

out = {"gammas": gammas, "families": fam_names, "delays": delays,
       "cap": {str(g): {m: cap[g][m].tolist() for m in fam_names} for g in gammas},
       "seeds": seeds.tolist(), "config": cfg.__dict__, "runtime_s": time.time() - t0}
json.dump(out, open("../results/trackB_variants.json", "w"), indent=2)

print("\n=== Track B variants: STM MC, paired ΔMC vs B0 local ===")
for g in gammas:
    base = cap[g]["B0_local"].sum(1)
    print(f"\nγ={g}: B0 MC={base.mean():.2f}")
    for m in fam_names:
        if m == "B0_local":
            continue
        d = cap[g][m].sum(1) - base
        se = d.std() / np.sqrt(len(d))
        sig = "  <-- signif" if abs(d.mean()) > 2 * se else ""
        print(f"  {m:16s} ΔMC={d.mean():+.2f} ± {d.std():.2f}{sig}")
