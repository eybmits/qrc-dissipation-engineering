"""Track A gaps: A3 learned static rates and A4 input-adaptive rates.

A3:  γ_i = softplus(θ_i), then renormalised to mean γ̄  (only the SHAPE is learned;
     matched mean dissipation is enforced).  θ optimised (Nelder-Mead) on a held-out
     VALIDATION split, scored on TEST.  Compared to uniform and random (A1) at the
     same γ̄, on the same reservoir (transductive: fixed J, different input splits).

A4:  γ_i(s) = softplus(a_i s + b_i), rates globally rescaled so the time/qubit mean
     equals γ̄.  Tests whether the input should also control the memory timescale.
     Controls: vs A3 (static learned, fewer params) and vs uniform.

Operating point h=0.5, Δt=0.5, lossy regime γ̄=1.5 (where rate shaping matters).
This is reduced-scale and the optimiser budget is modest — results are indicative.
"""
import _paths  # noqa: F401
import json
import time
import numpy as np
from scipy.optimize import minimize

from qrc import reservoirs as res, readout, tasks
from qrc import dissipators as dsp
from experiments_baseline import make_config

cfg = make_config("validation", h=0.5, dt=0.5, quantize=32,
                  n_realizations=3, washout=100, train_len=250, test_len=200)
VAL = 150                          # validation block carved from the tail of train
GBAR = 1.5
delays = list(range(1, 13))
obs = readout.pauli_observables(cfg.n_qubits, max_weight=cfg.max_weight)
N = cfg.n_qubits


def mc_on(X, post, sl):
    Xb = readout.add_bias(X)
    tr = slice(0, cfg.train_len - VAL)
    blocks = {"val": slice(cfg.train_len - VAL, cfg.train_len),
              "test": slice(cfg.train_len, cfg.train_len + cfg.test_len)}[sl]
    mc = 0.0
    for d in delays:
        y = tasks.delayed_target(post, d)
        a = np.zeros(len(y), bool); a[tr] = True; a &= ~np.isnan(y)
        b = np.zeros(len(y), bool); b[blocks] = True; b &= ~np.isnan(y)
        w = readout.train_readout(Xb[a], y[a], ridge=cfg.ridge)
        mc += readout.capacity(y[b], readout.predict(Xb[b], w))
    return mc


def static_mc(gammas, J, inputs, post, which):
    r = res.continuous_dissipation(N, J, cfg.h, gammas, cfg.dt, quantize=cfg.quantize)
    X = r.run(inputs, obs, washout=cfg.washout, n_virtual=1)
    return mc_on(X, post, which)


def adaptive_mc(a, b, J, inputs, post, which):
    from qrc.reservoirs import ising_xx_hamiltonian, transverse_drive, GeneralLindbladReservoir
    H0 = ising_xx_hamiltonian(J, cfg.h, N); Hx = transverse_drive(N)
    sgrid = np.linspace(0, 1, 11)
    mbar = np.mean([dsp.adaptive_rates(s, a, b).mean() for s in sgrid])
    k = GBAR / max(mbar, 1e-6)
    r = GeneralLindbladReservoir(N,
        lambda s: H0 + cfg.h * (s + 1) * Hx,
        lambda s: [(res.sminus(i, N), float(k * dsp.adaptive_rates(s, a, b)[i]))
                   for i in range(N)],
        cfg.dt, quantize=cfg.quantize)
    X = r.run(inputs, obs, washout=cfg.washout, n_virtual=1)
    return mc_on(X, post, which)


def main():
    rng_master = np.random.default_rng(cfg.seed + 800)
    seeds = rng_master.integers(0, 2 ** 31 - 1, size=cfg.n_realizations)
    res_out = {k: np.zeros(cfg.n_realizations) for k in
               ["uniform", "random", "A3_learned", "A4_adaptive"]}
    t0 = time.time()
    for r_i, sd in enumerate(seeds):
        rng = np.random.default_rng(int(sd))
        J = res.random_couplings(N, cfg.J_s, rng)
        inputs = tasks.stm_inputs(cfg.total_len, rng)
        post = inputs[cfg.washout:]

        # baselines (test MC)
        g_unif = dsp.uniform_rates(N, GBAR)
        g_rand = dsp.loguniform_rates(N, GBAR / 10, GBAR * 10, rng, mean=GBAR)
        res_out["uniform"][r_i] = static_mc(g_unif, J, inputs, post, "test")
        res_out["random"][r_i] = static_mc(g_rand, J, inputs, post, "test")

        # A3: optimise theta on validation, from BOTH uniform and random starts
        def negval_A3(theta):
            g = dsp.normalize_rates(dsp.rates_from_theta(theta), GBAR)
            return -static_mc(g, J, inputs, post, "val")
        starts = [np.zeros(N), np.log(np.expm1(np.clip(g_rand, 1e-3, None)))]  # softplus^-1
        best = None
        for th0 in starts:
            sol = minimize(negval_A3, th0, method="Nelder-Mead",
                           options=dict(maxfev=35, xatol=1e-2, fatol=1e-3))
            if best is None or sol.fun < best.fun:
                best = sol
        g_learned = dsp.normalize_rates(dsp.rates_from_theta(best.x), GBAR)
        res_out["A3_learned"][r_i] = static_mc(g_learned, J, inputs, post, "test")

        # A4: optimise (a,b) on validation, from a spread init
        def negval_A4(ab):
            return -adaptive_mc(ab[:N], ab[N:], J, inputs, post, "val")
        ab0 = np.concatenate([rng.standard_normal(N) * 0.5, np.full(N, 0.5)])
        sol2 = minimize(negval_A4, ab0, method="Nelder-Mead",
                        options=dict(maxfev=50, xatol=1e-2, fatol=1e-3))
        res_out["A4_adaptive"][r_i] = adaptive_mc(sol2.x[:N], sol2.x[N:], J, inputs, post, "test")
        print(f"  realization {r_i+1}/{cfg.n_realizations} done ({time.time()-t0:.0f}s) "
              f"unif={res_out['uniform'][r_i]:.2f} rand={res_out['random'][r_i]:.2f} "
              f"A3={res_out['A3_learned'][r_i]:.2f} A4={res_out['A4_adaptive'][r_i]:.2f}")

    result = {"gbar": GBAR, "delays": delays, "n_params": {"uniform": 1, "random": N,
              "A3_learned": N, "A4_adaptive": 2 * N},
              "test_mc": {k: res_out[k].tolist() for k in res_out},
              "seeds": seeds.tolist(), "config": cfg.__dict__, "runtime_s": time.time() - t0}
    json.dump(result, open("../results/trackA_learned.json", "w"), indent=2)

    print("\n=== Track A learned/adaptive: STM test MC (γ̄=1.5, matched mean) ===")
    base = res_out["uniform"].mean()
    for k in ["uniform", "random", "A3_learned", "A4_adaptive"]:
        v = res_out[k]
        print(f"  {k:12s} (params={result['n_params'][k]:2d})  MC={v.mean():.2f} ± {v.std():.2f}  "
              f"ΔvsUniform={v.mean()-base:+.2f}")


if __name__ == "__main__":
    main()
