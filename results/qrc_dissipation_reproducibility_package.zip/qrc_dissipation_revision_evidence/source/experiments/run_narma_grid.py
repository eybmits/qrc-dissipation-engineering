"""Grid-search NARMA for FN and CD, select per-model by validation NMSE."""
import _paths  # noqa: F401
import json
import sys
import numpy as np
import experiments_grid as G

order = int(sys.argv[1]) if len(sys.argv) > 1 else 10
g = G.GridConfig(n_realizations=3, quantize=24)
h_list = [0.5, 1.0, 2.0]
dt_list = [0.1, 0.25, 0.5, 1.0]
gamma_list = [0.3, 1.0, 3.0]

print(f"=== NARMA-{order} grid search | {g} ===")
print("--- FN ---")
fn = G.grid_search_narma(g, "FN", h_list, dt_list, [None], order=order)
print(f"  FN best (h,dt): {fn['best_params']}  val NMSE={fn['best_val']:.3f}  "
      f"test NMSE={fn['best_test']:.3f}")
print("--- CD ---")
cd = G.grid_search_narma(g, "CD", h_list, dt_list, gamma_list, order=order)
print(f"  CD best (h,dt,γ): {cd['best_params']}  val NMSE={cd['best_val']:.3f}  "
      f"test NMSE={cd['best_test']:.3f}")

json.dump({"FN": fn, "CD": cd}, open(f"../results/grid_narma{order}.json", "w"), indent=2)
better = "CD < FN ✓" if cd["best_test"] <= fn["best_test"] else "FN < CD"
print(f"\n>>> NARMA-{order} VERDICT: CD test NMSE {cd['best_test']:.3f} vs "
      f"FN {fn['best_test']:.3f} -> {better}")
