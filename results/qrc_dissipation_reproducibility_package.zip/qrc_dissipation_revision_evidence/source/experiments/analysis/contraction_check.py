"""Numerically verify the uniform-contraction hypothesis of the unitality
proposition. Phi_s = expm(L_s dt) preserves trace, so it maps the traceless
subspace to itself; sup_s of its largest singular value there is the joint
contraction factor. <1 => switched products converge to rho_star (capacity 0).
Expected: <1 for generic ensembles (dephasing dead), ~1 for the ZZ exception."""
import numpy as np, sys
sys.path.insert(0,'../../src')
sys.path.insert(0,'..')
from qrc import reservoirs as res, dissipators as dsp
from qrc.liouvillian import lindbladian
from scipy.linalg import expm, null_space
from run_review_experiments import build_hamiltonian, build_jumps, H as HFIELD, DT, GAMMA

N=5; d=2**N
u=np.eye(d).reshape(-1)/np.sqrt(d)           # vec(I)/||vec(I)||
V=null_space(u.conj()[None,:])               # (d^2, d^2-1) orthonormal traceless basis
SVALS=[0.0,0.25,0.5,0.75,1.0]
ENS=["xx_z_x","zz_x_z","xy_z_x","xx_ring"]
SEEDS=[int(s) for s in np.random.SeedSequence(7).generate_state(5)]

def contraction(ens, method, seed):
    rng=np.random.default_rng(seed)
    J=(res.ring_couplings(N,1.0,rng) if ens=="xx_ring" else res.random_couplings(N,1.0,rng)) \
        if hasattr(res,'ring_couplings') else res.random_couplings(N,1.0,rng)
    H0,Hdir=build_hamiltonian(ens,J,N)
    target=dsp.jump_strength(dsp.local_loss(N,GAMMA))
    jumps=build_jumps(method,J,N,target,np.random.default_rng(seed+1))
    worst=0.0
    for s in SVALS:
        Hs=H0+ (1.0+s)*HFIELD*Hdir
        Phi=expm(lindbladian(Hs,jumps)*DT)
        M=V.conj().T@Phi@V                    # restriction to traceless subspace
        sv=np.linalg.svd(M,compute_uv=False)[0]
        worst=max(worst,sv)
    return worst

print("Uniform HS-contraction factor sup_s sigma_max(Phi_s | traceless), dephasing (unital):")
print(f"{'ensemble':10} {'mean lambda':>12} {'max lambda':>11}  contractive?")
for ens in ENS:
    vals=[contraction(ens,"B1_dephasing",sd) for sd in SEEDS]
    tag="YES (<1: dead)" if max(vals)<1-1e-9 else "NO (>=1: computes)"
    print(f"{ens:10} {np.mean(vals):12.5f} {np.max(vals):11.5f}  {tag}")
print()
print("Contrast: a NON-unital channel (local loss) on xx_z_x (should also be <1 but has non-mixed fixed point):")
vals=[contraction("xx_z_x","CD_paper",sd) for sd in SEEDS]
print(f"  local loss: mean {np.mean(vals):.5f} max {np.max(vals):.5f}")
print("DONE")
