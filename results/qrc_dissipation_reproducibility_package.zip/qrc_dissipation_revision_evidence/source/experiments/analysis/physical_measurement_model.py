"""Physical total-shot measurement model: 3 commuting settings (X/Y/Z bases),
joint multinomial sampling per setting with correct covariances, total budget
shared across same-axis observables. Validates vs exact, then maps channels."""
import numpy as np, sys, itertools
sys.path.insert(0,'../../src')
sys.path.insert(0,'..')
from qrc import readout, tasks, reservoirs as res
from run_review_experiments import make_reservoir, WASH, TRAIN, TEST
from qrc.readout import add_bias, train_readout, predict, capacity

N=5; d=2**N
H1=np.array([[1,1],[1,-1]],complex)/np.sqrt(2)
Sd=np.array([[1,0],[0,-1j]],complex)
Rx=H1; Ry=H1@Sd; Rz=np.eye(2,dtype=complex)
def kron_n(M): 
    out=np.array([[1]],complex)
    for _ in range(N): out=np.kron(out,M)
    return out
ROT={'x':kron_n(Rx),'y':kron_n(Ry),'z':kron_n(Rz)}
# eigenvalue table E[b,i] = +1 if bit i of b is 0 else -1  (qubit 0 = most significant, matching pauli_op)
bits=np.array([[ (b>>(N-1-i))&1 for i in range(N)] for b in range(d)])
E=1-2*bits  # (d,N)
# feature order must match pauli_observables(N): axis-major weight1 then weight2, axes x,y,z
PAIRS=[(i,j) for i in range(N) for j in range(i+1,N)]
def phys_features(rho, shots_per_setting, rng):
    """Return 45-vector [x_i(5) y_i(5) z_i(5) x_ij(10) y_ij(10) z_ij(10)]."""
    w1={}; w2={}
    for a in ('x','y','z'):
        U=ROT[a]; p=np.real(np.diag(U@rho@U.conj().T)); p=np.clip(p,0,None); p/=p.sum()
        counts=rng.multinomial(shots_per_setting,p)
        f=counts/shots_per_setting
        s1=f@E                       # (N,) estimated <sigma^a_i>
        w1[a]=s1
        s2=np.array([f@(E[:,i]*E[:,j]) for (i,j) in PAIRS])
        w2[a]=s2
    feat=np.concatenate([w1['x'],w1['y'],w1['z'],w2['x'],w2['y'],w2['z']])
    return feat

def stm_from_feats(F, post, ridge=1e-8):
    Xb=add_bias(F); tot=0.0
    for delay in range(1,21):
        y=tasks.delayed_target(post,delay)
        a=np.zeros(len(y),bool);a[:600]=True;a&=~np.isnan(y)
        b=np.zeros(len(y),bool);b[600:1000]=True;b&=~np.isnan(y)
        w=train_readout(Xb[a],y[a],ridge=ridge)
        c=capacity(y[b],predict(Xb[b],w)); tot+= 0.0 if not np.isfinite(c) else c
    return tot

CHAN=["CD_paper","B3_collective","A1_heterogeneous","B2_thermal","B4_loss_exchange","B5_pair"]
SH={"CD_paper":"dial","B3_collective":"collective","A1_heterogeneous":"unequal","B2_thermal":"thermal","B4_loss_exchange":"exchange","B5_pair":"pair"}
PERSET=[64,256,1024,4096,16384,0]  # per-setting shots; 0=exact; total reps = 3x
SEEDS=[1208965604, 2975921940, 2862987534, 439371303, 92685261, 593718407, 1065668271, 2353411057, 3664265923, 3164297935, 2199701815, 3764799217, 355367973, 117369658, 910206443, 4290912757, 2282003311, 3578615673, 381243794, 1141676059]
obs=readout.pauli_observables(N,max_weight=2)
res_cap={S:{m:{} for m in CHAN} for S in PERSET}  # S->m->{seed:cap}
for seed in SEEDS:
    rng=np.random.default_rng(seed); J=res.random_couplings(N,1.0,rng)
    inp=tasks.stm_inputs(WASH+TRAIN+TEST,rng); post=inp[WASH:]
    for m in CHAN:
        r=make_reservoir("xx_z_x",m,J,N,np.random.default_rng(seed+1))
        rho=r.initial_state(); rhos=[]
        for k,s in enumerate(inp):
            rho=r.step(rho,float(s))
            if k>=WASH: rhos.append(rho)
        # exact features via observables (sanity)
        Xexact=r.run(inp,obs,washout=WASH)
        for S in PERSET:
            if S==0:
                F=Xexact
            else:
                nrng=np.random.default_rng(seed+999+S)
                F=np.array([phys_features(rhos[t],S,nrng) for t in range(len(rhos))])
            res_cap[S][m][seed]=stm_from_feats(F,post)
def paired(a,b):
    ks=sorted(set(a)&set(b)); dd=np.array([a[k]-b[k] for k in ks]); n=len(dd)
    m=dd.mean(); se=dd.std(ddof=1)/np.sqrt(n); import scipy.stats as st
    return m, m-1.96*se, m+1.96*se, int((dd>0).sum()), n
print("PHYSICAL total-shot model (3 settings; per-setting shots; total reps=3x); 20 seeds:")
print(f"{'perSet':>7} {'totReps':>8} "+" ".join(f"{SH[m]:>9}" for m in CHAN)+"   winner  win-vs-dial  coll-vs-dial")
for S in PERSET:
    lab='exact' if S==0 else str(S); tot='exact' if S==0 else str(3*S)
    means={m:np.mean(list(res_cap[S][m].values())) for m in CHAN}
    win=max(CHAN,key=lambda m:means[m])
    dmw=paired(res_cap[S][win],res_cap[S]['CD_paper'])
    dcw=paired(res_cap[S]['B3_collective'],res_cap[S]['CD_paper'])
    print(f"{lab:>7} {tot:>8} "+" ".join(f"{means[m]:9.2f}" for m in CHAN)+
          f"   {SH[win]:10} d={dmw[0]:+.2f}[{dmw[1]:+.2f},{dmw[2]:+.2f}] {dmw[3]}/{dmw[4]}  coll d={dcw[0]:+.2f} {dcw[3]}/{dcw[4]}")
import json
json.dump({str(S):{m:res_cap[S][m] for m in CHAN} for S in PERSET},
          open("phys_shots.json","w"))
print("DONE")
