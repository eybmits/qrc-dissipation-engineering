import numpy as np, sys
sys.path.insert(0,'../../src')
sys.path.insert(0,'..')
from qrc import readout, tasks, reservoirs as res
from run_review_experiments import make_reservoir, WASH, TRAIN, TEST
from qrc.readout import add_bias, train_readout, predict, capacity
DELAYS=range(1,21); LAMS=[1e-8,1e-5,1e-3,1e-2,1e-1,1.0,10.0]
CHAN=["CD_paper","B3_collective","A1_heterogeneous","B2_thermal","B4_loss_exchange","B5_pair"]
SH={"CD_paper":"dial","B3_collective":"collective","A1_heterogeneous":"unequal","B2_thermal":"thermal","B4_loss_exchange":"exchange","B5_pair":"pair"}
BUD=[256,4096,65536,0]; SEEDS=[198305900,518677875,1451336746,1716840368,1951374833,1965675192]
def cs(y,yh):
    c=capacity(y,yh); return 0.0 if not np.isfinite(c) else c
def mask(y, lo, hi):
    m=np.zeros(len(y),bool); m[lo:hi]=True; m &= ~np.isnan(y); return m
def stm(Xb, ys, tr_lo,tr_hi, te_lo,te_hi, lam):
    tot=0.0
    for y in ys:
        a=mask(y,tr_lo,tr_hi); b=mask(y,te_lo,te_hi)
        w=train_readout(Xb[a], y[a], ridge=lam)
        tot+=cs(y[b], predict(Xb[b], w))
    return tot
def cv(Xb, ys):
    best,bl=-1.0,LAMS[0]
    for lam in LAMS:
        v=stm(Xb,ys,0,480,480,600,lam)
        if v>best: best,bl=v,lam
    return stm(Xb,ys,0,600,600,1000,bl), bl
rf={b:{m:[] for m in CHAN} for b in BUD}; rc={b:{m:[] for m in CHAN} for b in BUD}; lp={b:[] for b in BUD}
fv={m:[] for m in CHAN}
for seed in SEEDS:
    rng=np.random.default_rng(seed); J=res.random_couplings(5,1.0,rng)
    inp=tasks.stm_inputs(WASH+TRAIN+TEST,rng); post=inp[WASH:]
    obs=readout.pauli_observables(5,max_weight=2); ys=[tasks.delayed_target(post,d) for d in DELAYS]
    for m in CHAN:
        r=make_reservoir("xx_z_x",m,J,5,np.random.default_rng(seed+1)); X=r.run(inp,obs,washout=WASH)
        fv[m].append(float(np.sum(np.var(X,axis=0))))
        for S in BUD:
            Xn=X if S==0 else X+np.random.default_rng(seed+777+S).standard_normal(X.shape)*np.sqrt(np.clip(1-X**2,0,None)/S)
            Xb=add_bias(Xn)
            rf[S][m].append(stm(Xb,ys,0,600,600,1000,1e-8))
            c,lam=cv(Xb,ys); rc[S][m].append(c); lp[S].append(lam)
from scipy.stats import spearmanr
print(f"{'budget':>7} {'channel':10} {'fixed1e-8':>9} {'CVridge':>8}")
for S in BUD:
    lab='exact' if S==0 else str(S)
    for m in CHAN: print(f"{lab:>7} {SH[m]:10} {np.mean(rf[S][m]):9.2f} {np.mean(rc[S][m]):8.2f}")
    wf=SH[max(CHAN,key=lambda m:np.mean(rf[S][m]))]; wc=SH[max(CHAN,key=lambda m:np.mean(rc[S][m]))]
    fvv=[np.mean(fv[m]) for m in CHAN]
    rho_f=spearmanr(fvv,[np.mean(rf[S][m]) for m in CHAN])[0]
    rho_c=spearmanr(fvv,[np.mean(rc[S][m]) for m in CHAN])[0]
    print(f"  WINNER fixed={wf} CV={wc}  medlam={np.median(lp[S]):.0e}  rho(featvar) fixed={rho_f:+.2f} CV={rho_c:+.2f}\n")
print("DONE")
