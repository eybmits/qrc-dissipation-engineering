"""Phase 5 — finite-shot robustness.

Ideal expectation features are replaced by finite-sample estimates
    <O>_Ns ~ N(<O>, 1/Ns)
(both train and test, as in a real experiment).  We retrain the linear readout
on the noisy features and measure STM total memory capacity vs the measurement
budget Ns.

Key question (H-B3): is collective decay more robust to readout noise than local
loss?  Compared families at matched total dissipative strength, lossy regime
γ̄ ∈ {1, 3} where the dissipator differences are largest.
"""
import _paths  # noqa: F401
import json
import time
import numpy as np

from qrc import reservoirs as res, readout, tasks
from qrc import dissipators as dsp
from experiments_baseline import make_config
from experiments_track_b import make_reservoir_with_jumps

cfg = make_config("validation", h=0.5, dt=0.5, quantize=48,
                  n_realizations=4, washout=150, train_len=450, test_len=300)
gammas = [1.0, 3.0]
Ns_list = [1e4, 1e5, 1e6, 1e7, 1e8, 1e10, 1e12]
n_noise = 8                      # average over measurement-noise draws
delays = list(range(1, 16))
families = ["local", "collective", "hetero"]
obs = readout.pauli_observables(cfg.n_qubits, max_weight=cfg.max_weight)
rng_master = np.random.default_rng(cfg.seed + 700)
seeds = rng_master.integers(0, 2 ** 31 - 1, size=cfg.n_realizations)


def build_family(name, J, n, gamma, rng):
    target = dsp.jump_strength(dsp.local_loss(n, gamma))
    if name == "local":
        return dsp.local_loss(n, gamma)
    if name == "collective":
        return dsp.normalize_jump_strength(dsp.collective_loss(n, gamma), target)
    if name == "hetero":
        g = dsp.loguniform_rates(n, gamma / 10, gamma * 10, rng, mean=gamma)
        return [(res.sminus(i, n), float(g[i])) for i in range(n)]
    raise ValueError(name)


def mc_noisy(Xtr, ytr_fn, Xte, yte_inputs, Ns, rng):
    """Total memory capacity with N(0,1/Ns) noise added to train+test features."""
    sigma = 1.0 / np.sqrt(Ns)
    Xtr_n = readout.add_bias(Xtr + sigma * rng.standard_normal(Xtr.shape))
    Xte_n = readout.add_bias(Xte + sigma * rng.standard_normal(Xte.shape))
    mc = 0.0
    for d in delays:
        ytr = tasks.delayed_target(ytr_fn, d)
        yte = tasks.delayed_target(yte_inputs, d)
        mtr = ~np.isnan(ytr); mte = ~np.isnan(yte)
        w = readout.train_readout(Xtr_n[mtr], ytr[mtr], ridge=cfg.ridge)
        mc += readout.capacity(yte[mte], readout.predict(Xte_n[mte], w))
    return mc


# results[gamma][family] -> array (n_real, n_Ns) of mean MC over noise draws
out = {g: {m: np.zeros((cfg.n_realizations, len(Ns_list))) for m in families}
       for g in gammas}
ideal = {g: {m: np.zeros(cfg.n_realizations) for m in families} for g in gammas}
t0 = time.time()
for r_i, sd in enumerate(seeds):
    rng = np.random.default_rng(int(sd))
    J = res.random_couplings(cfg.n_qubits, cfg.J_s, rng)
    inputs = tasks.stm_inputs(cfg.total_len, rng)
    post = inputs[cfg.washout:]
    tr_in = post[:cfg.train_len]; te_in = post[cfg.train_len:]
    for g in gammas:
        for m in families:
            jumps = build_family(m, J, cfg.n_qubits, g, np.random.default_rng(int(sd) + 1))
            reservoir = make_reservoir_with_jumps(J, cfg, jumps)
            X = reservoir.run(inputs, obs, washout=cfg.washout, n_virtual=1)
            Xtr, Xte = X[:cfg.train_len], X[cfg.train_len:]
            # ideal MC (Ns -> inf)
            mc0 = 0.0
            for d in delays:
                ytr = tasks.delayed_target(tr_in, d); yte = tasks.delayed_target(te_in, d)
                a = ~np.isnan(ytr); b = ~np.isnan(yte)
                w = readout.train_readout(readout.add_bias(Xtr)[a], ytr[a], ridge=cfg.ridge)
                mc0 += readout.capacity(yte[b], readout.predict(readout.add_bias(Xte)[b], w))
            ideal[g][m][r_i] = mc0
            for j, Ns in enumerate(Ns_list):
                vals = [mc_noisy(Xtr, tr_in, Xte, te_in, Ns,
                                 np.random.default_rng(1000 + k)) for k in range(n_noise)]
                out[g][m][r_i, j] = np.mean(vals)
    print(f"  realization {r_i+1}/{cfg.n_realizations} ({time.time()-t0:.0f}s)")

result = {"gammas": gammas, "Ns": Ns_list, "families": families, "delays": delays,
          "mc_vs_Ns": {str(g): {m: out[g][m].tolist() for m in families} for g in gammas},
          "mc_ideal": {str(g): {m: ideal[g][m].tolist() for m in families} for g in gammas},
          "seeds": seeds.tolist(), "config": cfg.__dict__, "runtime_s": time.time() - t0}
json.dump(result, open("../results/finite_shot.json", "w"), indent=2)

print("\n=== Finite-shot STM MC vs Ns (mean over realizations) ===")
for g in gammas:
    print(f"\nγ̄={g}  (ideal MC: " +
          ", ".join(f"{m}={ideal[g][m].mean():.1f}" for m in families) + ")")
    print("  Ns:      " + " ".join(f"{ns:7.0e}" for ns in Ns_list))
    for m in families:
        print(f"  {m:10s}" + " ".join(f"{out[g][m].mean(0)[j]:7.2f}"
                                      for j in range(len(Ns_list))))
