"""Phase 2 - Track A: RATE engineering.

Jump operators stay fixed at local loss ``L_i = sigma^-_i``; only the per-qubit
rates ``gamma_i`` change.  Profiles:

    A0 uniform              gamma_i = gamma           (== CD baseline)
    A1 heterogeneous        gamma_i ~ logU[lo, hi]
    A2 structured           gamma_i ∝ deg(i) | sum|J_ij| | 1/sum|J_ij|
    A3 learned/static       gamma_i = softplus(theta_i)   (optimised)
    A4 input-adaptive       gamma_i(s) = softplus(a_i s + b_i)

CONTROL: every heterogeneous/structured profile is compared to uniform loss with
the SAME mean rate ``bar gamma`` (``dissipators.normalize_rates``), so any gain
is not just "more dissipation".

>>> GATING <<<  Do not draw Track-A conclusions until the Phase-0 baseline
replication has passed qualitatively (see reports/replication_report.md).
This module is wired to the same evaluation code but is intentionally NOT run as
part of the baseline validation.
"""
from __future__ import annotations

import _paths  # noqa: F401
import time
from typing import Dict, List

import numpy as np

from qrc import reservoirs as res
from qrc import readout, tasks
from qrc import dissipators as dsp
from experiments_baseline import BaselineConfig, evaluate_delays, make_config, _save


def build_profiles(J: np.ndarray, n: int, mean_gamma: float,
                   rng: np.random.Generator) -> Dict[str, np.ndarray]:
    """All static Track-A rate profiles, each normalised to the same mean."""
    return {
        "A0_uniform": dsp.uniform_rates(n, mean_gamma),
        "A1_loguniform": dsp.loguniform_rates(n, mean_gamma / 10, mean_gamma * 10,
                                              rng, mean=mean_gamma),
        "A2_degree": dsp.degree_rates(J, mean=mean_gamma),
        "A2_coupling": dsp.coupling_rates(J, mean=mean_gamma),
        "A2_inv_coupling": dsp.inverse_coupling_rates(J, mean=mean_gamma),
    }


def run_rate_engineering_stm(cfg: BaselineConfig, mean_gamma: float = 1.0,
                             delays: List[int] | None = None) -> dict:
    """Compare static rate profiles on STM under matched mean dissipation."""
    delays = delays or list(range(1, 16))
    rng_master = np.random.default_rng(cfg.seed + 100)
    seeds = rng_master.integers(0, 2 ** 31 - 1, size=cfg.n_realizations)
    obs = readout.pauli_observables(cfg.n_qubits, max_weight=cfg.max_weight)

    profile_names = ["A0_uniform", "A1_loguniform", "A2_degree",
                     "A2_coupling", "A2_inv_coupling"]
    cap = {m: np.zeros((cfg.n_realizations, len(delays))) for m in profile_names}
    t0 = time.time()
    for r_i, sd in enumerate(seeds):
        rng = np.random.default_rng(int(sd))
        J = res.random_couplings(cfg.n_qubits, cfg.J_s, rng)
        inputs = tasks.stm_inputs(cfg.total_len, rng)
        post = inputs[cfg.washout:]
        profiles = build_profiles(J, cfg.n_qubits, mean_gamma, rng)
        for m in profile_names:
            reservoir = res.continuous_dissipation(
                cfg.n_qubits, J, cfg.h, profiles[m], cfg.dt, quantize=cfg.quantize)
            X = reservoir.run(inputs, obs, washout=cfg.washout, n_virtual=1)
            caps = evaluate_delays(X, post, tasks.delayed_target, delays, cfg, "capacity")
            cap[m][r_i] = [caps[d] for d in delays]
        print(f"  [TrackA-STM] realization {r_i + 1}/{cfg.n_realizations} "
              f"({time.time() - t0:.0f}s)")
    result = dict(task="trackA_stm", delays=np.asarray(delays),
                  models=profile_names, mean_gamma=mean_gamma,
                  capacity=cap, seeds=np.asarray(seeds),
                  config=cfg.__dict__, runtime_s=time.time() - t0)
    _save("trackA_stm", result)
    return result


# ---- A4 input-adaptive (s-dependent rates) --------------------------------

def adaptive_reservoir(J, cfg, a, b):
    """CD reservoir whose loss rates depend on the input: gamma_i(s)."""
    from qrc.reservoirs import ising_xx_hamiltonian, transverse_drive
    n = cfg.n_qubits
    H0 = ising_xx_hamiltonian(J, cfg.h, n)
    Hx = transverse_drive(n)

    def hamiltonian_fn(s):
        return H0 + cfg.h * (s + 1) * Hx

    def jump_fn(s):
        g = dsp.adaptive_rates(s, a, b)
        return [(res.sminus(i, n), float(g[i])) for i in range(n)]

    return res.GeneralLindbladReservoir(n, hamiltonian_fn, jump_fn, cfg.dt,
                                        quantize=cfg.quantize)


# Validated CD operating point from Phase 0 (STM optimum): h=0.5, dt=0.5, gamma_bar=0.3.
# Track A compares rate PROFILES at this point with matched mean dissipation.
STM_OPTIMUM = dict(h=0.5, dt=0.5, mean_gamma=0.3)

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Track A: rate engineering (gate OPEN)")
    ap.add_argument("--preset", default="validation")
    ap.add_argument("--max-delay", type=int, default=15)
    ap.add_argument("--quantize", type=int, default=64)
    args = ap.parse_args()

    cfg = make_config(args.preset, h=STM_OPTIMUM["h"], dt=STM_OPTIMUM["dt"],
                      quantize=args.quantize)
    print(f"=== Track A | STM | operating point {STM_OPTIMUM} | {cfg} ===")
    print("All profiles normalised to mean rate gamma_bar=0.3 (matched total "
          "dissipation); same J and input sequence per realization (paired).")
    run_rate_engineering_stm(cfg, mean_gamma=STM_OPTIMUM["mean_gamma"],
                             delays=list(range(1, args.max_delay + 1)))
