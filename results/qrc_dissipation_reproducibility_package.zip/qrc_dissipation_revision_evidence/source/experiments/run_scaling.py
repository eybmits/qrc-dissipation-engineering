"""Scaling trend check: do the key effects persist from N=5 to N=6?

The Lindblad Liouvillian scales as 4^N x 4^N, so propagator caching is infeasible
beyond N=5 (memory) and we fall back to expm_multiply per step (slow). This is a
LIMITED trend check (few seeds, short sequences) to see whether the qualitative
ordering — collective > paper on STM, dephasing dead — survives a larger reservoir.
A full statistical scaling study (N up to 8, 100 seeds) is a cluster job.

Operating point: matched budget (strength = local loss at gamma=1), h=0.5, dt=0.5.
"""
import _paths  # noqa: F401
import json
import time
import numpy as np

from qrc import reservoirs as res, readout, tasks, dissipators as dsp
from qrc.reservoirs import ising_xx_hamiltonian, transverse_drive, LindbladReservoir

NS = [5, 6]
N_REAL = 3
H, DT, GAMMA = 0.5, 0.5, 1.0
WASH, TRAIN, TEST = 60, 150, 110
DELAYS = list(range(1, 13))


def build(name, J, N, s, rng):
    if name == "CD_paper":
        return dsp.normalize_jump_strength(dsp.local_loss(N, 1.0), s)
    if name == "B3_collective":
        return dsp.normalize_jump_strength(dsp.collective_loss(N, 1.0), s)
    if name == "B5_pair":
        edges = [(i, j) for i in range(N) for j in range(i + 1, N) if abs(J[i, j]) > 1e-9]
        return dsp.normalize_jump_strength(dsp.pair_loss(N, 1.0, edges), s)
    if name == "B1_dephasing":
        return dsp.normalize_jump_strength(dsp.dephasing(N, 1.0), s)
    if name == "A1_heterogeneous":
        g = dsp.loguniform_rates(N, 0.1, 10, rng, mean=1.0)
        return [(res.sminus(i, N), float(g[i])) for i in range(N)]
    raise ValueError(name)


METHODS = ["CD_paper", "A1_heterogeneous", "B3_collective", "B5_pair", "B1_dephasing"]


def stm_mc(X, post):
    Xb = readout.add_bias(X); tr = slice(0, TRAIN); te = slice(TRAIN, TRAIN + TEST)
    tot = 0.0
    for d in DELAYS:
        y = tasks.delayed_target(post, d)
        a = np.zeros(len(y), bool); a[tr] = True; a &= ~np.isnan(y)
        b = np.zeros(len(y), bool); b[te] = True; b &= ~np.isnan(y)
        w = readout.train_readout(Xb[a], y[a], ridge=1e-8)
        tot += readout.capacity(y[b], readout.predict(Xb[b], w))
    return tot


def reservoir(name, J, N, s, rng):
    H0 = ising_xx_hamiltonian(J, H, N); Hx = transverse_drive(N)
    jumps = build(name, J, N, s, rng)
    return LindbladReservoir.from_terms(N, H0 + H * Hx, H * Hx, jumps, DT, quantize=None)


def main():
    total = WASH + TRAIN + TEST
    models = ["FN"] + METHODS
    out = {"NS": NS, "models": models, "n_real": N_REAL,
           "mc": {N: {m: [] for m in models} for N in NS}}
    t0 = time.time()
    for N in NS:
        obs = readout.pauli_observables(N, max_weight=2)
        s = dsp.jump_strength(dsp.local_loss(N, GAMMA))
        seeds = np.random.default_rng(909).integers(0, 2 ** 31 - 1, N_REAL)
        for r_i, sd in enumerate(seeds):
            rng = np.random.default_rng(int(sd))
            J = res.random_couplings(N, 1.0, rng)
            inp = tasks.stm_inputs(total, rng); post = inp[WASH:]
            fn = res.FujiNakajimaReservoir(N, J, H, DT)
            out["mc"][N]["FN"].append(stm_mc(fn.run(inp, obs, washout=WASH), post))
            for m in METHODS:
                r = reservoir(m, J, N, s, np.random.default_rng(int(sd) + 1))
                out["mc"][N][m].append(stm_mc(r.run(inp, obs, washout=WASH), post))
            print(f"  N={N} seed {r_i+1}/{N_REAL} done ({time.time()-t0:.0f}s)")
    out["mc"] = {str(N): out["mc"][N] for N in NS}
    json.dump(out, open("../results/scaling.json", "w"), indent=2)

    print("\n=== STM MC scaling (mean over seeds) — ΔMC vs CD_paper ===")
    for N in NS:
        cd = np.mean(out["mc"][str(N)]["CD_paper"])
        print(f"\nN={N}:  CD_paper MC={cd:.2f}  FN MC={np.mean(out['mc'][str(N)]['FN']):.2f}")
        for m in METHODS:
            if m == "CD_paper":
                continue
            v = np.mean(out["mc"][str(N)][m])
            print(f"  {m:18s} MC={v:5.2f}  ΔvsCD={v-cd:+.2f} ({100*(v-cd)/cd:+.0f}%)")


if __name__ == "__main__":
    main()
