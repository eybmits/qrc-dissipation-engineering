"""Per-model hyperparameter grid search with train / validation / test splits.

The baseline paper compares each reservoir at its *own* optimal (h, Δt, γ); a
fixed operating point is not a fair comparison.  This module sweeps the grid,
selects the operating point per model on a held-out **validation** split, and
reports the **test** score at that point — closing the Phase-0 gate honestly.

Split convention (per realization, one input sequence):
    [ washout | train | validation | test ]
Hyperparameters are chosen by validation score; test is reported only at the
selected point.  Readout weights are always retrained (linear / SVD).
"""
from __future__ import annotations

import _paths  # noqa: F401
import itertools
import json
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np

from qrc import reservoirs as res
from qrc import readout, tasks
from experiments_baseline import BaselineConfig, make_config
from _paths import RESULTS_DIR


@dataclass
class GridConfig:
    n_qubits: int = 5
    J_s: float = 1.0
    washout: int = 150
    train_len: int = 350
    val_len: int = 150
    test_len: int = 250
    n_realizations: int = 3
    seed: int = 2024
    quantize: int = 24          # coarse during search (ranking only); refine winner
    ridge: float = 1e-8
    max_weight: int = 2

    @property
    def total_len(self) -> int:
        return self.washout + self.train_len + self.val_len + self.test_len


def _splits(g: GridConfig):
    a = g.train_len
    b = a + g.val_len
    c = b + g.test_len
    return slice(0, a), slice(a, b), slice(b, c)


def _delay_scores(X, post, target_fn, delays, g: GridConfig, metric, which):
    """Return per-delay metric on the chosen ('val' or 'test') split."""
    Xb = readout.add_bias(X)
    tr, va, te = _splits(g)
    sel = {"val": va, "test": te}[which]
    out = {}
    for d in delays:
        y = target_fn(post, d)
        valid = ~np.isnan(y)
        trm = np.zeros(len(y), bool); trm[tr] = True; trm &= valid
        sm = np.zeros(len(y), bool); sm[sel] = True; sm &= valid
        r = readout.fit_and_score(Xb[trm], y[trm], Xb[sm], y[sm],
                                  metric=metric, ridge=g.ridge)
        out[d] = r.test_metric
    return out


def _build(kind, J, g, h, dt, gamma):
    if kind == "FN":
        return res.FujiNakajimaReservoir(g.n_qubits, J, h, dt)
    return res.continuous_dissipation(g.n_qubits, J, h, gamma, dt,
                                      quantize=g.quantize)


def grid_search_stm(
    g: GridConfig,
    kind: str,
    h_list: List[float],
    dt_list: List[float],
    gamma_list: List[float],
    delays: List[int],
    metric: str = "capacity",
    aggregate: str = "sum",   # 'sum' -> total memory capacity
) -> dict:
    """Grid-search STM for one model family; select by validation, report test."""
    if kind == "FN":
        gamma_list = [None]
    rng_master = np.random.default_rng(g.seed)
    seeds = rng_master.integers(0, 2 ** 31 - 1, size=g.n_realizations)
    obs = readout.pauli_observables(g.n_qubits, max_weight=g.max_weight)
    points = list(itertools.product(h_list, dt_list, gamma_list))

    val_cap = {p: np.zeros((g.n_realizations, len(delays))) for p in points}
    test_cap = {p: np.zeros((g.n_realizations, len(delays))) for p in points}

    t0 = time.time()
    for r_i, sd in enumerate(seeds):
        rng = np.random.default_rng(int(sd))
        J = res.random_couplings(g.n_qubits, g.J_s, rng)
        inputs = tasks.stm_inputs(g.total_len, rng)
        post = inputs[g.washout:]
        for p in points:
            h, dt, gamma = p
            reservoir = _build(kind, J, g, h, dt, gamma)
            X = reservoir.run(inputs, obs, washout=g.washout, n_virtual=1)
            vs = _delay_scores(X, post, tasks.delayed_target, delays, g, metric, "val")
            ts = _delay_scores(X, post, tasks.delayed_target, delays, g, metric, "test")
            val_cap[p][r_i] = [vs[d] for d in delays]
            test_cap[p][r_i] = [ts[d] for d in delays]
        print(f"  [{kind}] realization {r_i+1}/{g.n_realizations} "
              f"({len(points)} pts, {time.time()-t0:.0f}s)")

    # aggregate score per point (mean over realizations of summed capacity)
    def agg(arr):
        s = arr.sum(axis=1) if aggregate == "sum" else arr.mean(axis=1)
        return s.mean(), s.std()

    rows = []
    for p in points:
        vm, vs_ = agg(val_cap[p])
        tm, ts_ = agg(test_cap[p])
        rows.append((p, vm, vs_, tm, ts_))
    best = max(rows, key=lambda r: r[1])          # select on validation
    best_p = best[0]
    return dict(
        kind=kind, metric=metric, delays=delays, points=[list(p) for p in points],
        rows=[(list(p), vm, vs, tm, ts) for (p, vm, vs, tm, ts) in rows],
        best_params=list(best_p),
        best_val=best[1], best_test=best[3],
        best_test_per_delay=test_cap[best_p].mean(axis=0).tolist(),
        seeds=seeds.tolist(), runtime_s=time.time() - t0,
        config=g.__dict__.copy(),
    )


def grid_search_narma(
    g: GridConfig,
    kind: str,
    h_list: List[float],
    dt_list: List[float],
    gamma_list: List[float],
    order: int = 10,
    input_scale: float = 0.2,
) -> dict:
    """Grid-search NARMA-``order`` for one model; select by min validation NMSE."""
    if kind == "FN":
        gamma_list = [None]
    rng_master = np.random.default_rng(g.seed + 50)
    seeds = rng_master.integers(0, 2 ** 31 - 1, size=g.n_realizations)
    obs = readout.pauli_observables(g.n_qubits, max_weight=g.max_weight)
    points = list(itertools.product(h_list, dt_list, gamma_list))
    target_fn = lambda s, n: tasks.narma_target(s, order=n, input_scale=input_scale)

    val = {p: np.zeros(g.n_realizations) for p in points}
    test = {p: np.zeros(g.n_realizations) for p in points}
    t0 = time.time()
    for r_i, sd in enumerate(seeds):
        rng = np.random.default_rng(int(sd))
        J = res.random_couplings(g.n_qubits, g.J_s, rng)
        inputs = tasks.narma_inputs(g.total_len, rng)
        post = inputs[g.washout:]
        for p in points:
            h, dt, gamma = p
            reservoir = _build(kind, J, g, h, dt, gamma)
            X = reservoir.run(inputs, obs, washout=g.washout, n_virtual=1)
            vs = _delay_scores(X, post, target_fn, [order], g, "nmse", "val")
            ts = _delay_scores(X, post, target_fn, [order], g, "nmse", "test")
            val[p][r_i] = vs[order]
            test[p][r_i] = ts[order]
        print(f"  [{kind} NARMA-{order}] realization {r_i+1}/{g.n_realizations} "
              f"({time.time()-t0:.0f}s)")
    rows = [(p, val[p].mean(), val[p].std(), test[p].mean(), test[p].std())
            for p in points]
    best = min(rows, key=lambda r: r[1])           # min validation NMSE
    return dict(
        kind=kind, order=order, metric="nmse",
        rows=[(list(p), vm, vs, tm, ts) for (p, vm, vs, tm, ts) in rows],
        best_params=list(best[0]), best_val=best[1], best_test=best[3],
        seeds=seeds.tolist(), runtime_s=time.time() - t0, config=g.__dict__.copy(),
    )


def confirm_stm(h_fn, dt_fn, h_cd, dt_cd, gamma_cd, delays,
                n_real=8, quantize=96, washout=200, train=600, test=400, seed=999):
    """Fair high-fidelity head-to-head at the selected operating points
    (more realizations, fine input quantisation, train/test only)."""
    g = GridConfig(n_realizations=n_real, quantize=quantize, washout=washout,
                   train_len=train, val_len=0, test_len=test, seed=seed)
    rng_master = np.random.default_rng(seed)
    seeds = rng_master.integers(0, 2 ** 31 - 1, size=n_real)
    obs = readout.pauli_observables(g.n_qubits, max_weight=g.max_weight)
    cap = {"FN": np.zeros((n_real, len(delays))),
           "CD": np.zeros((n_real, len(delays)))}
    for r_i, sd in enumerate(seeds):
        rng = np.random.default_rng(int(sd))
        J = res.random_couplings(g.n_qubits, g.J_s, rng)
        inputs = tasks.stm_inputs(g.total_len, rng)
        post = inputs[g.washout:]
        for kind, (h, dt, gam) in {"FN": (h_fn, dt_fn, None),
                                   "CD": (h_cd, dt_cd, gamma_cd)}.items():
            reservoir = _build(kind, J, g, h, dt, gam)
            X = reservoir.run(inputs, obs, washout=g.washout, n_virtual=1)
            ts = _delay_scores(X, post, tasks.delayed_target, delays, g, "capacity", "test")
            cap[kind][r_i] = [ts[d] for d in delays]
        print(f"  [confirm] realization {r_i+1}/{n_real} done")
    return dict(delays=delays, cap_fn=cap["FN"].tolist(), cap_cd=cap["CD"].tolist(),
                fn_params=[h_fn, dt_fn], cd_params=[h_cd, dt_cd, gamma_cd],
                seeds=seeds.tolist())


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-delay", type=int, default=12)
    ap.add_argument("--n-real", type=int, default=3)
    ap.add_argument("--quantize", type=int, default=24)
    args = ap.parse_args()

    g = GridConfig(n_realizations=args.n_real, quantize=args.quantize)
    delays = list(range(1, args.max_delay + 1))
    # grid emphasising small dt (longer step-memory hypothesis) and h to keep drive
    h_list = [0.5, 1.0, 2.0]
    dt_list = [0.1, 0.25, 0.5, 1.0]
    gamma_list = [0.3, 1.0, 3.0]

    print(f"=== STM grid search | delays 1..{args.max_delay} | {g} ===")
    out = {}
    print("\n--- FN ---")
    out["FN"] = grid_search_stm(g, "FN", h_list, dt_list, [None], delays)
    print(f"  FN best (h,dt): {out['FN']['best_params']}  "
          f"val MC={out['FN']['best_val']:.2f}  test MC={out['FN']['best_test']:.2f}")
    print("\n--- CD ---")
    out["CD"] = grid_search_stm(g, "CD", h_list, dt_list, gamma_list, delays)
    print(f"  CD best (h,dt,γ): {out['CD']['best_params']}  "
          f"val MC={out['CD']['best_val']:.2f}  test MC={out['CD']['best_test']:.2f}")

    with open(f"{RESULTS_DIR}/grid_stm.json", "w") as f:
        json.dump(out, f, indent=2)
    print(f"\nsaved results/grid_stm.json")
    print(f"\n>>> VERDICT: CD test MC {out['CD']['best_test']:.2f} vs "
          f"FN test MC {out['FN']['best_test']:.2f} -> "
          f"{'CD >= FN ✓' if out['CD']['best_test'] >= out['FN']['best_test'] else 'FN > CD'}")


if __name__ == "__main__":
    main()
