"""Render the two fair comparisons from best_vs_best.json:
   (1) best-vs-best   — each method at its own (Δt, dissipation-strength) optimum
   (2) matched-budget — all at the same strength (s=80), each at its own best Δt
"""
import _paths  # noqa: F401
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from _paths import RESULTS_DIR, FIGURES_DIR

REF = "CD_paper (uniform local)"


def _pct(v, ref, higher_better):
    if ref == 0:
        return 0.0
    r = (v - ref) / abs(ref) * 100
    return r if higher_better else -r


def tables():
    d = json.load(open(f"{RESULTS_DIR}/best_vs_best.json"))
    R = d["results"]; ms = d["methods"]
    bb_ref_stm = R[REF]["stm_test_MC"]; bb_ref_nar = R[REF]["narma_test_NMSE"]
    mb_ref_stm = R[REF]["mb_stm_test_MC"]; mb_ref_nar = R[REF]["mb_narma_test_NMSE"]

    out = ["## (1) Best-vs-best — each method at its OWN optimum",
           "",
           "Per-method (Δt, strength) tuned on validation; test reported. "
           "γ is the strength level (local-loss-at-γ). % vs CD_paper, + = better.",
           "",
           "| method | STM MC ↑ | @(Δt,γ) | NARMA NMSE ↓ | @(Δt,γ) |",
           "|---|---|---|---|---|"]
    for m in ms:
        r = R[m]
        s = r["stm_test_MC"]; na = r["narma_test_NMSE"]
        ds = "" if m == REF else f" ({_pct(s, bb_ref_stm, True):+.0f}%)"
        dn = "" if m == REF else f" ({_pct(na, bb_ref_nar, False):+.0f}%)"
        out.append(f"| {m} | {s:.2f}{ds} | {tuple(r['stm_best_dt_sgamma'])} | "
                   f"{na:.3f}{dn} | {tuple(r['narma_best_dt_sgamma'])} |")

    out += ["", "## (2) Matched budget — same dissipation strength (s=80), best Δt each",
            "",
            "Fair-budget control: equal total dissipative strength `Σ rate·Tr(L†L)=80` "
            "for all; only Δt tuned. Isolates which dissipator STRUCTURE is best at "
            "equal budget. % vs CD_paper, + = better.",
            "",
            "| method | STM MC ↑ | @Δt | NARMA NMSE ↓ | @Δt |",
            "|---|---|---|---|---|"]
    for m in ms:
        r = R[m]
        s = r["mb_stm_test_MC"]; na = r["mb_narma_test_NMSE"]
        ds = "" if m == REF else f" ({_pct(s, mb_ref_stm, True):+.0f}%)"
        dn = "" if m == REF else f" ({_pct(na, mb_ref_nar, False):+.0f}%)"
        out.append(f"| {m} | {s:.2f}{ds} | {r['mb_stm_best_dt']} | "
                   f"{na:.3f}{dn} | {r['mb_narma_best_dt']} |")
    return "\n".join(out), d


def figure(d):
    R = d["results"]; ms = [m for m in d["methods"]]
    short = [m.split(" (")[0].replace("CD_paper", "CD").replace("heterogeneous rates", "A1")
             .replace("coupling-structured", "A2cpl").replace("inverse-coupling", "A2inv")
             .replace("collective", "coll").replace("loss+exchange", "l+exch")
             .replace("dephasing", "deph").replace("thermal", "therm").replace("pair loss", "pair")
             for m in ms]
    bb = [R[m]["stm_test_MC"] for m in ms]
    mb = [R[m]["mb_stm_test_MC"] for m in ms]
    x = np.arange(len(ms)); w = 0.4
    fig, ax = plt.subplots(figsize=(11, 5))
    ax.bar(x - w/2, bb, w, label="best-vs-best (own strength)")
    ax.bar(x + w/2, mb, w, label="matched budget (s=80)")
    ax.axhline(R[REF]["stm_test_MC"], color="k", ls="--", lw=1, label="CD_paper best")
    ax.set_xticks(x); ax.set_xticklabels(short, rotation=35, ha="right", fontsize=8)
    ax.set_ylabel("STM total memory capacity (test)")
    ax.set_title("STM: best-vs-best vs matched-budget, per dissipation method")
    ax.legend(fontsize=8); ax.grid(alpha=0.3, axis="y")
    fig.tight_layout(); fig.savefig(f"{FIGURES_DIR}/best_vs_best.png", dpi=130)
    print("wrote best_vs_best.png")


def main():
    txt, d = tables()
    figure(d)
    print("\n" + txt)
    return txt


if __name__ == "__main__":
    main()
