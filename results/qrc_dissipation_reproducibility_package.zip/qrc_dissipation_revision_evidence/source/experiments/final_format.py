"""Render the final story table: FN (normal) -> CD (paper) -> our methods."""
import _paths  # noqa: F401
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from _paths import RESULTS_DIR, FIGURES_DIR

FN = "FN (normal/unitary)"
CD = "CD_paper (uniform local)"


def _se(a):
    a = np.asarray(a); return a.mean(), a.std(ddof=1) / np.sqrt(len(a))


def _paired_sigma(a, ref, higher_better):
    a = np.asarray(a); ref = np.asarray(ref)
    d = (a - ref) if higher_better else (ref - a)
    s = d.std(ddof=1) / np.sqrt(len(d))
    return d.mean() / (s + 1e-12)


def render():
    d = json.load(open(f"{RESULTS_DIR}/final_table.json"))
    stm = d["stm"]; nar = d["narma"]; n = d["n_real"]
    fn_s, cd_s = np.array(stm[FN]), np.array(stm[CD])
    fn_n, cd_n = np.array(nar[FN]), np.array(nar[CD])
    # order: FN, CD, then methods by STM mean (desc)
    methods = [m for m in d["models"] if m not in (FN, CD)]
    methods.sort(key=lambda m: -np.mean(stm[m]))
    order = [FN, CD] + methods

    L = [f"## Final table — FN → CD → engineered dissipators  (N={n} seeds, mean ± SE)",
         "",
         "STM = total memory capacity (↑). NARMA-10 NMSE (↓). "
         "`%FN`/`%CD` = improvement over the normal model / the paper model. "
         "`σ/CD` = paired significance of beating the paper model.",
         "",
         "| model | STM MC | %FN | %CD | σ/CD | NARMA NMSE | %CD |",
         "|---|---|---|---|---|---|---|"]
    for m in order:
        ms, se = _se(stm[m]); mn, sen = _se(nar[m])
        pfn = (ms - fn_s.mean()) / fn_s.mean() * 100
        pcd = (ms - cd_s.mean()) / cd_s.mean() * 100
        sig = _paired_sigma(stm[m], cd_s, True)
        pcd_n = (cd_n.mean() - mn) / cd_n.mean() * 100  # positive = better than CD
        label = m + ("  ← paper" if m == CD else ("  ← normal" if m == FN else ""))
        L.append(f"| {label} | {ms:.2f}±{se:.2f} | {pfn:+.0f}% | "
                 f"{'—' if m in (FN, CD) else f'{pcd:+.0f}%'} | "
                 f"{'—' if m in (FN, CD) else f'{sig:.1f}σ'} | "
                 f"{mn:.3f}±{sen:.3f} | {'—' if m in (FN, CD) else f'{pcd_n:+.0f}%'} |")
    return "\n".join(L), d, order


def figure(d, order):
    stm = d["stm"]
    fn = np.mean(stm[FN]); cd = np.mean(stm[CD])
    labels = [m.split(" (")[0].replace("FN (normal/unitary)", "FN")
              .replace("CD_paper", "CD").replace("heterogeneous rates", "A1")
              .replace("coupling-structured", "A2cpl").replace("inverse-coupling", "A2inv")
              .replace("collective", "coll").replace("loss+exchange", "l+exch")
              .replace("dephasing", "deph").replace("thermal", "therm").replace("pair loss", "pair")
              for m in order]
    means = [np.mean(stm[m]) for m in order]
    ses = [np.std(stm[m], ddof=1) / np.sqrt(len(stm[m])) for m in order]
    colors = ["#888"] + ["#1f77b4"] + ["#2ca02c"] * (len(order) - 2)
    fig, ax = plt.subplots(figsize=(11, 5))
    ax.bar(range(len(order)), means, yerr=ses, capsize=3, color=colors)
    ax.axhline(fn, color="#888", ls="--", lw=1, label="FN (normal)")
    ax.axhline(cd, color="#1f77b4", ls="--", lw=1, label="CD (paper)")
    ax.set_xticks(range(len(order))); ax.set_xticklabels(labels, rotation=35, ha="right", fontsize=8)
    ax.set_ylabel("STM total memory capacity (test)")
    ax.set_title(f"FN → CD → engineered dissipators  (N={d['n_real']} seeds, ±SE)")
    ax.legend(fontsize=8); ax.grid(alpha=0.3, axis="y")
    fig.tight_layout(); fig.savefig(f"{FIGURES_DIR}/final_table.png", dpi=130)
    print("wrote final_table.png")


def main():
    txt, d, order = render()
    figure(d, order)
    print("\n" + txt)
    return txt


if __name__ == "__main__":
    main()
