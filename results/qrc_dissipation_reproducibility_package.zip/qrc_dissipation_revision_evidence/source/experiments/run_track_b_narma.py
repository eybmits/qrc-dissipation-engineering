"""Track B on NARMA — testing H-B4 correctly (transport ON TOP OF loss).

Pure exchange / dephasing are *unital* (D[I]=0) ⇒ they relax to the maximally
mixed state I/2^N, which the Hamiltonian drive cannot shift ⇒ they cannot encode
the input at all (zero capacity on STM, and on any task).  So H-B4 ("dissipative
transport improves nonlinear processing") must be tested by **adding** exchange to
a working (non-unital) loss reservoir, at matched total dissipative strength.

Families (all matched to the strength of B0 local loss at rate γ):
  B0_local         : Σ rate on σ^-_i
  loss+exchange(α) : fraction (1-α) of the budget on local loss, α on exchange
  B3_collective    : single collective σ^-
  B2_thermal       : σ^- and σ^+

Operating point: the Phase-0 NARMA optimum (h=0.5, Δt=0.25).  Metric: test NMSE.
"""
import _paths  # noqa: F401
import json
import time
import numpy as np

from qrc import reservoirs as res, readout, tasks
from qrc import dissipators as dsp
from experiments_baseline import make_config, evaluate_delays
from experiments_track_b import make_reservoir_with_jumps


def loss_exchange(n, gamma, edges, alpha):
    """Local loss + exchange, total strength = strength(local loss at gamma),
    with fraction ``alpha`` of the budget in exchange transport."""
    S0 = dsp.jump_strength(dsp.local_loss(n, gamma))
    loss = dsp.normalize_jump_strength(dsp.local_loss(n, 1.0), (1 - alpha) * S0)
    if alpha > 0 and edges:
        ex = dsp.normalize_jump_strength(dsp.exchange(n, 1.0, edges), alpha * S0)
        return loss + ex
    return loss


cfg = make_config("validation", h=0.5, dt=0.25, quantize=48,
                  n_realizations=4, washout=150, train_len=450, test_len=300)
gammas = [0.3, 1.0]
orders = [5, 10]
input_scale = 0.2
fam_names = ["B0_local", "lossexch_0.3", "lossexch_0.6", "B3_collective"]
obs = readout.pauli_observables(cfg.n_qubits, max_weight=cfg.max_weight)
rng_master = np.random.default_rng(cfg.seed + 500)
seeds = rng_master.integers(0, 2 ** 31 - 1, size=cfg.n_realizations)

# nmse[gamma][family][order] -> (n_real,)
nmse = {g: {m: {o: np.zeros(cfg.n_realizations) for o in orders} for m in fam_names}
        for g in gammas}
t0 = time.time()
for r_i, sd in enumerate(seeds):
    rng = np.random.default_rng(int(sd))
    J = res.random_couplings(cfg.n_qubits, cfg.J_s, rng)
    edges = dsp.graph_edges(J)
    inputs = tasks.narma_inputs(cfg.total_len, rng)
    post = inputs[cfg.washout:]
    for g in gammas:
        fams = {
            "B0_local": loss_exchange(cfg.n_qubits, g, edges, 0.0),
            "lossexch_0.3": loss_exchange(cfg.n_qubits, g, edges, 0.3),
            "lossexch_0.6": loss_exchange(cfg.n_qubits, g, edges, 0.6),
            "B3_collective": dsp.normalize_jump_strength(
                dsp.collective_loss(cfg.n_qubits, g),
                dsp.jump_strength(dsp.local_loss(cfg.n_qubits, g))),
        }
        for m in fam_names:
            reservoir = make_reservoir_with_jumps(J, cfg, fams[m])
            X = reservoir.run(inputs, obs, washout=cfg.washout, n_virtual=1)
            for o in orders:
                tf = lambda s, n: tasks.narma_target(s, order=n, input_scale=input_scale)
                sc = evaluate_delays(X, post, tf, [o], cfg, "nmse")
                nmse[g][m][o][r_i] = sc[o]
    print(f"  realization {r_i+1}/{cfg.n_realizations} ({time.time()-t0:.0f}s)")

out = {"gammas": gammas, "orders": orders, "families": fam_names,
       "nmse": {str(g): {m: {str(o): nmse[g][m][o].tolist() for o in orders}
                         for m in fam_names} for g in gammas},
       "seeds": seeds.tolist(), "config": cfg.__dict__, "runtime_s": time.time() - t0}
json.dump(out, open("../results/trackB_narma.json", "w"), indent=2)

print("\n=== Track B NARMA: test NMSE (lower=better), mean ± std ===")
for g in gammas:
    print(f"\nstrength budget γ={g}:")
    for o in orders:
        base = nmse[g]["B0_local"][o]
        print(f"  NARMA-{o}:  ", end="")
        for m in fam_names:
            v = nmse[g][m][o]
            tag = "" if m == "B0_local" else (
                f"(Δ{v.mean()-base.mean():+.3f})")
            print(f"{m}={v.mean():.3f}{tag}  ", end="")
        print()
