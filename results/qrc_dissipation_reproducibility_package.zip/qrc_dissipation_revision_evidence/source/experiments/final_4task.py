"""Merge the 16-seed results into one 4-task table: STM, NARMA, parity, MG."""
import _paths  # noqa: F401
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from _paths import RESULTS_DIR, FIGURES_DIR

FN = "FN (normal/unitary)"
CD = "CD_paper (uniform local)"
# (name, dict-key-loader, higher_is_better, label)
TASKS = [("STM MC", "stm", True), ("NARMA NMSE", "narma", False),
         ("parity cap", "parity", True), ("MG MSE", "mg", False)]


def load():
    ft = json.load(open(f"{RESULTS_DIR}/final_table.json"))
    par = json.load(open(f"{RESULTS_DIR}/final_parity.json"))["value"]
    mg = json.load(open(f"{RESULTS_DIR}/final_mg.json"))["value"]
    data = {"stm": ft["stm"], "narma": ft["narma"], "parity": par, "mg": mg}
    return ft["models"], {k: {m: np.array(v[m]) for m in v} for k, v in data.items()}


def _sig(a, ref, hb):
    d = (a - ref) if hb else (ref - a)
    return d.mean() / (d.std(ddof=1) / np.sqrt(len(d)) + 1e-12)


def table(models, D):
    # order: FN, CD, methods by STM
    methods = [m for m in models if m not in (FN, CD)]
    methods.sort(key=lambda m: -D["stm"][m].mean())
    order = [FN, CD] + methods
    head = "| model | " + " | ".join(f"{n} {'↑' if hb else '↓'}" for n, _, hb in TASKS) + " |"
    L = ["## Final 4-task table — FN → CD → engineered dissipators (N=16 seeds)",
         "",
         "Each cell: mean ± SE, and (vs CD: %improvement, paired σ). "
         "+% always = better than the paper model.", "",
         head, "|" + "---|" * (len(TASKS) + 1)]
    for m in order:
        cells = [m + ("  ← paper" if m == CD else ("  ← normal" if m == FN else ""))]
        for _, key, hb in TASKS:
            a = D[key][m]; ref = D[key][CD]
            mean = a.mean(); se = a.std(ddof=1) / np.sqrt(len(a))
            if m in (FN, CD):
                cells.append(f"{mean:.3g} ± {se:.2g}")
            else:
                imp = (mean - ref.mean()) / abs(ref.mean()) * 100
                imp = imp if hb else -imp
                cells.append(f"{mean:.3g} ({imp:+.0f}%, {_sig(a, ref, hb):+.1f}σ)")
        L.append("| " + " | ".join(cells) + " |")
    return "\n".join(L), order


def figure(D, order):
    fig, ax = plt.subplots(2, 2, figsize=(13, 8))
    for k, (name, key, hb) in enumerate(TASKS):
        a = ax[k // 2][k % 2]
        means = [D[key][m].mean() for m in order]
        ses = [D[key][m].std(ddof=1) / np.sqrt(len(D[key][m])) for m in order]
        labels = [m.split(" (")[0].replace("FN", "FN").replace("CD_paper", "CD")
                  .replace("heterogeneous rates", "A1").replace("coupling-structured", "A2cpl")
                  .replace("inverse-coupling", "A2inv").replace("collective", "coll")
                  .replace("loss+exchange", "l+exch").replace("dephasing", "deph")
                  .replace("thermal", "therm").replace("pair loss", "pair") for m in order]
        colors = ["#888", "#1f77b4"] + ["#2ca02c"] * (len(order) - 2)
        a.bar(range(len(order)), means, yerr=ses, capsize=2, color=colors)
        a.axhline(D[key][CD].mean(), color="#1f77b4", ls="--", lw=1)
        a.set_xticks(range(len(order))); a.set_xticklabels(labels, rotation=40, ha="right", fontsize=7)
        a.set_title(f"{name} {'(↑ better)' if hb else '(↓ better)'}"); a.grid(alpha=0.3, axis="y")
    fig.suptitle("Robust 4-task comparison (N=16 seeds, ±SE; dashed = paper/CD)")
    fig.tight_layout(); fig.savefig(f"{FIGURES_DIR}/final_4task.png", dpi=130)
    print("wrote final_4task.png")


def main():
    models, D = load()
    txt, order = table(models, D)
    figure(D, order)
    print("\n" + txt)
    return txt


if __name__ == "__main__":
    main()
