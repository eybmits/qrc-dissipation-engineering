"""Render the master comparison (performance + diagnostics) as markdown + figure."""
import _paths  # noqa: F401
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from _paths import RESULTS_DIR, FIGURES_DIR

REF = "CD_paper (uniform local)"
# (label, higher_is_better)
TASKS = [("STM", "MC", True), ("NARMA", "NMSE", False),
         ("parity", "cap", True), ("MG", "MSE", False)]


def _rel(method_val, ref_val, higher_better):
    """Signed % change vs reference, positive = better than the paper method."""
    if ref_val == 0:
        return 0.0
    raw = (method_val - ref_val) / abs(ref_val) * 100
    return raw if higher_better else -raw


def performance_table(d):
    perf = d["perf"]
    ref = {t: np.mean(perf[REF][t]) for t, _, _ in TASKS}
    lines = ["### Performance vs the paper's method (CD = uniform local loss)", "",
             "Each cell: absolute metric (mean over 4 paired realizations); "
             "**±%** = change vs CD_paper, *positive = better*. "
             "Matched total dissipation, identical readout. γ=1.0.", "",
             "| method | STM MC ↑ | NARMA-10 NMSE ↓ | parity cap ↑ | MG MSE ↓ |",
             "|---|---|---|---|---|"]
    for m in d["methods"]:
        cells = [m]
        for t, _, hb in TASKS:
            v = np.mean(perf[m][t])
            if m == REF:
                cells.append(f"**{v:.3g}** (ref)")
            elif m.startswith("FN"):
                cells.append(f"{v:.3g}")
            else:
                r = _rel(v, ref[t], hb)
                arrow = "🟢" if r > 2 else ("🔴" if r < -2 else "⚪")
                cells.append(f"{v:.3g} ({r:+.0f}% {arrow})")
        lines.append("| " + " | ".join(cells) + " |")
    lines += ["", "FN = Fuji–Nakajima unitary reservoir (pre-dissipation baseline); "
              "it has no matched-dissipation control and is shown for context only."]
    return "\n".join(lines)


def diagnostics_table(d):
    dg = d["diagnostics"]
    lines = ["### Diagnostics at the STM operating point (Phase 4)", "",
             "| method | unitality | gap Δ_L | t_mix | separability | eff. rank | cond | forget (steps) |",
             "|---|---|---|---|---|---|---|---|"]
    for m in d["diag_methods"]:
        f = lambda k: np.mean(dg[m][k])
        lines.append(f"| {m} | {f('unitality'):.2f} | {f('gap'):.3f} | {f('t_mix'):.2f} | "
                     f"{f('separability'):.3f} | {f('eff_rank'):.1f} | {f('cond'):.0f} | "
                     f"{f('forget_steps'):.0f} |")
    lines += ["", "*unitality 0 ⇒ input-blind/useless; separability ≈0 ⇒ no STM; "
              "smaller gap / larger t_mix / larger forget ⇒ longer memory.*"]
    return "\n".join(lines)


def figure(d):
    perf = d["perf"]
    methods = [m for m in d["methods"] if not m.startswith("FN")]
    ref = {t: np.mean(perf[REF][t]) for t, _, _ in TASKS}
    short = {m: m.replace(" heterogeneous rates", " hetero").replace(" coupling-structured", " cpl")
             .replace(" inverse-coupling", " inv").replace(" collective (graph c)", " coll-graph")
             .replace(" collective", " coll").replace(" loss+exchange", " l+exch")
             .replace(" dephasing", " deph").replace(" thermal", " therm")
             .replace(" pair loss", " pair") for m in methods}
    fig, ax = plt.subplots(figsize=(11, 5))
    x = np.arange(len(methods)); w = 0.2
    for k, (t, _, hb) in enumerate(TASKS):
        vals = [_rel(np.mean(perf[m][t]), ref[t], hb) for m in methods]
        ax.bar(x + k * w, vals, w, label=t)
    ax.axhline(0, color="k", lw=1)
    ax.set_xticks(x + 1.5 * w)
    ax.set_xticklabels([short[m] for m in methods], rotation=35, ha="right", fontsize=8)
    ax.set_ylim(bottom=max(-160, min(-160, ax.get_ylim()[0])))
    ax.set_ylabel("% change vs CD_paper (positive = better)")
    ax.set_title("New dissipation methods vs the paper's method, per task")
    ax.legend(fontsize=8); ax.grid(alpha=0.3, axis="y")
    fig.tight_layout(); fig.savefig(f"{FIGURES_DIR}/master_comparison.png", dpi=130)
    print("wrote master_comparison.png")


def main():
    d = json.load(open(f"{RESULTS_DIR}/master_comparison.json"))
    pt = performance_table(d); dt = diagnostics_table(d)
    figure(d)
    print("\n" + pt + "\n\n" + dt)
    return pt, dt


if __name__ == "__main__":
    main()
