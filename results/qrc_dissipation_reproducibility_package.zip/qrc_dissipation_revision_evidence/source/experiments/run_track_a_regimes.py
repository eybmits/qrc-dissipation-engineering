"""Track A follow-up: does rate heterogeneity help more in a LOSSIER regime?

The γ̄=0.3 STM optimum already has long memory, leaving little room for a spatial
hierarchy to help.  Here we sweep the matched mean rate γ̄ and, for each, measure
the paired ΔMC of every profile vs uniform.  Hypothesis: heterogeneity (esp.
inverse-coupling, i.e. strongly-coupled qubits forgetting slower) helps more when
γ̄ is large and memory is scarce.
"""
import _paths  # noqa: F401
import json
import time
import numpy as np

from qrc import reservoirs as res, readout, tasks
from experiments_baseline import make_config, evaluate_delays
from experiments_track_a import build_profiles

cfg = make_config("validation", h=0.5, dt=0.5, quantize=48,
                  n_realizations=4, washout=150, train_len=450, test_len=300)
gammabars = [0.3, 1.0, 3.0]
delays = list(range(1, 16))
profile_names = ["A0_uniform", "A1_loguniform", "A2_degree",
                 "A2_coupling", "A2_inv_coupling"]
obs = readout.pauli_observables(cfg.n_qubits, max_weight=cfg.max_weight)

rng_master = np.random.default_rng(cfg.seed + 300)
seeds = rng_master.integers(0, 2 ** 31 - 1, size=cfg.n_realizations)

# mc[gbar][profile] -> (n_real,)
mc = {gb: {m: np.zeros(cfg.n_realizations) for m in profile_names} for gb in gammabars}
t0 = time.time()
for r_i, sd in enumerate(seeds):
    rng = np.random.default_rng(int(sd))
    J = res.random_couplings(cfg.n_qubits, cfg.J_s, rng)
    inputs = tasks.stm_inputs(cfg.total_len, rng)
    post = inputs[cfg.washout:]
    for gb in gammabars:
        profiles = build_profiles(J, cfg.n_qubits, gb, rng)
        for m in profile_names:
            reservoir = res.continuous_dissipation(
                cfg.n_qubits, J, cfg.h, profiles[m], cfg.dt, quantize=cfg.quantize)
            X = reservoir.run(inputs, obs, washout=cfg.washout, n_virtual=1)
            caps = evaluate_delays(X, post, tasks.delayed_target, delays, cfg, "capacity")
            mc[gb][m][r_i] = sum(caps[d] for d in delays)
    print(f"  realization {r_i+1}/{cfg.n_realizations} ({time.time()-t0:.0f}s)")

out = {"gammabars": gammabars, "profiles": profile_names,
       "mc": {str(gb): {m: mc[gb][m].tolist() for m in profile_names} for gb in gammabars},
       "seeds": seeds.tolist(), "config": cfg.__dict__, "runtime_s": time.time() - t0}
json.dump(out, open("../results/trackA_regimes.json", "w"), indent=2)

print("\n=== Track A: paired ΔMC vs uniform across regimes ===")
for gb in gammabars:
    base = mc[gb]["A0_uniform"]
    print(f"\nγ̄={gb}: uniform MC={base.mean():.2f}")
    for m in profile_names:
        if m == "A0_uniform":
            continue
        d = mc[gb][m] - base
        se = d.std() / np.sqrt(len(d))
        sig = "  <-- signif" if abs(d.mean()) > 2 * se else ""
        print(f"  {m:16s} ΔMC={d.mean():+.2f} ± {d.std():.2f}{sig}")
