"""Track B (jump-operator engineering) on STM, across dissipation-strength budgets.

Compares jump families B0 local / B1 dephasing / B2 thermal / B3 collective /
B4 exchange at the validated CD optimum (h=0.5, dt=0.5).  Within each realization
every family is normalised to the SAME total dissipative strength
``Σ_k rate_k Tr(L_k^dag L_k)`` as B0 local loss at rate ``gamma`` (so gains are not
"more dissipation"); families are paired (same J + input sequence).

Following the Track-A lesson, we sweep the strength budget gamma ∈ {0.3, 1, 3}
because interesting effects appeared only when memory was scarce.
"""
import _paths  # noqa: F401
import json
import time
import numpy as np

from qrc import reservoirs as res, readout, tasks
from experiments_baseline import make_config, evaluate_delays
from experiments_track_b import build_jump_families, make_reservoir_with_jumps

cfg = make_config("validation", h=0.5, dt=0.5, quantize=48,
                  n_realizations=4, washout=150, train_len=450, test_len=300)
gammas = [0.3, 1.0, 3.0]
delays = list(range(1, 16))
families = ["B0_local", "B1_dephasing", "B2_thermal", "B3_collective", "B4_exchange"]
obs = readout.pauli_observables(cfg.n_qubits, max_weight=cfg.max_weight)

rng_master = np.random.default_rng(cfg.seed + 400)
seeds = rng_master.integers(0, 2 ** 31 - 1, size=cfg.n_realizations)

# cap[gamma][family] -> (n_real, n_delays)
cap = {g: {m: np.zeros((cfg.n_realizations, len(delays))) for m in families}
       for g in gammas}
t0 = time.time()
for r_i, sd in enumerate(seeds):
    rng = np.random.default_rng(int(sd))
    J = res.random_couplings(cfg.n_qubits, cfg.J_s, rng)
    inputs = tasks.stm_inputs(cfg.total_len, rng)
    post = inputs[cfg.washout:]
    for g in gammas:
        fams = build_jump_families(J, cfg.n_qubits, g, match_strength=True)
        for m in families:
            reservoir = make_reservoir_with_jumps(J, cfg, fams[m])
            X = reservoir.run(inputs, obs, washout=cfg.washout, n_virtual=1)
            caps = evaluate_delays(X, post, tasks.delayed_target, delays, cfg, "capacity")
            cap[g][m][r_i] = [caps[d] for d in delays]
    print(f"  realization {r_i+1}/{cfg.n_realizations} ({time.time()-t0:.0f}s)")

out = {"gammas": gammas, "families": families, "delays": delays,
       "cap": {str(g): {m: cap[g][m].tolist() for m in families} for g in gammas},
       "seeds": seeds.tolist(), "config": cfg.__dict__, "runtime_s": time.time() - t0}
json.dump(out, open("../results/trackB_regimes.json", "w"), indent=2)

print("\n=== Track B: STM total memory capacity (paired ΔMC vs B0 local) ===")
for g in gammas:
    base = cap[g]["B0_local"].sum(axis=1)
    print(f"\nstrength budget γ={g}: B0 local MC={base.mean():.2f}")
    for m in families:
        if m == "B0_local":
            continue
        d = cap[g][m].sum(axis=1) - base
        se = d.std() / np.sqrt(len(d))
        sig = "  <-- signif" if abs(d.mean()) > 2 * se else ""
        print(f"  {m:16s} ΔMC={d.mean():+.2f} ± {d.std():.2f}{sig}")
