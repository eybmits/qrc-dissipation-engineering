"""Master comparison: every dissipation method vs the paper's original method.

Reference method = the paper's continuous-dissipation model with **uniform local
loss** (`CD_paper`, == A0 == B0).  Every other method is a jump-operator or rate
variant, normalised to the SAME total dissipative strength (so differences are
not "more dissipation"), paired per realization (same J + inputs), identical
45-feature readout.  We evaluate all four tasks and, at the STM operating point,
the full diagnostic battery (Phase 4), incl. the previously un-swept effective
rank / condition number / trace-distance forgetting.

Closes the remaining gaps: B5 pair loss is included on every task, and the
diagnostics are tabulated across families.
"""
import _paths  # noqa: F401
import json
import time
import numpy as np

from qrc import reservoirs as res, readout, tasks
from qrc import dissipators as dsp
from qrc import diagnostics as diag
from experiments_baseline import make_config, evaluate_delays
from experiments_track_b import make_reservoir_with_jumps

GAMMA = 1.0
N_REAL = 4
DELAYS_STM = list(range(1, 16))
DELAYS_PAR = list(range(1, 8))
NARMA_ORDER = 10


def _loss(n, g):
    return [(res.sminus(i, n), float(g[i])) for i in range(n)]


def methods(J, n, gamma):
    """Jump-family builders, all matched to CD_paper total strength."""
    target = dsp.jump_strength(dsp.local_loss(n, gamma))
    rng = np.random.default_rng(int(abs(J).sum() * 1e6) % (2 ** 31))
    g_rand = dsp.loguniform_rates(n, gamma / 10, gamma * 10, rng, mean=gamma)
    g_cpl = dsp.coupling_rates(J, mean=gamma)
    g_inv = dsp.inverse_coupling_rates(J, mean=gamma)
    c_graph = np.sum(np.abs(J), axis=1) + 1e-3
    edges = dsp.graph_edges(J)
    loss = dsp.normalize_jump_strength(dsp.local_loss(n, 1.0), 0.4 * target)
    ex = dsp.normalize_jump_strength(dsp.exchange(n, 1.0, edges), 0.6 * target)
    pair_edges = [(i, j) for i in range(n) for j in range(i + 1, n) if abs(J[i, j]) > 1e-9]
    return {
        "CD_paper (uniform local)": dsp.local_loss(n, gamma),
        "A1 heterogeneous rates": _loss(n, g_rand),
        "A2 coupling-structured": _loss(n, g_cpl),
        "A2 inverse-coupling": _loss(n, g_inv),
        "B1 dephasing": dsp.normalize_jump_strength(dsp.dephasing(n, gamma), target),
        "B2 thermal": dsp.normalize_jump_strength(
            dsp.thermal(n, gamma_down=gamma, gamma_up=0.3 * gamma), target),
        "B3 collective": dsp.normalize_jump_strength(dsp.collective_loss(n, gamma), target),
        "B3 collective (graph c)": dsp.normalize_jump_strength(
            dsp.collective_loss(n, gamma, c=c_graph), target),
        "B4 loss+exchange": loss + ex,
        "B5 pair loss": dsp.normalize_jump_strength(
            dsp.pair_loss(n, gamma, pair_edges), target),
    }


METHOD_NAMES = list(methods(np.ones((5, 5)) - np.eye(5), 5, 1.0))
ALL = ["FN (paper, unitary)"] + METHOD_NAMES


def stm_metric(X, post, cfg):
    caps = evaluate_delays(X, post, tasks.delayed_target, DELAYS_STM, cfg, "capacity")
    return sum(caps.values())


def narma_metric(X, post, cfg):
    tf = lambda s, n: tasks.narma_target(s, order=n, input_scale=0.2)
    return evaluate_delays(X, post, tf, [NARMA_ORDER], cfg, "nmse")[NARMA_ORDER]


def parity_metric(X, post, cfg):
    caps = evaluate_delays(X, post, tasks.parity_target, DELAYS_PAR, cfg, "capacity")
    return sum(caps.values())


def mg_mse(reservoir, J, cfg, obs, horizon=150, sample_every=3, seed=0):
    rng = np.random.default_rng(seed)
    n_train = cfg.washout + cfg.train_len
    series = tasks.mackey_glass_series(n_train + horizon + 5, tau=17,
                                       sample_every=sample_every, discard=500, rng=rng)
    series = tasks.rescale_unit(series, 0, 1); drive = series[:n_train]
    X = reservoir.run(drive, obs, washout=cfg.washout, n_virtual=1)
    post = drive[cfg.washout:]; y = np.empty(len(post)); y[:-1] = post[1:]; y[-1] = series[n_train]
    w = readout.train_readout(readout.add_bias(X)[:-1], y[:-1], ridge=cfg.ridge)
    rho = reservoir.initial_state()
    for s in drive:
        rho = reservoir.step(rho, float(s))
    preds = []
    for _ in range(horizon):
        feat = readout.add_bias(readout.features_from_states([rho], obs))[0]
        cur = float(np.clip(feat @ w, 0, 1)); preds.append(cur); rho = reservoir.step(rho, cur)
    truth = series[n_train:n_train + horizon]
    return float(np.mean((truth - np.array(preds)) ** 2))


def main():
    cfg_lin = make_config("validation", h=0.5, dt=0.5, quantize=48,
                          n_realizations=N_REAL, washout=150, train_len=450, test_len=300)
    cfg_nl = make_config("validation", h=0.5, dt=0.25, quantize=48,
                         n_realizations=N_REAL, washout=150, train_len=450, test_len=300)
    obs = readout.pauli_observables(cfg_lin.n_qubits, max_weight=cfg_lin.max_weight)
    n = cfg_lin.n_qubits
    seeds = np.random.default_rng(2026).integers(0, 2 ** 31 - 1, N_REAL)

    perf = {m: {t: np.zeros(N_REAL) for t in ["STM", "NARMA", "parity", "MG"]} for m in ALL}
    diags = {m: {k: [] for k in ["unitality", "gap", "t_mix", "separability",
                                 "eff_rank", "cond", "forget_steps"]} for m in METHOD_NAMES}
    t0 = time.time()
    for r_i, sd in enumerate(seeds):
        rng = np.random.default_rng(int(sd))
        J = res.random_couplings(n, cfg_lin.J_s, rng)
        stm_in = tasks.stm_inputs(cfg_lin.total_len, rng)
        nar_in = tasks.narma_inputs(cfg_nl.total_len, rng)
        par_in = tasks.parity_inputs(cfg_lin.total_len, rng)
        meth = methods(J, n, GAMMA)

        # FN reference (unitary) on each task
        fn_lin = res.FujiNakajimaReservoir(n, J, cfg_lin.h, cfg_lin.dt)
        fn_nl = res.FujiNakajimaReservoir(n, J, cfg_nl.h, cfg_nl.dt)
        perf["FN (paper, unitary)"]["STM"][r_i] = stm_metric(
            fn_lin.run(stm_in, obs, washout=cfg_lin.washout), stm_in[cfg_lin.washout:], cfg_lin)
        perf["FN (paper, unitary)"]["NARMA"][r_i] = narma_metric(
            fn_nl.run(nar_in, obs, washout=cfg_nl.washout), nar_in[cfg_nl.washout:], cfg_nl)
        perf["FN (paper, unitary)"]["parity"][r_i] = parity_metric(
            fn_lin.run(par_in, obs, washout=cfg_lin.washout, n_virtual=15),
            par_in[cfg_lin.washout:], cfg_lin)
        perf["FN (paper, unitary)"]["MG"][r_i] = mg_mse(fn_nl, J, cfg_nl, obs, seed=int(sd))

        for m, jumps in meth.items():
            r_lin = make_reservoir_with_jumps(J, cfg_lin, jumps)
            r_nl = make_reservoir_with_jumps(J, cfg_nl, jumps)
            X_stm = r_lin.run(stm_in, obs, washout=cfg_lin.washout)
            perf[m]["STM"][r_i] = stm_metric(X_stm, stm_in[cfg_lin.washout:], cfg_lin)
            perf[m]["NARMA"][r_i] = narma_metric(
                r_nl.run(nar_in, obs, washout=cfg_nl.washout), nar_in[cfg_nl.washout:], cfg_nl)
            r_par = make_reservoir_with_jumps(J, cfg_lin, jumps); r_par.cache_propagators = True
            perf[m]["parity"][r_i] = parity_metric(
                r_par.run(par_in, obs, washout=cfg_lin.washout, n_virtual=15),
                par_in[cfg_lin.washout:], cfg_lin)
            perf[m]["MG"][r_i] = mg_mse(r_nl, J, cfg_nl, obs, seed=int(sd))

            # diagnostics (STM operating point)
            L = r_lin.liouvillian(0.5)
            diags[m]["unitality"].append(diag.unitality_defect(jumps))
            diags[m]["gap"].append(diag.spectral_gap(L))
            diags[m]["t_mix"].append(diag.mixing_time(L))
            diags[m]["separability"].append(diag.stationary_separability(r_lin, [0.0, 1.0])[0, 1])
            diags[m]["eff_rank"].append(diag.effective_rank(X_stm))
            diags[m]["cond"].append(diag.condition_number(X_stm))
            # trace-distance forgetting: evolve two different initial states under
            # the same input stream; record the step where their distance has
            # decayed to 10% of the initial separation (the fading-memory time).
            rng2 = np.random.default_rng(int(sd) + 7)
            td = diag.trace_distance_decay(
                r_lin, rng2.uniform(0, 1, 60),
                r_lin.initial_state(), _perturbed_state(n))
            below = np.where(td < 0.1 * max(td[0], 1e-9))[0]
            diags[m]["forget_steps"].append(int(below[0]) if len(below) else 60)
        print(f"  realization {r_i+1}/{N_REAL} done ({time.time()-t0:.0f}s)")

    out = {"gamma": GAMMA, "methods": ALL, "diag_methods": METHOD_NAMES,
           "perf": {m: {t: perf[m][t].tolist() for t in perf[m]} for m in ALL},
           "diagnostics": {m: {k: list(map(float, diags[m][k])) for k in diags[m]}
                           for m in METHOD_NAMES},
           "seeds": seeds.tolist(), "runtime_s": time.time() - t0}
    json.dump(out, open("../results/master_comparison.json", "w"), indent=2)
    _print_tables(out)


def _perturbed_state(n):
    """A different valid initial density matrix (input qubit excited)."""
    from qrc.operators import input_state
    rho = input_state(0.9)
    for _ in range(n - 1):
        rho = np.kron(rho, input_state(0.1))
    return rho


def _print_tables(out):
    perf = out["perf"]
    ref = "CD_paper (uniform local)"
    print("\n=== PERFORMANCE vs paper method (CD uniform local loss) ===")
    print(f"{'method':28s} {'STM MC':>8s} {'NARMA':>8s} {'parity':>8s} {'MG MSE':>9s}")
    for m in out["methods"]:
        s = np.mean(perf[m]['STM']); na = np.mean(perf[m]['NARMA'])
        p = np.mean(perf[m]['parity']); mg = np.mean(perf[m]['MG'])
        print(f"{m:28s} {s:8.2f} {na:8.3f} {p:8.2f} {mg:9.2e}")
    print("\n=== DIAGNOSTICS (STM operating point) ===")
    d = out["diagnostics"]
    print(f"{'method':28s} {'unital':>7s} {'gap':>6s} {'t_mix':>6s} {'sep':>6s} "
          f"{'rank':>6s} {'cond':>8s} {'forget':>7s}")
    for m in out["diag_methods"]:
        f = lambda k: np.mean(d[m][k])
        print(f"{m:28s} {f('unitality'):7.2f} {f('gap'):6.3f} {f('t_mix'):6.2f} "
              f"{f('separability'):6.3f} {f('eff_rank'):6.1f} {f('cond'):8.1f} "
              f"{f('forget_steps'):7.1f}")


if __name__ == "__main__":
    main()
