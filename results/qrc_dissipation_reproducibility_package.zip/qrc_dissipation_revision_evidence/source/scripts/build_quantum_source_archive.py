#!/usr/bin/env python3
"""Build and verify the self-contained Quantum/arXiv manuscript source ZIP."""

from __future__ import annotations

import argparse
import hashlib
import re
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath


REPO_ROOT = Path(__file__).resolve().parents[1]
PAPER_ROOT = REPO_ROOT / "paper"
DEFAULT_OUTPUT = REPO_ROOT / "results" / "quantum_submission_source.zip"
ZIP_TIMESTAMP = (1980, 1, 1, 0, 0, 0)
FILE_MODE = 0o644

REQUIRED_FILES = (
    "dissipation_qrc.tex",
    "dissipation_qrc.bbl",
    "quantumarticle.cls",
    "quantum.bst",
    "references.bib",
    "sections/abstract.tex",
    "sections/background.tex",
    "sections/conclusion.tex",
    "sections/evaluation.tex",
    "sections/experimental-section.tex",
    "sections/introduction.tex",
    "sections/methodology.tex",
    "sections/related-work.tex",
)
EXPECTED_FIGURES = (
    "figures/fig_adaptive.pdf",
    "figures/fig_budget.pdf",
    "figures/fig_designspace.pdf",
    "figures/fig_map.pdf",
    "figures/fig_predict.pdf",
    "figures/fig_prospective.pdf",
    "figures/fig_scaling.pdf",
    "figures/fig_shotmap.pdf",
)
GENERATED_FILES = ("README.txt", "SHA256SUMS.txt")


class SourceArchiveError(RuntimeError):
    """Raised when a source package is incomplete or internally inconsistent."""


@dataclass(frozen=True)
class SourcePayload:
    name: str
    data: bytes


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_name(value: str) -> str:
    path = PurePosixPath(value)
    if (
        not path.parts
        or path.is_absolute()
        or ".." in path.parts
        or "\\" in value
        or "\x00" in value
        or ":" in path.parts[0]
    ):
        raise SourceArchiveError(f"unsafe archive path: {value}")
    return path.as_posix()


def _read_regular(path: Path, paper_root: Path) -> bytes:
    try:
        relative = path.relative_to(paper_root).as_posix()
    except ValueError as error:
        raise SourceArchiveError(f"source escapes paper directory: {path}") from error
    _safe_name(relative)
    if path.is_symlink():
        raise SourceArchiveError(f"symlinks are not allowed: {relative}")
    if not path.is_file():
        raise SourceArchiveError(f"missing source file: {relative}")
    return path.read_bytes()


def _read_tex_tree(
    path: Path,
    paper_root: Path,
    seen: set[Path] | None = None,
) -> str:
    seen = set() if seen is None else seen
    path = path.resolve()
    if path in seen:
        return ""
    seen.add(path)
    try:
        path.relative_to(paper_root.resolve())
    except ValueError as error:
        raise SourceArchiveError(f"TeX input escapes paper directory: {path}") from error
    source = path.read_text(encoding="utf-8")
    parts = [source]
    for input_name in re.findall(r"\\input\{([^}]+)\}", source):
        child = path.parent / input_name
        if child.suffix == "":
            child = child.with_suffix(".tex")
        if not child.is_file():
            raise SourceArchiveError(f"missing TeX input: {input_name}")
        parts.append(_read_tex_tree(child, paper_root, seen))
    return "\n".join(parts)


def _readme() -> bytes:
    return (
        "Quantum submission source package\n"
        "=================================\n\n"
        "Canonical source: dissipation_qrc.tex\n\n"
        "Build from this directory with:\n"
        "  latexmk -pdf -interaction=nonstopmode -halt-on-error "
        "dissipation_qrc.tex\n\n"
        "The package contains the generated bibliography, the bundled "
        "quantumarticle class and bibliography style, all section files, "
        "and exactly the eight vector figures used by the manuscript.\n"
    ).encode("utf-8")


def collect_payloads(paper_root: Path = PAPER_ROOT) -> list[SourcePayload]:
    paper_root = paper_root.resolve()
    main_tex = paper_root / "dissipation_qrc.tex"
    manuscript = _read_tex_tree(main_tex, paper_root)

    unresolved = re.search(
        r"\b(?:PENDING|PLACEHOLDER|TODO)\b|\?\?",
        manuscript,
        flags=re.IGNORECASE,
    )
    if unresolved:
        raise SourceArchiveError(
            f"manuscript contains unresolved token: {unresolved.group(0)!r}"
        )

    observed_figures = {
        _safe_name(name)
        for name in re.findall(
            r"\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}",
            manuscript,
        )
    }
    if observed_figures != set(EXPECTED_FIGURES):
        raise SourceArchiveError(
            "included figure set differs from the sealed eight-figure allowlist: "
            f"{sorted(observed_figures)}"
        )

    payloads = [
        SourcePayload(relative, _read_regular(paper_root / relative, paper_root))
        for relative in (*REQUIRED_FILES, *EXPECTED_FIGURES)
    ]
    payloads.append(SourcePayload("README.txt", _readme()))
    payloads.sort(key=lambda payload: payload.name)

    manifest = "".join(
        f"{sha256_bytes(payload.data)}  {payload.name}\n"
        for payload in payloads
    ).encode("utf-8")
    payloads.append(SourcePayload("SHA256SUMS.txt", manifest))
    payloads.sort(key=lambda payload: payload.name)
    return payloads


def _zip_info(name: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(_safe_name(name), date_time=ZIP_TIMESTAMP)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.create_system = 3
    info.external_attr = FILE_MODE << 16
    return info


def build_archive(
    output: Path,
    paper_root: Path = PAPER_ROOT,
) -> dict[str, object]:
    payloads = collect_payloads(paper_root)
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        prefix=f".{output.name}.",
        suffix=".tmp",
        dir=output.parent,
        delete=False,
    ) as handle:
        temporary = Path(handle.name)
    try:
        with zipfile.ZipFile(
            temporary,
            "w",
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=9,
        ) as bundle:
            for payload in payloads:
                bundle.writestr(_zip_info(payload.name), payload.data)
        temporary.replace(output)
    finally:
        temporary.unlink(missing_ok=True)
    verified = verify_archive(output)
    return {
        **verified,
        "path": str(output),
    }


def verify_archive(path: Path) -> dict[str, object]:
    path = path.resolve()
    try:
        with zipfile.ZipFile(path) as bundle:
            infos = bundle.infolist()
            names = [info.filename for info in infos]
            if len(names) != len(set(names)):
                raise SourceArchiveError("archive contains duplicate members")
            if names != sorted(names):
                raise SourceArchiveError("archive members are not sorted")
            for info in infos:
                _safe_name(info.filename)
                if info.is_dir():
                    raise SourceArchiveError(
                        f"archive contains a directory member: {info.filename}"
                    )
                unix_type = (info.external_attr >> 16) & 0o170000
                if unix_type not in (0, 0o100000):
                    raise SourceArchiveError(
                        f"archive contains a non-regular member: {info.filename}"
                    )
                if info.flag_bits & 0x1:
                    raise SourceArchiveError(
                        f"archive contains an encrypted member: {info.filename}"
                    )
            expected = set((*REQUIRED_FILES, *EXPECTED_FIGURES, *GENERATED_FILES))
            if set(names) != expected:
                raise SourceArchiveError(
                    "archive membership differs from the sealed allowlist"
                )
            members = {name: bundle.read(name) for name in names}
    except (OSError, zipfile.BadZipFile, KeyError) as error:
        raise SourceArchiveError(f"cannot read source archive: {path}") from error

    try:
        manifest_text = members["SHA256SUMS.txt"].decode("utf-8")
    except UnicodeDecodeError as error:
        raise SourceArchiveError("checksum manifest is not UTF-8") from error
    observed: dict[str, str] = {}
    for line in manifest_text.splitlines():
        match = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
        if not match:
            raise SourceArchiveError(f"malformed checksum line: {line!r}")
        digest, name = match.groups()
        name = _safe_name(name)
        if name in observed:
            raise SourceArchiveError(f"duplicate checksum entry: {name}")
        observed[name] = digest
    expected_manifest_names = set(members) - {"SHA256SUMS.txt"}
    if set(observed) != expected_manifest_names:
        raise SourceArchiveError("checksum manifest membership mismatch")
    for name, digest in observed.items():
        if sha256_bytes(members[name]) != digest:
            raise SourceArchiveError(f"checksum mismatch: {name}")

    return {
        "sha256": sha256_file(path),
        "file_count": len(members),
        "figure_count": len(EXPECTED_FIGURES),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    build = subparsers.add_parser("build")
    build.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    build.add_argument("--paper-root", type=Path, default=PAPER_ROOT)
    verify = subparsers.add_parser("verify")
    verify.add_argument("archive", type=Path)
    args = parser.parse_args()

    if args.command == "build":
        result = build_archive(args.output, args.paper_root)
    else:
        result = verify_archive(args.archive)
    for key, value in result.items():
        print(f"{key}: {value}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
