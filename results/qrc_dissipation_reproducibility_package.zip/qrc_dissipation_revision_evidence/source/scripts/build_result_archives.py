#!/usr/bin/env python3
"""Build deterministic, sidecar-free archives for the raw result bundles.

The archive format is deliberately simple: each tarball has one top-level
directory, contains only directories and regular files, and uses normalized tar
metadata.  Gzip timestamps are also fixed, so repeated builds from unchanged
inputs produce byte-identical output.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import os
import tarfile
import tempfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Iterable


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_RESULTS_DIR = ROOT / "results"

PROTOCOL_BUNDLES = (
    ("final_protocol", "final_protocol_results.tar.gz"),
    ("review_protocol", "review_protocol_results.tar.gz"),
)
GROUPED_ROOT = "grouped_measurement"
GROUPED_DATA_NAME = "phys_shots.json"
GROUPED_MANIFEST_NAME = "provenance.json"
GROUPED_ARCHIVE_NAME = "grouped_measurement_results.tar.gz"

NORMALIZED_MTIME = 0
NORMALIZED_UID = 0
NORMALIZED_GID = 0
DIRECTORY_MODE = 0o755
FILE_MODE = 0o644


@dataclass(frozen=True)
class ArchiveEntry:
    """One normalized archive member."""

    name: str
    data: bytes | None

    @property
    def is_directory(self) -> bool:
        return self.data is None


@dataclass(frozen=True)
class ArchiveSummary:
    """Validated output metadata printed after a successful build."""

    path: Path
    member_count: int
    file_count: int
    excluded_count: int
    sha256: str


def is_forbidden_sidecar(path: PurePosixPath) -> bool:
    """Return whether *path* is Apple metadata rather than scientific data."""
    return any(
        part == ".DS_Store" or part == "__MACOSX" or part.startswith("._")
        for part in path.parts
    )


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def normalized_tarinfo(entry: ArchiveEntry) -> tarfile.TarInfo:
    """Create fixed tar metadata for *entry*."""
    name = entry.name.rstrip("/") + "/" if entry.is_directory else entry.name
    info = tarfile.TarInfo(name)
    info.mtime = NORMALIZED_MTIME
    info.uid = NORMALIZED_UID
    info.gid = NORMALIZED_GID
    info.uname = ""
    info.gname = ""
    info.pax_headers = {}
    if entry.is_directory:
        info.type = tarfile.DIRTYPE
        info.mode = DIRECTORY_MODE
        info.size = 0
    else:
        info.type = tarfile.REGTYPE
        info.mode = FILE_MODE
        info.size = len(entry.data)
    return info


def collect_tree(source: Path, archive_root: str) -> tuple[list[ArchiveEntry], int]:
    """Collect a source directory in sorted order, filtering macOS sidecars."""
    if not source.is_dir():
        raise FileNotFoundError(f"required result directory is missing: {source}")

    entries = [ArchiveEntry(archive_root, None)]
    excluded = 0
    for path in sorted(source.rglob("*"), key=lambda item: item.as_posix()):
        relative = PurePosixPath(path.relative_to(source).as_posix())
        if is_forbidden_sidecar(relative):
            excluded += 1
            continue
        member = str(PurePosixPath(archive_root) / relative)
        if path.is_symlink():
            raise ValueError(f"symlinks are not permitted in result archives: {path}")
        if path.is_dir():
            entries.append(ArchiveEntry(member, None))
        elif path.is_file():
            entries.append(ArchiveEntry(member, path.read_bytes()))
        else:
            raise ValueError(f"unsupported filesystem entry in result archive: {path}")
    return entries, excluded


def write_archive(path: Path, entries: Iterable[ArchiveEntry]) -> None:
    """Atomically write a deterministic gzip-compressed POSIX tar archive."""
    entries = list(entries)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb",
            prefix=f".{path.name}.",
            suffix=".tmp",
            dir=path.parent,
            delete=False,
        ) as raw:
            temporary = Path(raw.name)
            with gzip.GzipFile(
                filename="",
                mode="wb",
                fileobj=raw,
                compresslevel=9,
                mtime=NORMALIZED_MTIME,
            ) as compressed:
                with tarfile.open(
                    fileobj=compressed,
                    mode="w",
                    format=tarfile.PAX_FORMAT,
                ) as bundle:
                    for entry in entries:
                        info = normalized_tarinfo(entry)
                        payload = None if entry.is_directory else io.BytesIO(entry.data)
                        bundle.addfile(info, payload)
        os.replace(temporary, path)
        temporary = None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def validate_archive(
    path: Path,
    expected_entries: Iterable[ArchiveEntry],
    excluded_count: int,
) -> ArchiveSummary:
    """Verify exact membership, normalized metadata, and absence of sidecars."""
    expected_entries = list(expected_entries)
    # ``tarfile`` canonicalizes directory member names by removing the trailing
    # slash when reading, even though command-line tar displays that slash.
    expected_names = [entry.name.rstrip("/") for entry in expected_entries]
    expected_by_name = dict(zip(expected_names, expected_entries, strict=True))

    with tarfile.open(path, mode="r:gz") as bundle:
        members = bundle.getmembers()
        names = [member.name for member in members]
        if len(names) != len(set(names)):
            raise RuntimeError(f"archive contains duplicate members: {path}")
        if names != expected_names:
            missing = sorted(set(expected_names) - set(names))
            unexpected = sorted(set(names) - set(expected_names))
            raise RuntimeError(
                f"archive membership/order mismatch for {path}: "
                f"missing={missing}, unexpected={unexpected}"
            )

        for member in members:
            pure_name = PurePosixPath(member.name)
            if pure_name.is_absolute() or ".." in pure_name.parts:
                raise RuntimeError(f"unsafe member path in {path}: {member.name}")
            if is_forbidden_sidecar(pure_name):
                raise RuntimeError(f"forbidden sidecar in {path}: {member.name}")
            expected = expected_by_name[member.name]
            expected_mode = DIRECTORY_MODE if expected.is_directory else FILE_MODE
            if (
                member.mtime != NORMALIZED_MTIME
                or member.uid != NORMALIZED_UID
                or member.gid != NORMALIZED_GID
                or member.uname != ""
                or member.gname != ""
                or member.mode != expected_mode
            ):
                raise RuntimeError(
                    f"non-normalized metadata in {path}: {member.name}"
                )
            if member.isdir() != expected.is_directory:
                raise RuntimeError(f"member type mismatch in {path}: {member.name}")
            if not member.isdir() and not member.isfile():
                raise RuntimeError(f"unsupported member type in {path}: {member.name}")
            if not expected.is_directory:
                extracted = bundle.extractfile(member)
                if extracted is None or extracted.read() != expected.data:
                    raise RuntimeError(f"content mismatch in {path}: {member.name}")

    return ArchiveSummary(
        path=path,
        member_count=len(expected_names),
        file_count=sum(not entry.is_directory for entry in expected_entries),
        excluded_count=excluded_count,
        sha256=sha256_file(path),
    )


def build_protocol_archive(
    source: Path,
    output: Path,
    archive_root: str,
) -> ArchiveSummary:
    entries, excluded = collect_tree(source, archive_root)
    write_archive(output, entries)
    return validate_archive(output, entries, excluded)


def build_grouped_archive(source: Path, output: Path) -> ArchiveSummary:
    """Import grouped-measurement JSON with a deterministic provenance record."""
    if not source.is_file():
        raise FileNotFoundError(f"required grouped-measurement JSON is missing: {source}")
    if source.is_symlink():
        raise ValueError(f"grouped-measurement source may not be a symlink: {source}")

    raw = source.read_bytes()
    try:
        json.loads(raw)
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError(f"grouped-measurement source is not valid JSON: {source}") from error

    source_digest = sha256_bytes(raw)
    manifest = {
        "archive_member": f"{GROUPED_ROOT}/{GROUPED_DATA_NAME}",
        "archive_member_sha256": source_digest,
        "schema_version": 1,
        "source_path": source.name,
        "source_path_note": (
            "Recovery-time filename; the machine-local absolute path is "
            "intentionally omitted from the portable archive."
        ),
        "source_sha256": source_digest,
    }
    manifest_bytes = (
        json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    ).encode("utf-8")
    entries = [
        ArchiveEntry(GROUPED_ROOT, None),
        ArchiveEntry(f"{GROUPED_ROOT}/{GROUPED_DATA_NAME}", raw),
        ArchiveEntry(f"{GROUPED_ROOT}/{GROUPED_MANIFEST_NAME}", manifest_bytes),
    ]
    write_archive(output, entries)
    return validate_archive(output, entries, excluded_count=0)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Build deterministic final-protocol, review-protocol, and grouped-"
            "measurement result archives."
        )
    )
    parser.add_argument(
        "--grouped-source",
        required=True,
        type=Path,
        help="recovered phys_shots.json to import (required)",
    )
    parser.add_argument(
        "--results-dir",
        type=Path,
        default=DEFAULT_RESULTS_DIR,
        help=f"source results directory (default: {DEFAULT_RESULTS_DIR})",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="archive destination (default: --results-dir)",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    results_dir = args.results_dir.resolve()
    output_dir = (
        args.output_dir.resolve() if args.output_dir is not None else results_dir
    )

    summaries: list[ArchiveSummary] = []
    for directory_name, archive_name in PROTOCOL_BUNDLES:
        summaries.append(
            build_protocol_archive(
                results_dir / directory_name,
                output_dir / archive_name,
                directory_name,
            )
        )
    summaries.append(
        build_grouped_archive(
            args.grouped_source,
            output_dir / GROUPED_ARCHIVE_NAME,
        )
    )

    for summary in summaries:
        print(
            f"OK {summary.path}: members={summary.member_count} "
            f"files={summary.file_count} excluded={summary.excluded_count} "
            f"sha256={summary.sha256}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
