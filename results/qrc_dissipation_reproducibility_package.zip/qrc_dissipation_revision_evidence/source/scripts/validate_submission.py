#!/usr/bin/env python3
"""Validate the canonical Quantum submission artifact.

This script intentionally uses only the Python standard library and Poppler
command-line tools so it can run in a clean checkout before submission.
"""

from __future__ import annotations

import re
import shutil
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PAPER = ROOT / "paper"
TEX = PAPER / "dissipation_qrc.tex"
PDF = PAPER / "dissipation_qrc.pdf"
LOG = PAPER / "dissipation_qrc.log"
FIGURES = PAPER / "figures"


def read_tex_tree(path: Path, seen: set[Path] | None = None) -> str:
    r"""Return a manuscript source closure, following local ``\input`` files."""
    seen = set() if seen is None else seen
    path = path.resolve()
    if path in seen:
        return ""
    seen.add(path)
    source = path.read_text(encoding="utf-8")
    parts = [source]
    for input_name in re.findall(r"\\input\{([^}]+)\}", source):
        child = (path.parent / input_name)
        if child.suffix == "":
            child = child.with_suffix(".tex")
        if child.is_file():
            parts.append(read_tex_tree(child, seen))
    return "\n".join(parts)


def run(*args: str) -> str:
    completed = subprocess.run(
        args,
        cwd=PAPER,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    if completed.returncode:
        raise RuntimeError(f"{' '.join(args)} failed:\n{completed.stdout}")
    return completed.stdout


def check(condition: bool, message: str, failures: list[str]) -> None:
    if not condition:
        failures.append(message)


def main() -> int:
    failures: list[str] = []
    warnings: list[str] = []

    for tool in ("pdfinfo", "pdffonts", "pdftotext"):
        check(shutil.which(tool) is not None, f"missing required tool: {tool}", failures)

    check(TEX.is_file(), f"missing manuscript source: {TEX}", failures)
    check(PDF.is_file(), f"missing manuscript PDF: {PDF}", failures)
    check(LOG.is_file(), f"missing LaTeX log: {LOG}", failures)
    if failures:
        for item in failures:
            print(f"FAIL: {item}")
        return 1

    tex = TEX.read_text(encoding="utf-8")
    manuscript_source = read_tex_tree(TEX)
    log = LOG.read_text(encoding="utf-8", errors="replace")
    pdf_text = run("pdftotext", "-layout", str(PDF), "-")
    pdfinfo = run("pdfinfo", str(PDF))

    page_match = re.search(r"^Pages:\s+(\d+)", pdfinfo, re.MULTILINE)
    pages = int(page_match.group(1)) if page_match else 0
    check(8 <= pages <= 30, f"unexpected manuscript length: {pages} pages", failures)

    hard_log_patterns = {
        "undefined references": r"(undefined references|Reference .* undefined)",
        "undefined citations": r"Citation .* undefined",
        "overfull boxes": r"Overfull \\[hv]box",
        "stuck floats": r"A float is stuck",
        "multiply-defined labels": r"multiply defined",
        "fatal LaTeX errors": r"(^! |Emergency stop|Fatal error)",
    }
    for label, pattern in hard_log_patterns.items():
        check(
            re.search(pattern, log, flags=re.MULTILINE) is None,
            f"LaTeX log contains {label}",
            failures,
        )

    forbidden_source_patterns = {
        "submission TODO": r"TODO before submission",
        "placeholder authorship": r"placeholder",
        "future DOI promise": r"DOI-stamped snapshot will accompany",
        "unstable date command": r"\\date\{\\today\}",
    }
    for label, pattern in forbidden_source_patterns.items():
        check(
            re.search(pattern, manuscript_source, flags=re.IGNORECASE) is None,
            f"source contains {label}",
            failures,
        )

    for token in ("TODO", "PLACEHOLDER", "??"):
        check(token not in pdf_text, f"PDF contains unresolved token {token!r}", failures)

    figure_paths = sorted(
        set(
            re.findall(
                r"\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}",
                manuscript_source,
            )
        )
    )
    check(bool(figure_paths), "manuscript includes no figures", failures)
    for figure in figure_paths:
        path = PAPER / figure
        check(path.is_file(), f"missing included figure: {figure}", failures)

    pdf_targets = [PDF] + sorted(FIGURES.glob("*.pdf"))
    for target in pdf_targets:
        font_table = run("pdffonts", str(target))
        rows = [line.split() for line in font_table.splitlines()[2:] if line.strip()]
        check(rows, f"no fonts detected in {target.relative_to(ROOT)}", failures)
        for row in rows:
            descriptor = " ".join(row)
            check("Type 3" not in descriptor, f"Type 3 font in {target.relative_to(ROOT)}", failures)
            if len(row) >= 6:
                check(
                    row[4].lower() == "yes",
                    f"unembedded font in {target.relative_to(ROOT)}: {row[0]}",
                    failures,
                )

    required_sections = (
        "abstract.tex",
        "introduction.tex",
        "background.tex",
        "related-work.tex",
        "methodology.tex",
        "experimental-section.tex",
        "evaluation.tex",
        "conclusion.tex",
    )
    section_dir = PAPER / "sections"
    for name in required_sections:
        check((section_dir / name).is_file(), f"missing section source: paper/sections/{name}", failures)

    if "Author contributions" not in pdf_text:
        failures.append("PDF lacks an author-contributions statement")
    if re.search(r"Data\s+and\s+code", pdf_text) is None:
        failures.append("PDF lacks a data-and-code statement")
    if len(re.findall(r"\\bibitem", tex)) < 15 and "\\bibliography{" not in tex:
        warnings.append("bibliography contains fewer than 15 manual entries")
    if re.search(r"Underfull \\[hv]box \(badness 10000\)", log):
        warnings.append("LaTeX log contains maximally underfull boxes")

    for item in warnings:
        print(f"WARN: {item}")
    for item in failures:
        print(f"FAIL: {item}")

    if failures:
        print(f"\nSubmission validation failed: {len(failures)} failure(s).")
        return 1

    print(
        f"Submission validation passed: {pages} pages, "
        f"{len(figure_paths)} included figures, no Type 3 fonts or hard LaTeX defects."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
