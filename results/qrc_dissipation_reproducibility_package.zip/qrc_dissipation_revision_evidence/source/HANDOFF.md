# Handoff: Quantum submission

This is the continuation guide for the canonical manuscript

> *Dissipator structure shapes what a quantum reservoir remembers*

Read this file, [`README.md`](README.md), and
[`paper/SUBMISSION.md`](paper/SUBMISSION.md) before changing the paper or its
evidence.

## Current state

The rejection-level coauthor revision entered final repository and manuscript
QA on 26 July 2026. It accepts and repairs the four
principal criticisms of the fixed-Frobenius comparison, gap diagnostic,
finite-size framing, and measurement headline. The pre-revision `main`
checkout was left untouched; verify the live branch and working tree with
`git status -sb` before integrating the revision. The canonical source is
[`paper/dissipation_qrc.tex`](paper/dissipation_qrc.tex), using the bundled
`quantumarticle` class.

The prospective activity-matching audit, manuscript/figure QA, and local
release-package QA are complete. The evidence-producing scientific revision
remains sealed at commit `0e12030f0d8e3b73f234e98e8e4a263f05b5c1f4`; the
subsequent manuscript pass changes presentation and framing, not the recorded
results. The canonical
[`paper/dissipation_qrc.pdf`](paper/dissipation_qrc.pdf) is 19 pages (SHA-256
`e3b084c05ae96e7c39737e86e11253e5fc3b340bf8c35484bd0798ecb70591e8`);
all pages were visually inspected, all fonts are embedded, and the log has no
overfull box or undefined reference/citation. The allowlisted source ZIP and
strict evidence ZIP both verify; each was fresh-extracted, and the evidence
archive alone reconstructed a runnable tree that passed the full tests,
regenerated all eight figures, and rebuilt the manuscript. The remaining
submission gates are human attestations, public visibility and remote
synchronization/CI, and external upload/archive checks listed in
[`paper/SUBMISSION.md`](paper/SUBMISSION.md); repository automation cannot
complete those on the authors' behalf.

The fixed-Frobenius map, all-six scalar-strength study, corrected parity
control, dephasing contraction proof, equal-nominal-state-preparation
measurement study, and terminal activity-matching feasibility audit are
sealed. Current control seals:

> **FINAL-SEAL — prospective activity-matching feasibility: COMPLETE
> (26 July 2026).** The task-blind v3 pilot completed 160/160 rows, passed all
> monotonicity checks, and froze five activity targets
> (`0.336169420`, `0.413057367`, `0.507530959`, `0.623612348`,
> `0.766243623`) before fresh calibration. All 240 fresh calibration cells
> completed: 236 matched within the 0.5% rule and four local cells were
> unreachable; all 120 collective cells matched. The mandatory freeze command
> rejected the result with `fresh calibration cannot be frozen: 4 calibration
> cells censored`. No frozen-calibration artifact, STM score, or aggregate
> exists, so no activity-matched superiority or Pareto claim is permitted. The
> precommitted recovery rule forbids another branch extension or target
> adjustment. Pilot-manifest SHA-256:
> `2ed21080536a1081d96d45a809582f08a000a0d716de493171ee66107601f79f`;
> frozen-target SHA-256:
> `0586458a449d642c6fee83f7640b111172bee9cc664240291911578c6928840d`;
> task-manifest SHA-256:
> `d5effd1bc8bb4ba6b120818f94862c18dbd185784497f4bfff099b9e54eac76b`;
> embedded task-protocol SHA-256:
> `201a1da30be8b321840a69cb1f1f050c1629497208c81cfb77280a9ddb5a1f76`;
> frozen-driver SHA-256:
> `d043d5d6327857336b02b3f85e6fcda59e88be986fc81b9046f3f61147fea3c4`.

> **HISTORICAL SENSITIVITY — driven-ensemble jump activity: COMPLETE
> (25 July 2026).**
> Coverage is 224/224 jobs: seven fixed-Frobenius designs on all 32 sealed
> primary STM test trajectories. The expected jump rate is integrated inside
> each of the 400 continuously evolved held-out input intervals. Uniform-local
> mean activity is `1.481811256`; collective mean activity is `1.199200757`,
> for a ratio of means `0.809280`. The paired collective-minus-local
> difference is `-0.282610499`, with descriptive 95% \(t\)-interval
> `[-0.330512458, -0.234708540]`; collective is lower in 31/32 instances.
> This is a descriptive check performed after task scoring, not an
> activity-matched performance experiment or a paper-facing headline. Maximum
> Frobenius-strength error is `3.553e-16`,
> maximum trace error is `1.870e-13`, and maximum imaginary integration
> residue is `4.319e-16`. Protocol-file SHA-256:
> `22d8562792059285d23751864e8900fa66f374e92ffa5ca6aa869fd81b6e3804`;
> aggregate-file SHA-256:
> `4d3f2f91650f2e662a952029cbb9f8353cede3bf5a4072d0db6c9ab59207cb2f`;
> embedded protocol SHA-256:
> `769584ad42bf8be8dbb11a2530ef99a27280a7dc7ed9bbd542ff6d14400a4d3a`;
> source-environment SHA-256:
> `c23ddadf77f8c5aa86c812647b9cb615ea9cf6d266296df1d5118a06e3f468d1`.

> **FINAL-SEAL — seven-design readout-regularization control: COMPLETE
> (24 July 2026).** Coverage is 224/224 jobs. Design-specific
> validation-selected ridge coefficients preserve the seven-design mean
> ordering for both STM and NARMA-10. Collective versus local is
> `+3.58403454` STM capacity (`[3.37572717, 3.79234192]`, 32/32 wins) and
> lowers NARMA-10 NMSE by `0.08469767` (`[0.06992060, 0.09947474]`, 32/32
> wins). The simultaneously recomputed fixed-\(10^{-8}\) branch reproduces all
> 384 non-dephasing-design task--seed scores to a maximum STM drift of
> `1.46e-13` and zero NARMA drift. This sensitivity control was performed after
> task scoring and reuses the reported primary test blocks. Aggregate file SHA-256:
> `436dba4c844c0d1eb1593f29e68a128ddafd95c316377bea1b3d43036ed95d29`;
> protocol-file SHA-256:
> `2ffcdfecb20d6e82058d3af01e1a80e2e4384a7366810d629a047228d7d6d5b5`;
> embedded protocol SHA-256:
> `d72ec65e561647f612c817e41735ec18840f2301ab136e72b2b8d3e5ecc517a3`.

> **FINAL-SEAL — sampled collective-loss stationary-mode diagnostic: COMPLETE
> (24 July 2026).** All 210 fixed-input generators (10 reservoirs by 21
> equally spaced inputs) have exactly one numerical stationary mode in the
> full 1024-eigenvalue spectrum. The smallest nonzero decay gap is
> `0.0502596919`; maximum positive-real-part leakage is `3.22e-14`, and the
> maximum dense residual is `7.33e-13`. Six sparse cross-checks agree with the
> dense spectra to `3.30e-9`. This is a sampled fixed-input diagnostic, not a
> continuum or arbitrary-switching theorem. Aggregate file SHA-256:
> `95e1c2856242aed80a385be9e0da6267b3b483540a3815f15e723a7ef876f5dd`;
> raw-spectrum file SHA-256:
> `d9c9db2d9a061d65f2c80019915efe4c31cfe280a7536b7ebfd90bebc16d124b`;
> embedded protocol SHA-256:
> `d7d1bff24b9c545eb97428ffbd55fb924aeabff1496d63c3e95ef072b59f8311`.

> **FINAL-SEAL — nested local/collective control: COMPLETE (24 July 2026).**
> Coverage is 704/704 screen (512 reused and 192 new), 204/204 selection
> (168 reused and 36 new), and 48/48 fresh-test checkpoints; the three seed
> pools are disjoint and no selected ridge has an unresolved upper boundary.
> The common 176-configuration screen selects collective strength multiplier
> \(16\), whose 12-reservoir selection mean (`17.83293355`) is a strict local
> maximum between multipliers \(8\) (`16.89966364`) and \(32\)
> (`16.27351197`). Collective scores
> `17.6813166367 ± 0.1378827974` versus local
> `13.7358254137 ± 0.1371195999`; paired gain `3.9454912230` (28.724%),
> 95% interval `[3.5227887334, 4.3681937126]`, 24/24 wins. Aggregate file
> SHA-256:
> `9fcf437b2c29ea9a6c5b9b785c8ae25f2c5908f5b3a2229349e46ba1af44db68`;
> embedded protocol SHA-256:
> `1696169ac2b11c3bc832a562c1c0745a943ac1de555b5b7dab2e6f7d48275357`;
> frozen-selection SHA-256:
> `35406b3840f0abdb778e9d3c011eedb24e1775ae964a8ccb175667b675a23313`;
> deterministic payload SHA-256:
> `1d3d44a1ae6c036c920f79dfff2797d9431550f3c9575ad21cfb169fcc47e841`.
> The two-seed prescreen remains a limitation; its descriptive stability audit
> places the frozen local configuration first for both screen seeds and the
> frozen collective configuration second and third, with full-rank Spearman
> correlations `0.955` and `0.953`, respectively.

> **FINAL-SEAL — prospective control: COMPLETE (24 July 2026).** Coverage is
> 288/288 task checkpoints: 24 fresh seeds at each of six interpolation points
> for both \(N=4\) and \(N=5\), with zero overlap with the 20-seed frozen
> diagnostic ensemble and no unresolved upper ridge boundary. The frozen
> diagnostic selects \(\alpha=0.8\) at both sizes. It beats local loss by
> `1.7806439878` (`[1.5547503454, 2.0065376303]`, 24/24 wins) at \(N=4\)
> and `2.5801773539` (`[2.3563729811, 2.8039817267]`, 24/24 wins) at
> \(N=5\); the complete six-point gap and fresh-mean rankings have
> \(\rho=1\) at both sizes (exact 720-permutation \(p=0.00277778\)).
> Result SHA-256:
> `0aa3439886a994e8fa8dfd12f5334f4ce7e00e0d7db814fb8265752ed4c2164b`;
> embedded protocol SHA-256:
> `2d2464129903aff48bd662369b91a6af64620db40e1a6adb269f52a1390d98b9`;
> manifest SHA-256:
> `d9627586d14d57e1ed2da56e78371f058585999cd9ccb55d35d5d6bdd4d11e69`;
> frozen-diagnostic SHA-256:
> `26127f69498505dcc8cbeb29f59dd05073d8b7013ce49aba47bdc551e7af190c`;
> fresh-stage helper and frozen driver SHA-256:
> `e444a578a9830c90f4715fffd8f6313b60c5389c6a0af4870a40bd23f68cc439`
> and
> `723a57867e6901ac852a058c2288572ec7222fe9797f09bc57dfb86d04ce6d53`.

> **FINAL-SEAL — normalized scaling: COMPLETE (24 July 2026).** The aggregate
> is complete at 80/80 checkpoints with zero missing rows, eight paired seeds at
> every size, no unresolved upper ridge boundary, and all invariant audits
> passed. Aggregate file SHA-256:
> `2329c919a0488dcddb9a2282227e436d57794e605572b7979433a77fb177e64f`;
> embedded protocol SHA-256:
> `d718a49b1a57e0e2f170a62b93da053a8be87a19cc6f854284bfbabe02a615fd`;
> protocol-file SHA-256:
> `2d991207d35c24c9c308d21bdaa4fb87b89d21b7d811edad9f7f3ad6e97b98b8`.

> **FINAL-SEAL — critique-response inference: COMPLETE (24 July 2026).**
> The deterministic inference layer uses 50,000 paired reservoir-cluster
> bootstrap draws (seed `20260724`) for the six-design strength sensitivity,
> 210 simultaneous finite-budget measurement contrasts, and 10 simultaneous
> family-profile contrasts. Collective-minus-competitor bootstrap lower
> endpoints are `0.826`, `0.927`, `1.300`, `1.361`, and `1.412`; first
> simultaneous collective-over-local measurement points are `184320`
> (grouped) and `2949120` (independent); learned collective minus learned local
> is `0.662264`, simultaneous interval `[0.032825, 1.291704]`, 18/24 wins.
> Scientific-source commit:
> `492ef9350e7d72a3a73cf2756d33e4c236464d5d`.

Do not submit or freeze checksums unless every final-seal line is `COMPLETE`.

## Scientific story and claim boundary

Sannia *et al.* established that uniform local loss can be a resource for
quantum reservoir computing and optimized its scalar rate. This work is the
natural next step: it engineers the jump-operator structure itself, evaluates
both independently selected and fixed-Frobenius comparisons, and treats the
spatial damping profile as a second design axis.

The paper supports the following claims:

- bounded, independently selected local/collective comparisons retain 29.6%
  and 28.7% collective STM gains on disjoint test ensembles without imposing
  cross-design strength equality;
- dissipator structure materially changes computation at fixed Frobenius
  normalization, and collective loss is a strong memory specialist in the
  tested ensembles;
- within the one-body lowering sector,
  \(\mathcal B=2^{N-1}\operatorname{Tr}\Gamma\), so the central
  local--collective comparison fixes the total rate weight in the one-body
  decay matrix, but it does not fix dissipated power, heat, entropy production,
  trajectory activity, or hardware cost;
- the prospective operational comparison terminates before task scoring:
  236/240 fresh activity calibrations match and four local upper-target cells
  are unreachable. It therefore supplies neither an activity-matched STM
  effect nor a Pareto curve;
- the older driven-trajectory replay is retained only as historical,
  descriptive sensitivity evidence and is not a substitute for matching;
- the result survives design-specific scalar-strength selection within the
  declared grids in a selection-aware cluster-bootstrap sensitivity analysis,
  while close-design rankings depend on the resource-matching convention;
- no tested design is best on every task;
- for the driven local-dephasing model, a family-specific proof gives uniform
  contraction of the traceless state deviation and absolute Pauli signals over
  the continuous input interval;
- the six-design midpoint-gap pattern was measured after scoring, while a rule
  chosen before task scoring is rank-consistent only within the nearly monotone
  local-to-collective interpolation at \(N=4,5\);
- collective remains ahead at each tested size from \(N=4\) to \(8\) under two
  fixed-strength finite-size protocols; the observed rise is neither
  size-optimized, mechanistically explained, nor asymptotic;
- finite measurement budgets can reorder the preferred design even when
  nominal state preparations and readout regularization are controlled;
  grouping's earlier resolution is consistent with generic 15-feature sample
  reuse rather than a dissipator-specific effect; and
- learning a static damping profile is a useful but partly overlapping design
  lever.

Do **not** claim a globally optimal dissipator, a universal theorem for all
unital channels, a universal or out-of-family spectral-gap selector, a
hardware-independent cost advantage, a monotonic size-growth law, an
asymptotic size-scaling law, or a dissipator-specific 16-fold sampling
advantage. The fixed quantity
\(\sum_k\operatorname{Tr}(L_k^\dagger L_k)\) is a controlled Frobenius
normalization, not a platform-level resource measure. The Kossakowski identity
is scoped to one-body lowering jumps and does not supply one common physical
resource across all seven operator sectors. Unreached operational targets are
censored failures, not exact matches; under the frozen v3 gate, even one censor
forbids task scoring. The bounded local/collective search excludes learned
profiles and does not establish global equal-footing optimization. The
measurement result does not estimate a continuous resource threshold, and
mean-winner labels are descriptive unless the winner is simultaneously above
every competitor. The prospective interpolation is an internal frozen test
within a predefined monotone local-to-collective family, not an external
preregistration or out-of-family validation; its spectral diagnostics are
evaluated only at the representative midpoint \(s=0.5\).

## Canonical evidence

Current paper-facing evidence is deliberately separated from older exploratory
results:

| Question | Canonical artifact |
|---|---|
| Four-task map, diagnostics, scaling baseline, profiles | `results/final_protocol_results.tar.gz` |
| Forecasting, length, zero-jump, and robustness controls | `results/review_protocol_results.tar.gz` |
| Target-only forecast baseline audit | `results/forecast_baseline_audit/aggregate.json`, `reports/forecast_baseline_audit.md` |
| Six-channel tuning, bracketed nested control, prescreen audit, fresh interpolation | `results/revision_tuning/` |
| Prospective activity-matching feasibility failure | `results/activity_matched_response/`, `reports/activity_matched_response_report.md` |
| Development, failed-v2, and frozen recovery record | `reports/activity_matched_response_development_audit.md`, `reports/activity_matched_response_v2_failure_audit.md`, `reports/activity_matched_response_v2_recovery_plan.md` |
| Historical driven test-trajectory jump-activity sensitivity | `results/primary_driven_activity/`, `reports/primary_driven_activity_report.md` |
| Seven-design readout-regularization sensitivity | `results/revision_primary_regularization/`, `reports/revision_primary_regularization_report.md` |
| Sampled collective-loss stationary-mode diagnostic | `results/collective_loss_full_input_diagnostic/`, `reports/collective_loss_full_input_diagnostic.md` |
| Corrected parity and reference rows | `results/revision_parity_control/` |
| Equal-nominal-state-preparation independent and grouped measurements | `results/measurement_full_v3/` |
| Variance-normalized scaling control | `results/revision_normalized_scaling/` |
| Dephasing proof | `reports/dephasing_uniform_contraction_proof.md` |
| Final nested and prescreen summaries | `reports/nested_operating_point_extension_report.md`, `reports/nested_prescreen_stability_audit.md` |
| Historical pre-extension tuning summary | `reports/revision_tuning_report.md` |
| Other revision controls | `reports/revision_controls_report.md` |
| Measurement summary | `reports/measurement_full_equal_total_shots.md` |
| Critique-response inference and current response | `results/revision_tuning/critique_response_inference.json`, `reports/review_response_v7.md` |

The allowlist-based package builder,
[`scripts/build_revision_evidence_package.py`](scripts/build_revision_evidence_package.py),
is the release gate. In strict mode it accepts either a complete scored
activity-response chain or the authenticated terminal feasibility failure
present here; the latter requires all 240 calibration identities, at least one
valid censor, and complete absence of frozen-rate, score, and aggregate
artifacts. It also checks expected coverage, protocol hashes, source snapshots,
seed separation, ridge-boundary audits, baseline archive checksums, unsafe
paths, and a clean committed source tree. It excludes rendered manuscripts,
build products, caches, superseded smoke results, and credentials.

## Physics and implementation conventions

- Qubit 0 is the input qubit and the leftmost Kronecker factor:
  \(I^{\otimes i}\otimes O\otimes I^{\otimes(N-1-i)}\).
- \(\sigma^- = |0\rangle\langle1|\), so local amplitude damping relaxes toward
  \(|0\rangle\).
- Vectorization is column-major (`order="F"`), with
  \(\mathrm{vec}(A\rho B)=(B^\mathsf{T}\otimes A)\mathrm{vec}(\rho)\).
- The channel map, diagnostics, tuning, prospective, measurement, scaling, and
  joint family-profile paths use exact sparse matrix-exponential action with
  the continuous input value and do not sample quantum trajectories. The
  secondary local-rate-profile comparison is a documented legacy exception using dense
  evolution on a 32-point input grid; do not describe that ladder as exact
  continuous-input evolution.
- Paired comparisons reuse the same coupling draw and input sequence across
  methods. Selection, validation, and final test pools must remain separated.
- Hyperparameters are selected only on validation data. Reported test scores
  are evaluated once after the selection is frozen.
- Statistical effects are instance-paired and oriented so positive means
  better. Preserve the interval and multiplicity conventions stated in each
  figure caption.

The implementation sources of truth are `src/qrc/`, the checkpointed drivers
under `experiments/`, and the tests under `tests/`. Historical reports can help
with provenance, but they must not override the current manuscript, sealed
aggregates, or strict validators.

Two byte-sealed historical source docstrings retain the older words “budget”
and “initial energy-loss rate”:
`src/qrc/dissipators.py` and `experiments/run_review_experiments.py`.
Do not use those labels as the current physical interpretation, and do not edit
the files without deliberately resealing every dependent result group. The
current definitions are fixed in the manuscript, `reports/review_response_v7.md`,
and `reports/revision_tuning_report.md`: Frobenius normalization and initial
excitation-number loss rate, respectively.

## Reproduce the technical package

Create an isolated environment:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
PYTHONPATH=src:experiments python -m pytest -q
PYTHONPATH=src:experiments python experiments/revision_inference.py
```

After all result groups and reports are final, build and verify the reviewer
evidence archive from a clean committed tree:

```bash
python scripts/build_revision_evidence_package.py build \
  --require-complete \
  --output results/qrc_dissipation_reproducibility_package.zip
python scripts/build_revision_evidence_package.py verify \
  --require-complete \
  results/qrc_dissipation_reproducibility_package.zip
```

The evidence ZIP separates repository files under `source/` from sibling
`results/`. From its extracted top-level directory, reconstruct and validate a
runnable tree exactly as follows:

```bash
mkdir reproduction
cp -R source/. reproduction/
cp -R results reproduction/
cp -R reports reproduction/
cd reproduction
tar -xzf results/final_protocol_results.tar.gz -C results
tar -xzf results/review_protocol_results.tar.gz -C results
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
PYTHONPATH=src:experiments python -m pytest -q
PYTHONPATH=src:experiments python experiments/revision_inference.py
MPLCONFIGDIR=.mplconfig python paper/make_figures.py
cd paper
latexmk -pdf -interaction=nonstopmode -halt-on-error dissipation_qrc.tex
```

Figure sources and visual contracts are in
[`paper/FIGURE_QA.md`](paper/FIGURE_QA.md).

## Final release gate

Local items 1--8 below were completed on 26 July 2026 for scientific commit
`0e12030`; item 9 remains an integration/remote gate:

1. Revalidate the terminal v3 feasibility failure, nested tuning, historical
   driven-activity sensitivity, fresh spectral prospective control, and
   normalized-scaling evidence; verify manifests, source snapshots, complete
   checkpoint coverage, and disjoint seed pools where applicable.
2. Replace all `FINAL-SEAL` lines above with the exact validated result and
   source path. Synchronize manuscript prose, captions, reports, README files,
   and `paper/make_figures.py`.
3. Run `git diff --check` and the complete test suite.
4. Regenerate all eight figures. Audit their uncertainty semantics, embedded
   fonts, grayscale readability, and publication-scale renders.
5. Compile the manuscript with no missing references, undefined citations,
   overfull boxes, missing files, or Type 3/unembedded fonts. Inspect every
   rendered page.
6. Build and verify the strict evidence archive. Fresh-extract it, restore its
   baseline archives, regenerate the figures, and recompile the paper without
   relying on untracked repository files.
7. Build the allowlisted source ZIP and fresh-extract/compile it independently.
   Use `python scripts/build_quantum_source_archive.py build`, followed by its
   `verify` subcommand; the builder enforces the sealed eight-figure source
   membership and internal checksums.
8. Record the final scientific-source commit and actual archive hashes in the
   data-availability and submission materials. Verify every sidecar.
9. Confirm a clean worktree, exact local/remote synchronization, and successful
   CI before handoff.

The final user-facing deliverables are:

```text
qrc_dissipation_quantum_submission.pdf
quantum_submission_source.zip
qrc_dissipation_reproducibility_package.zip
qrc_dissipation_reproducibility_package.zip.sha256
quantum_submission_checklist.md
SHA256SUMS.txt
```

Author names/order, affiliations, ORCID iDs, funding, acknowledgements,
conflicts, contributions, licences, AI-tools disclosure approval, and the
arXiv `quant-ph` identifier remain human attestations. Do not invent them.
