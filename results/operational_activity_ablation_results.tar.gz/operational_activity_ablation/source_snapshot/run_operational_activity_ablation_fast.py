"""Fast entry point for the frozen operational-activity ablation.

The scientific protocol is defined in ``run_operational_activity_ablation``.
This wrapper changes only the linear-algebra implementation of the parity
readout: all seven delay targets and all ridge values share one thin SVD per
fit split.  Predictions are algebraically equivalent to the original repeated
least-squares/ridge solves.
"""
from __future__ import annotations

import numpy as np

import run_operational_activity_ablation as base
from qrc import readout, tasks
from run_final_scaling import TCFG


def _svd_predict(
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_eval: np.ndarray,
    ridges,
) -> dict[float, np.ndarray]:
    x_train = np.asarray(x_train, dtype=float)
    y_train = np.asarray(y_train, dtype=float)
    x_eval = np.asarray(x_eval, dtype=float)
    if y_train.ndim == 1:
        y_train = y_train[:, None]
    u, singular, vt = np.linalg.svd(x_train, full_matrices=False)
    uy = u.T @ y_train
    tol = np.finfo(float).eps * max(x_train.shape) * singular[0]
    output: dict[float, np.ndarray] = {}
    for ridge in ridges:
        if ridge <= 0:
            factors = np.divide(
                1.0,
                singular,
                out=np.zeros_like(singular),
                where=singular > tol,
            )
        else:
            factors = singular / (singular**2 + float(ridge))
        weights = vt.T @ (factors[:, None] * uy)
        output[float(ridge)] = x_eval @ weights
    return output


def parity_score(
    reservoir,
    train_inputs: np.ndarray,
    validation_inputs: np.ndarray,
    test_inputs: np.ndarray,
) -> dict:
    obs = readout.pauli_observables(base.N, max_weight=2)
    train_x = reservoir.run(
        train_inputs,
        obs,
        washout=base.PARITY_WASH,
        n_virtual=TCFG.parity_n_virtual,
    )
    val_x = reservoir.run(
        validation_inputs,
        obs,
        washout=base.PARITY_WASH,
        n_virtual=TCFG.parity_n_virtual,
    )
    test_x = reservoir.run(
        test_inputs,
        obs,
        washout=base.PARITY_WASH,
        n_virtual=TCFG.parity_n_virtual,
    )
    (train_xb, val_xb, test_xb), retained = base._guard_features(
        train_x, val_x, test_x
    )

    delays = tuple(TCFG.parity_delays)
    y_train = np.column_stack(
        [tasks.parity_target(train_inputs, d)[base.PARITY_WASH:] for d in delays]
    )
    y_val = np.column_stack(
        [
            tasks.parity_target(validation_inputs, d)[base.PARITY_WASH:]
            for d in delays
        ]
    )
    y_test = np.column_stack(
        [tasks.parity_target(test_inputs, d)[base.PARITY_WASH:] for d in delays]
    )
    if not (np.isfinite(y_train).all() and np.isfinite(y_val).all() and np.isfinite(y_test).all()):
        raise RuntimeError("parity targets unexpectedly contain non-finite values")

    predictions = _svd_predict(train_xb, y_train, val_xb, base.PARITY_RIDGES)
    validation_scores: dict[str, float] = {}
    for ridge in base.PARITY_RIDGES:
        pred = predictions[float(ridge)]
        validation_scores[f"{ridge:.12g}"] = float(
            sum(readout.capacity(y_val[:, j], pred[:, j]) for j in range(len(delays)))
        )
    best_ridge = max(
        base.PARITY_RIDGES,
        key=lambda value: validation_scores[f"{value:.12g}"],
    )

    refit_x = np.concatenate([train_xb, val_xb], axis=0)
    refit_y = np.concatenate([y_train, y_val], axis=0)
    test_pred = _svd_predict(refit_x, refit_y, test_xb, (best_ridge,))[float(best_ridge)]
    total = float(
        sum(readout.capacity(y_test[:, j], test_pred[:, j]) for j in range(len(delays)))
    )
    return {
        "value": total,
        "ridge": float(best_ridge),
        "retained_features": retained,
        "validation_scores": validation_scores,
        "readout_backend": "shared_thin_svd",
    }


base.parity_score = parity_score


if __name__ == "__main__":
    base.main()
