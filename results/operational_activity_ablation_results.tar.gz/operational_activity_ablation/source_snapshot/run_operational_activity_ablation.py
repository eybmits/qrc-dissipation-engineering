"""Minimal operationally matched task-dependence ablation.

This script is intentionally additive and does not modify any sealed result.
It asks one narrow reviewer-facing question:

    Does the collective-versus-local task reversal survive when the two
    dissipators realise the same time-averaged expected jump activity?

The matched quantity is

    J = (T * dt)^(-1) sum_t integral_0^dt
        sum_k rate_k Tr[L_k^dag L_k rho_t(tau)] d tau.

For the one-body lowering channels compared here, J is also the mean
bath-induced excitation-loss rate.  A single central target (0.5075) is taken
from the previously frozen five-target feasibility grid; no task scores from
that aborted protocol were produced.  Each paired reservoir is calibrated on
an independent unlabeled input stream.  A hard gate requires both local and
collective calibrations to reach the target before any task is scored.

The minimal task stage uses eight fresh paired reservoirs and all four paper
benchmarks.  It is a compact ablation, not a platform-cost comparison and not a
replacement for the paper's broader fixed-Frobenius map.

Run from the repository root:

    PYTHONPATH=src:experiments python experiments/run_operational_activity_ablation.py \
        --workers 2
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Sequence

for _name in (
    "OMP_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "MKL_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "NUMEXPR_NUM_THREADS",
):
    os.environ.setdefault(_name, "1")

import _paths  # noqa: E402,F401
import numpy as np  # noqa: E402
from scipy import sparse, stats  # noqa: E402
from scipy.sparse.linalg import expm_multiply  # noqa: E402

from _paths import RESULTS_DIR  # noqa: E402
from qrc import dissipators as dsp  # noqa: E402
from qrc import readout, reservoirs as res, tasks  # noqa: E402
from qrc.liouvillian import unvec, vec  # noqa: E402
from qrc.reservoirs import LindbladReservoir, ising_xx_hamiltonian, transverse_drive  # noqa: E402
from qrc.sparse_evolve import (  # noqa: E402
    SparseLindbladReservoir,
    commutator_super as sparse_commutator_super,
    lindbladian as sparse_lindbladian,
)
from run_final_scaling import TCFG, build_jumps, deterministic_seeds, mg_mse  # noqa: E402


PROTOCOL_VERSION = "operational-activity-ablation-v1-2026-07-27"
OUTDIR = Path(RESULTS_DIR) / "operational_activity_ablation"
PROTOCOL_PATH = OUTDIR / "protocol.json"
AGGREGATE_PATH = OUTDIR / "aggregate.json"

N = 5
H = 0.5
DT = 0.5
METHODS = ("CD_paper", "B3_collective")
METHOD_LABELS = {"CD_paper": "uniform local", "B3_collective": "collective"}

# Central member of the previously frozen five-target grid
ACTIVITY_TARGET = 0.5075
ACTIVITY_BOUNDS = {
    "CD_paper": (0.05, 0.5),
    "B3_collective": (4.0, 32.0),
}
CAL_WASH = 100
CAL_MEASURE = 150
CAL_BISECTION_STEPS = 8
CAL_REL_TOL = 0.015
N_SEEDS = 8
SEED_NAMESPACE = 2026072701

# STM/NARMA: same split sizes as the paper's validation-selected-ridge control.
WASH = 200
TRAIN = 450
VALIDATION = 150
TEST = 400
RIDGES = (0.0, 1e-10, 1e-8, 1e-6, 1e-4, 1e-2, 1e-1, 1.0, 10.0, 100.0)

# Corrected parity protocol: more refit rows than the 675 non-bias features.
PARITY_WASH = 100
PARITY_TRAIN = 500
PARITY_VALIDATION = 250
PARITY_TEST = 400
PARITY_RIDGES = (0.0, 1e-14, 1e-12, 1e-10, 1e-8, 1e-6, 1e-4, 1e-2, 1.0, 100.0)
FEATURE_STD_TOL = 1e-12

MG_WASH = 200
MG_TRAIN = 600
MG_HORIZON = 150


def _canonical_json(value: object) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _sha256_json(value: object) -> str:
    return hashlib.sha256(_canonical_json(value).encode("utf-8")).hexdigest()


def _atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n")
    os.replace(tmp, path)


def _rng(seed: int, stream: int) -> np.random.Generator:
    return np.random.default_rng(np.random.SeedSequence([seed, 20260727, stream]))


def fresh_seeds() -> list[int]:
    """Fresh deterministic seeds, explicitly disjoint from the sealed pool."""
    excluded = set(deterministic_seeds(256))
    rng = np.random.default_rng(SEED_NAMESPACE)
    out: list[int] = []
    while len(out) < N_SEEDS:
        candidate = int(rng.integers(0, 2**31 - 1))
        if candidate not in excluded and candidate not in out:
            out.append(candidate)
    return out


def protocol_payload() -> dict:
    payload = {
        "protocol_version": PROTOCOL_VERSION,
        "purpose": "minimal task-dependence ablation at matched realised jump activity",
        "n_qubits": N,
        "h": H,
        "dt": DT,
        "methods": list(METHODS),
        "activity_definition": (
            "time-averaged integral of sum_k rate_k Tr(L_k^dag L_k rho) "
            "along an independent unlabeled driven trajectory"
        ),
        "activity_target": ACTIVITY_TARGET,
        "activity_bounds": {key: list(value) for key, value in ACTIVITY_BOUNDS.items()},
        "calibration": {
            "washout": CAL_WASH,
            "measured_intervals": CAL_MEASURE,
            "bisection_steps": CAL_BISECTION_STEPS,
            "relative_tolerance": CAL_REL_TOL,
            "gate": "all 2*n calibrations must pass before any task scoring",
        },
        "task_splits": {
            "stm_narma": [WASH, TRAIN, VALIDATION, TEST],
            "parity": [PARITY_WASH, PARITY_TRAIN, PARITY_VALIDATION, PARITY_TEST],
            "mackey_glass": [MG_WASH, MG_TRAIN, MG_HORIZON],
        },
        "ridge_grids": {"stm_narma": list(RIDGES), "parity": list(PARITY_RIDGES)},
        "seeds": fresh_seeds(),
        "seed_namespace": SEED_NAMESPACE,
        "scope": (
            "equal realised jump activity, not equal power, entropy production, "
            "hardware complexity, or platform-specific cost"
        ),
    }
    payload["protocol_sha256"] = _sha256_json(payload)
    return payload


def ensure_frozen_protocol() -> dict:
    payload = protocol_payload()
    if PROTOCOL_PATH.exists():
        current = json.loads(PROTOCOL_PATH.read_text())
        if current != payload:
            raise RuntimeError("protocol drift detected")
    else:
        _atomic_json(PROTOCOL_PATH, payload)
    return payload


def couplings(seed: int) -> np.ndarray:
    return res.random_couplings(N, 1.0, _rng(seed, 0))


def jumps_for(method: str, J: np.ndarray, multiplier: float):
    target = dsp.jump_strength(dsp.local_loss(N, 1.0)) * float(multiplier)
    # Both selected families are deterministic; the explicit RNG keeps the
    # construction compatible with the shared build_jumps interface.
    return build_jumps(method, J, N, target, np.random.default_rng(0))


def _hamiltonian_terms(J: np.ndarray):
    h0 = ising_xx_hamiltonian(J, H, N)
    hx = transverse_drive(N)
    return h0 + H * hx, H * hx


def integrated_jump_activity(
    J: np.ndarray,
    jumps,
    inputs: Sequence[float],
    washout: int,
) -> float:
    """Compute the activity integral exactly via one augmented linear system.

    If v=vec(rho) and q^T v=Tr(Q rho), Q=sum rate L^dag L, augment the
    Liouvillian by ydot=q^T v.  The final auxiliary coordinate is the desired
    time integral.  No trajectory quadrature or jump sampling is used.
    """
    inputs = np.asarray(inputs, dtype=float)
    if not 0 <= washout < len(inputs):
        raise ValueError("invalid calibration washout")
    measured = len(inputs) - washout
    h_static, h_drive = _hamiltonian_terms(J)
    base = sparse_lindbladian(h_static, jumps)
    drive = sparse_commutator_super(h_drive)

    d = 2**N
    n = d * d
    q = np.zeros((d, d), dtype=complex)
    for op, rate in jumps:
        arr = np.asarray(op, dtype=complex)
        q += float(rate) * (arr.conj().T @ arr)
    qrow = sparse.csr_matrix(vec(q.T).reshape(1, n))
    zero_col = sparse.csr_matrix((n, 1), dtype=complex)
    zero_row = sparse.csr_matrix((1, n), dtype=complex)
    zero_one = sparse.csr_matrix((1, 1), dtype=complex)
    base_aug = sparse.bmat([[base, zero_col], [qrow, zero_one]], format="csr")
    drive_aug = sparse.bmat([[drive, zero_col], [zero_row, zero_one]], format="csr")

    rho0 = np.zeros((d, d), dtype=complex)
    rho0[0, 0] = 1.0
    z = np.concatenate([vec(rho0), np.zeros(1, dtype=complex)])
    for index, value in enumerate(inputs):
        generator = base_aug + float(value) * drive_aug
        z = expm_multiply(generator * DT, z)
        if index == washout - 1:
            z[-1] = 0.0
    result = float(np.real(z[-1]) / (measured * DT))
    if not np.isfinite(result) or result < -1e-10:
        raise RuntimeError(f"invalid activity {result}")
    return max(result, 0.0)


def calibration_inputs(seed: int) -> np.ndarray:
    return _rng(seed, 1).uniform(0.0, 1.0, CAL_WASH + CAL_MEASURE)


def calibrate_method(method: str, seed: int, J: np.ndarray, inputs: np.ndarray) -> dict:
    lo, hi = ACTIVITY_BOUNDS[method]
    cache: dict[str, float] = {}

    def evaluate(multiplier: float) -> float:
        key = f"{multiplier:.16g}"
        if key not in cache:
            cache[key] = integrated_jump_activity(
                J, jumps_for(method, J, multiplier), inputs, CAL_WASH
            )
        return cache[key]

    a_lo = evaluate(lo)
    a_hi = evaluate(hi)
    lower, upper = sorted((a_lo, a_hi))
    if not lower <= ACTIVITY_TARGET <= upper:
        best_mult, best_activity = min(
            ((lo, a_lo), (hi, a_hi)), key=lambda pair: abs(pair[1] - ACTIVITY_TARGET)
        )
        return {
            "method": method,
            "seed": seed,
            "reached": False,
            "multiplier": best_mult,
            "activity": best_activity,
            "relative_error": abs(best_activity - ACTIVITY_TARGET) / ACTIVITY_TARGET,
            "endpoint_activities": [a_lo, a_hi],
            "trace": cache,
            "reason": "target_not_bracketed",
        }

    best_mult, best_activity = min(
        ((lo, a_lo), (hi, a_hi)), key=lambda pair: abs(pair[1] - ACTIVITY_TARGET)
    )
    left_mult, right_mult = lo, hi
    left_activity, right_activity = a_lo, a_hi
    for _ in range(CAL_BISECTION_STEPS):
        mid = math.sqrt(left_mult * right_mult)
        a_mid = evaluate(mid)
        if abs(a_mid - ACTIVITY_TARGET) < abs(best_activity - ACTIVITY_TARGET):
            best_mult, best_activity = mid, a_mid
        if (left_activity - ACTIVITY_TARGET) * (a_mid - ACTIVITY_TARGET) <= 0:
            right_mult, right_activity = mid, a_mid
        else:
            left_mult, left_activity = mid, a_mid

    relative_error = abs(best_activity - ACTIVITY_TARGET) / ACTIVITY_TARGET
    return {
        "method": method,
        "seed": seed,
        "reached": bool(relative_error <= CAL_REL_TOL),
        "multiplier": float(best_mult),
        "activity": float(best_activity),
        "relative_error": float(relative_error),
        "endpoint_activities": [float(a_lo), float(a_hi)],
        "trace": cache,
        "reason": None if relative_error <= CAL_REL_TOL else "tolerance_not_reached",
    }


def calibration_job(seed: int) -> dict:
    started = time.perf_counter()
    J = couplings(seed)
    inputs = calibration_inputs(seed)
    rows = {method: calibrate_method(method, seed, J, inputs) for method in METHODS}
    return {"seed": seed, "methods": rows, "runtime_s": time.perf_counter() - started}


def sparse_reservoir(method: str, J: np.ndarray, multiplier: float):
    h_static, h_drive = _hamiltonian_terms(J)
    return SparseLindbladReservoir.from_terms(
        N, h_static, h_drive, jumps_for(method, J, multiplier), DT
    )


def parity_reservoir(method: str, J: np.ndarray, multiplier: float):
    h_static, h_drive = _hamiltonian_terms(J)
    return LindbladReservoir.from_terms(
        N,
        h_static,
        h_drive,
        jumps_for(method, J, multiplier),
        DT,
        cache_propagators=True,
        quantize=None,
    )


def _split_masks(y: np.ndarray, train: int, validation: int, test: int):
    valid = np.isfinite(y)
    fit = np.zeros(len(y), dtype=bool)
    val = np.zeros(len(y), dtype=bool)
    tst = np.zeros(len(y), dtype=bool)
    fit[:train] = True
    val[train : train + validation] = True
    tst[train + validation : train + validation + test] = True
    return fit & valid, val & valid, tst & valid


def stm_score(reservoir, inputs: np.ndarray) -> dict:
    obs = readout.pauli_observables(N, max_weight=2)
    features = reservoir.run(inputs, obs, washout=WASH)
    xb = readout.add_bias(features)
    targets = {d: tasks.delayed_target(inputs, d)[WASH:] for d in TCFG.stm_delays}
    validation_scores: dict[str, float] = {}
    for ridge in RIDGES:
        total = 0.0
        for delay, target in targets.items():
            fit, val, _ = _split_masks(target, TRAIN, VALIDATION, TEST)
            weights = readout.train_readout(xb[fit], target[fit], ridge=ridge)
            total += readout.capacity(target[val], readout.predict(xb[val], weights))
        validation_scores[f"{ridge:.12g}"] = float(total)
    best_ridge = max(RIDGES, key=lambda value: validation_scores[f"{value:.12g}"])
    test_scores = []
    for target in targets.values():
        fit, val, tst = _split_masks(target, TRAIN, VALIDATION, TEST)
        refit = fit | val
        weights = readout.train_readout(xb[refit], target[refit], ridge=best_ridge)
        test_scores.append(readout.capacity(target[tst], readout.predict(xb[tst], weights)))
    return {
        "value": float(np.sum(test_scores)),
        "ridge": float(best_ridge),
        "validation_scores": validation_scores,
    }


def narma_score(reservoir, inputs: np.ndarray) -> dict:
    obs = readout.pauli_observables(N, max_weight=2)
    features = reservoir.run(inputs, obs, washout=WASH)
    xb = readout.add_bias(features)
    target = tasks.narma_target(inputs, order=10, input_scale=0.2)[WASH:]
    fit, val, tst = _split_masks(target, TRAIN, VALIDATION, TEST)
    validation_scores: dict[str, float] = {}
    for ridge in RIDGES:
        weights = readout.train_readout(xb[fit], target[fit], ridge=ridge)
        validation_scores[f"{ridge:.12g}"] = float(
            readout.nmse(target[val], readout.predict(xb[val], weights))
        )
    best_ridge = min(RIDGES, key=lambda value: validation_scores[f"{value:.12g}"])
    refit = fit | val
    weights = readout.train_readout(xb[refit], target[refit], ridge=best_ridge)
    return {
        "value": float(readout.nmse(target[tst], readout.predict(xb[tst], weights))),
        "ridge": float(best_ridge),
        "validation_scores": validation_scores,
    }


def _guard_features(train_x: np.ndarray, *others: np.ndarray):
    keep = np.std(train_x, axis=0) > FEATURE_STD_TOL
    selected = [readout.add_bias(train_x[:, keep])]
    selected.extend(readout.add_bias(value[:, keep]) for value in others)
    return selected, int(np.count_nonzero(keep))


def parity_score(
    reservoir,
    train_inputs: np.ndarray,
    validation_inputs: np.ndarray,
    test_inputs: np.ndarray,
) -> dict:
    obs = readout.pauli_observables(N, max_weight=2)
    train_x = reservoir.run(
        train_inputs, obs, washout=PARITY_WASH, n_virtual=TCFG.parity_n_virtual
    )
    val_x = reservoir.run(
        validation_inputs, obs, washout=PARITY_WASH, n_virtual=TCFG.parity_n_virtual
    )
    test_x = reservoir.run(
        test_inputs, obs, washout=PARITY_WASH, n_virtual=TCFG.parity_n_virtual
    )
    (train_xb, val_xb, test_xb), retained = _guard_features(train_x, val_x, test_x)

    train_targets = {
        d: tasks.parity_target(train_inputs, d)[PARITY_WASH:] for d in TCFG.parity_delays
    }
    val_targets = {
        d: tasks.parity_target(validation_inputs, d)[PARITY_WASH:]
        for d in TCFG.parity_delays
    }
    test_targets = {
        d: tasks.parity_target(test_inputs, d)[PARITY_WASH:] for d in TCFG.parity_delays
    }

    validation_scores: dict[str, float] = {}
    for ridge in PARITY_RIDGES:
        total = 0.0
        for delay in TCFG.parity_delays:
            y_train = train_targets[delay]
            y_val = val_targets[delay]
            a = np.isfinite(y_train)
            b = np.isfinite(y_val)
            weights = readout.train_readout(train_xb[a], y_train[a], ridge=ridge)
            total += readout.capacity(y_val[b], readout.predict(val_xb[b], weights))
        validation_scores[f"{ridge:.12g}"] = float(total)
    best_ridge = max(
        PARITY_RIDGES, key=lambda value: validation_scores[f"{value:.12g}"]
    )

    total = 0.0
    for delay in TCFG.parity_delays:
        y_train = train_targets[delay]
        y_val = val_targets[delay]
        y_test = test_targets[delay]
        refit_x = np.concatenate([train_xb, val_xb], axis=0)
        refit_y = np.concatenate([y_train, y_val])
        valid = np.isfinite(refit_y)
        check = np.isfinite(y_test)
        weights = readout.train_readout(refit_x[valid], refit_y[valid], ridge=best_ridge)
        total += readout.capacity(y_test[check], readout.predict(test_xb[check], weights))
    return {
        "value": float(total),
        "ridge": float(best_ridge),
        "retained_features": retained,
        "validation_scores": validation_scores,
    }


def mg_score(reservoir, raw_series: np.ndarray) -> dict:
    prefix = MG_WASH + MG_TRAIN
    lo = float(np.min(raw_series[:prefix]))
    hi = float(np.max(raw_series[:prefix]))
    series = (raw_series - lo) / max(hi - lo, 1e-12)

    class _Job:
        wash = MG_WASH
        train = MG_TRAIN

    value = mg_mse(
        reservoir,
        readout.pauli_observables(N, max_weight=2),
        series,
        _Job(),
    )
    return {"value": float(value), "ridge": 1e-8, "scale_min": lo, "scale_max": hi}


def evaluate_seed(seed: int, calibration: dict) -> dict:
    started = time.perf_counter()
    J = couplings(seed)
    multipliers = {
        method: float(calibration["methods"][method]["multiplier"]) for method in METHODS
    }

    total = WASH + TRAIN + VALIDATION + TEST
    stm_inputs = tasks.stm_inputs(total, _rng(seed, 10))
    narma_inputs = tasks.narma_inputs(total, _rng(seed, 11))
    parity_train = tasks.parity_inputs(PARITY_WASH + PARITY_TRAIN, _rng(seed, 12))
    parity_validation = tasks.parity_inputs(
        PARITY_WASH + PARITY_VALIDATION, _rng(seed, 13)
    )
    parity_test = tasks.parity_inputs(PARITY_WASH + PARITY_TEST, _rng(seed, 14))
    mg_raw = tasks.mackey_glass_series(
        MG_WASH + MG_TRAIN + MG_HORIZON + 5,
        tau=17,
        sample_every=TCFG.mg_sample_every,
        discard=500,
        rng=_rng(seed, 15),
    )

    results: dict[str, dict] = {}
    for method in METHODS:
        multiplier = multipliers[method]
        method_rows: dict[str, dict] = {}
        method_rows["stm"] = stm_score(sparse_reservoir(method, J, multiplier), stm_inputs)
        method_rows["narma"] = narma_score(
            sparse_reservoir(method, J, multiplier), narma_inputs
        )
        method_rows["parity"] = parity_score(
            parity_reservoir(method, J, multiplier),
            parity_train,
            parity_validation,
            parity_test,
        )
        method_rows["mg"] = mg_score(sparse_reservoir(method, J, multiplier), mg_raw)
        results[method] = method_rows
    return {
        "seed": seed,
        "multipliers": multipliers,
        "tasks": results,
        "runtime_s": time.perf_counter() - started,
    }


def paired_summary(candidate: Sequence[float], reference: Sequence[float], higher: bool) -> dict:
    a = np.asarray(candidate, dtype=float)
    b = np.asarray(reference, dtype=float)
    if a.shape != b.shape or a.ndim != 1 or not len(a):
        raise ValueError("paired vectors required")
    raw = a - b
    oriented = raw if higher else -raw
    n = len(oriented)
    mean = float(np.mean(oriented))
    se = float(np.std(oriented, ddof=1) / math.sqrt(n)) if n > 1 else 0.0
    critical = float(stats.t.ppf(0.975, n - 1)) if n > 1 else 0.0
    nonzero = oriented[~np.isclose(oriented, 0.0, atol=1e-14)]
    wins = int(np.count_nonzero(nonzero > 0))
    sign_p = float(stats.binomtest(wins, len(nonzero), 0.5).pvalue) if len(nonzero) else 1.0
    return {
        "n": n,
        "candidate_mean": float(np.mean(a)),
        "reference_mean": float(np.mean(b)),
        "raw_candidate_minus_reference": float(np.mean(raw)),
        "oriented_improvement": mean,
        "ci95_low": float(mean - critical * se),
        "ci95_high": float(mean + critical * se),
        "wins": wins,
        "ties": int(n - len(nonzero)),
        "exact_sign_p_two_sided": sign_p,
        "paired_oriented_differences": oriented.tolist(),
    }


def build_aggregate(protocol: dict, calibrations: list[dict], evaluations: list[dict]) -> dict:
    calibration_by_seed = {row["seed"]: row for row in calibrations}
    evaluation_by_seed = {row["seed"]: row for row in evaluations}
    seeds = protocol["seeds"]

    activity = {}
    for method in METHODS:
        values = [calibration_by_seed[seed]["methods"][method]["activity"] for seed in seeds]
        multipliers = [
            calibration_by_seed[seed]["methods"][method]["multiplier"] for seed in seeds
        ]
        activity[method] = {
            "label": METHOD_LABELS[method],
            "mean": float(np.mean(values)),
            "se": float(np.std(values, ddof=1) / math.sqrt(len(values))),
            "max_relative_target_error": float(
                max(abs(value - ACTIVITY_TARGET) / ACTIVITY_TARGET for value in values)
            ),
            "mean_multiplier": float(np.mean(multipliers)),
            "multipliers": multipliers,
            "values": values,
        }
    activity["collective_minus_local"] = paired_summary(
        activity["B3_collective"]["values"], activity["CD_paper"]["values"], higher=True
    )

    tasks_summary = {}
    higher_map = {"stm": True, "narma": False, "parity": True, "mg": False}
    for task, higher in higher_map.items():
        local = [
            evaluation_by_seed[seed]["tasks"]["CD_paper"][task]["value"] for seed in seeds
        ]
        collective = [
            evaluation_by_seed[seed]["tasks"]["B3_collective"][task]["value"]
            for seed in seeds
        ]
        tasks_summary[task] = {
            "higher_is_better": higher,
            "uniform_local": local,
            "collective": collective,
            "collective_vs_local": paired_summary(collective, local, higher=higher),
        }

    return {
        "status": "complete",
        "protocol": protocol,
        "activity": activity,
        "tasks": tasks_summary,
        "calibration_rows": calibrations,
        "evaluation_rows": evaluations,
    }


def print_report(aggregate: dict) -> None:
    print("\n=== OPERATIONAL-ACTIVITY ABLATION ===", flush=True)
    print(
        f"target J={ACTIVITY_TARGET:.4f}; "
        f"local={aggregate['activity']['CD_paper']['mean']:.5f}, "
        f"collective={aggregate['activity']['B3_collective']['mean']:.5f}",
        flush=True,
    )
    print(
        "mean multipliers: "
        f"local={aggregate['activity']['CD_paper']['mean_multiplier']:.5f}, "
        f"collective={aggregate['activity']['B3_collective']['mean_multiplier']:.5f}",
        flush=True,
    )
    for task in ("stm", "narma", "parity", "mg"):
        row = aggregate["tasks"][task]["collective_vs_local"]
        arrow = "higher" if aggregate["tasks"][task]["higher_is_better"] else "lower"
        print(
            f"{task:7s} ({arrow} better): local={row['reference_mean']:.6f}, "
            f"collective={row['candidate_mean']:.6f}, "
            f"oriented Δ={row['oriented_improvement']:+.6f} "
            f"[{row['ci95_low']:+.6f},{row['ci95_high']:+.6f}], "
            f"wins={row['wins']}/{row['n']}, sign-p={row['exact_sign_p_two_sided']:.6g}",
            flush=True,
        )
    print(f"aggregate: {AGGREGATE_PATH}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=2)
    args = parser.parse_args()
    OUTDIR.mkdir(parents=True, exist_ok=True)
    protocol = ensure_frozen_protocol()
    seeds = [int(value) for value in protocol["seeds"]]
    print(
        f"Frozen protocol {protocol['protocol_sha256']}: "
        f"{len(seeds)} seeds, workers={args.workers}",
        flush=True,
    )

    calibrations: list[dict] = []
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(calibration_job, seed): seed for seed in seeds}
        for index, future in enumerate(as_completed(futures), 1):
            seed = futures[future]
            row = future.result()
            calibrations.append(row)
            _atomic_json(OUTDIR / "calibration" / f"seed_{seed}.json", row)
            status = all(row["methods"][method]["reached"] for method in METHODS)
            print(
                f"calibration {index}/{len(seeds)} seed={seed} pass={status} "
                + ", ".join(
                    f"{method}:x={row['methods'][method]['multiplier']:.5g},"
                    f"J={row['methods'][method]['activity']:.5f}"
                    for method in METHODS
                ),
                flush=True,
            )
    calibrations.sort(key=lambda row: seeds.index(row["seed"]))

    failures = [
        (row["seed"], method, row["methods"][method])
        for row in calibrations
        for method in METHODS
        if not row["methods"][method]["reached"]
    ]
    if failures:
        payload = {
            "status": "calibration_gate_failed",
            "protocol": protocol,
            "failures": failures,
            "calibration_rows": calibrations,
        }
        _atomic_json(AGGREGATE_PATH, payload)
        print("CALIBRATION GATE FAILED; NO TASK WAS SCORED", flush=True)
        for seed, method, row in failures:
            print(
                f"seed={seed} method={method} reason={row['reason']} "
                f"J={row['activity']:.6f} relerr={row['relative_error']:.3%}",
                flush=True,
            )
        raise SystemExit(2)

    calibration_by_seed = {row["seed"]: row for row in calibrations}
    evaluations: list[dict] = []
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures = {
            pool.submit(evaluate_seed, seed, calibration_by_seed[seed]): seed for seed in seeds
        }
        for index, future in enumerate(as_completed(futures), 1):
            seed = futures[future]
            row = future.result()
            evaluations.append(row)
            _atomic_json(OUTDIR / "tasks" / f"seed_{seed}.json", row)
            print(
                f"tasks {index}/{len(seeds)} seed={seed} "
                f"runtime={row['runtime_s']:.1f}s",
                flush=True,
            )
    evaluations.sort(key=lambda row: seeds.index(row["seed"]))

    aggregate = build_aggregate(protocol, calibrations, evaluations)
    _atomic_json(AGGREGATE_PATH, aggregate)
    print_report(aggregate)


if __name__ == "__main__":
    main()
